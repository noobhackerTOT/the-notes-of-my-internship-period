# Categorization Usage Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMTAxIn0=

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778468572808/%E6%99%BA%E8%83%BD%E5%88%86%E7%B1%BB.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778468578374/AI%20NAS%20%E6%95%99%E7%A8%8B%20%281%29.png)
