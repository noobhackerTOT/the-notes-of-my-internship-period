# Intelligent Organization Quick Start Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmOTcifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778464735914/%E6%99%BA%E8%83%BD%E6%95%B4%E7%90%86.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778464740498/AI%20NAS%20%E6%95%99%E7%A8%8B%20%284%29.png)
