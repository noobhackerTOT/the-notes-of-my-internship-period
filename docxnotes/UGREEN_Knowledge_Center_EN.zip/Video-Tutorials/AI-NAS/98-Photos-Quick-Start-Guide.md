# Photos Quick Start Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmOTgifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778465352292/%E7%9B%B8%E5%86%8C%E6%A6%82%E8%A7%88-en.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778465457003/AI%20NAS%20%E6%95%99%E7%A8%8B.png)
