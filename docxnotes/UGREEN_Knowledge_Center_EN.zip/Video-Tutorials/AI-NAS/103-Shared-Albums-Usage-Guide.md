# Shared Albums Usage Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMTAzIn0=

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778469988072/%E5%85%B1%E4%BA%AB%E7%9B%B8%E5%86%8C.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778469990260/AI%20NAS%20%E6%95%99%E7%A8%8B%20%284%29.png)
