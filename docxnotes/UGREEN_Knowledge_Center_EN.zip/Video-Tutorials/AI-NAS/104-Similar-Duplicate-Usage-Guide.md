# Similar & Duplicate Usage Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMTA0In0=

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778470054118/%E7%9B%B8%E5%86%8C-%E7%9B%B8%E4%BC%BC%E9%87%8D%E5%A4%8D%E7%85%A7%E7%89%87%E8%AF%86%E5%88%AB.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778470057130/AI%20NAS%20%E6%95%99%E7%A8%8B%20%285%29.png)
