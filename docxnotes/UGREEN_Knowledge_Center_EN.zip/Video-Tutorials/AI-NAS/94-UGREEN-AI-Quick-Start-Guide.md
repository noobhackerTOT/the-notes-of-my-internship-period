# UGREEN AI Quick Start Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmOTQifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778463156483/UGREEN%20AI%20.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778463163583/AI%20NAS%20%E6%95%99%E7%A8%8B%20%281%29.png)
