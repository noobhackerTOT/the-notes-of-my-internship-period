# Folder & Favorites Usage Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMTAwIn0=

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778468476674/%E7%9B%B8%E5%86%8C-%E6%96%87%E4%BB%B6%E5%A4%B9%26%E6%94%B6%E8%97%8F.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778468479316/AI%20NAS%20%E6%95%99%E7%A8%8B%20%286%29.png)
