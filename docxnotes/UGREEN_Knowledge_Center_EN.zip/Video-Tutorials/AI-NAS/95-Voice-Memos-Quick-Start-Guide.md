# Voice Memos Quick Start Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmOTUifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778463798659/Voice%20memos-en.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778463806921/AI%20NAS%20%E6%95%99%E7%A8%8B%20%282%29.png)
