# Personal Albums Usage Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMTAyIn0=

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778469228174/%E6%88%91%E7%9A%84%E7%9B%B8%E5%86%8C.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778469230672/AI%20NAS%20%E6%95%99%E7%A8%8B%20%283%29.png)
