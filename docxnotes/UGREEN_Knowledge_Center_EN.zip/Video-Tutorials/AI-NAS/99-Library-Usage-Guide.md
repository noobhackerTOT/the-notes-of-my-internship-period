# Library Usage Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmOTkifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778468130104/%E7%9B%B8%E5%86%8C-%E5%9B%BE%E5%BA%93.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778468238032/AI%20NAS%20%E6%95%99%E7%A8%8B.png)
