# Search Quick Start Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmOTYifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1778464302420/%E5%85%A8%E5%B1%80%E6%90%9C%E7%B4%A2-3n.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1778464274796/AI%20NAS%20%E6%95%99%E7%A8%8B%20%283%29.png)
