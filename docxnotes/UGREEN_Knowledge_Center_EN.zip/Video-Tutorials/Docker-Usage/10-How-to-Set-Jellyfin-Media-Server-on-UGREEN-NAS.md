# How to Set Jellyfin Media Server on UGREEN NAS?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMTAifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1753430536815/How%20to%20Set%20Jellyfin%20Media%20Server%20on%20UGREEN%20NAS.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1748501872398/photos%E5%B0%81%E9%9D%A2-%E8%8B%B1%E6%96%87%20%282%29.png)

When creating a project, you need to provide a Docker Compose configuration file. Below is an example configuration file for Jellyfin:

```
services:
  jellyfin:
    image: jellyfin/jellyfin:latest
    container_name: jellyfin
    restart: always
    devices:
      - /dev/dri:/dev/dri  # Integrated graphics
    environment:
      PUID: 0
      PGID: 0
    volumes:
      - ./config:/config
      - ./cache:/cache
      - /volume2/video:/video2 #Library location
    ports:
      - 9096:8096/TCP
    network_mode: "bridge"
```
