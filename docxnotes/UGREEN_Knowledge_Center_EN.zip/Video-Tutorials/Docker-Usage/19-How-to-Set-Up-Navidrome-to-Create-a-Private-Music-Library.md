# How to Set Up Navidrome to Create a Private Music Library

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMTkifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1750918473515/How%20to%20Set%20Up%20Navidrome%20on%20UGREEN%20NAS%20to%20Create%20a%20.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1750918478100/photos%E5%B0%81%E9%9D%A2-%E8%8B%B1%E6%96%87.png)

Below is a sample configuration for Navidrome:

```
services:
  navidrome:
    image: deluan/navidrome:latest
    restart: always
    volumes:
      - ./data:/data  #Custom cache path
      - /path/to/your/music/folder:/music:ro  #Custom path to your music folder; adjust based on actual location
    environment:
      ND_ENABLETRANSCODINGCONFIG: true  #Enable transcoding settings in the UI
      ND_TRANSCODINGCACHESIZE: 0 #Size of the transcoding cache; set to "0" to disable caching
      ND_SCANSCHEDULE: 1h  #Schedule regular library scans using "cron" syntax; set to "0" to disable
      ND_LOGLEVEL: info  #Log level, useful for troubleshooting
      ND_SESSIONTIMEOUT: 24h #Duration Navidrome waits before closing an idle session
      ND_BASEURL: ""  #Base URL for Navidrome when used behind a proxy (e.g., /music or https://music.example.com)
      ND_ENABLESHARING: true  #Enable the sharing feature
    ports:
      - 4533:4533 #Map host port 4533 to container port 4533; this is the default web port for Navidrome
```
