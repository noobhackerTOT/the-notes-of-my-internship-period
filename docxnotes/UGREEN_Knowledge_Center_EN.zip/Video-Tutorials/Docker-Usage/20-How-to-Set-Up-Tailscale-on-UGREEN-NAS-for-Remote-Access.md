# How to Set Up Tailscale on UGREEN NAS for Remote Access?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMSYmMjAifQ==

[Watch video](https://file1-cn.ugnas.com/ugreen-pro/article/manage/video/1750846780608/How%20to%20Set%20Up%20Tailscale%20on%20UGREEN%20NAS%20for%20Remote%20A.mp4)

![Cover](https://file1-cn.ugnas.com/ugreen-pro/article/manage/image/1748503984003/photos%E5%B0%81%E9%9D%A2-%E8%8B%B1%E6%96%87%20%285%29.png)

In the project creation wizard, enter the following Docker Compose configuration information for the container. These configurations are for reference only, and you can adjust them according to your own needs.

```
services:
  tailscale:
    container_name: tailscale
    image: tailscale/tailscale:latest # Image Name
    restart: always #Restart Policy
    volumes:
      - ./tun:/dev/net/tun  
      - ./lib:/var/lib  
    environment:
      - TS_AUTH_KEY=tskey-auth-k5msULvKo511CNTRL-odJfJb2aQcKSprp9JpLwcKd58Fws4Pje # Enter the key generated earlier.
      - TS_STATE_DIR=/var/lib/tailscale # Fixed value, no need to change.
      - TS_ROUTES=192.168.31.0/24 #Enter your router's gateway.
    network_mode: host # Use the host networking mode.
    privileged: true # Privileged Mode
```
