# File Management Settings

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjIwIn0=

**"Files**" is the core tool on a NAS device for managing and operating files. With proper configuration, you can optimize file management functionality, improve the user experience, and ensure data security. This document provides a detailed introduction to the Files settings, including general settings, feature permissions, and speed limit.

● **General Settings**: Essential for optimizing the user experience and management capabilities of Files. These options allow you to enable logging, manage file display behavior, handle duplicate file names, configure the code page used for file compression, and control user permissions.

● **Functional Permissions**: Administrators can finely manage permissions related to file sharing and file collection tasks here. You can specify which users or user groups are allowed to share files or create file collection tasks, and you can also limit the number of shared file links and file request links.

● **Speed Limit**: After enabling speed limit, administrators can control the upload and download speeds for each user when transferring data through Files. This helps prevent individual users from consuming excessive bandwidth and affecting the experience of others.

## General Settings

### Enable File Logs

When enabled, the system records all user file operations, including creating folders, uploading, downloading, deleting, renaming, moving, copying files, and modifying file properties.

**Steps:**

1. Open "**Files**", and click the "**Settings**" icon in the toolbar to open the settings window.

2. In the settings window, locate the "**General**"tab.

3. Select "**Enable file logs**".

4. Click "**Save**" to apply the settings.

**View logs:** Once enabled, you can view detailed user operation records in the "**Logs**"app.

### Hide User File Categories

By default, all users' personal folders are displayed in the left sidebar of "**Files**", allowing administrators to view and access files from all users. When "**Hide user file categories**" is enabled, the user folder categories in the left sidebar will be hidden, preventing administrators from seeing other users' personal folders while browsing files.

**Steps:**

1. Open "**Files**" and click the "**Settings**" icon in the toolbar to open the settings window.

2. In the settings window, locate the "**General**" tab.

3. Select "**Hide user file categories**".

4. Click "**Save**" to apply the settings.

5. Once saved, the user folder categories will be hidden.

### Duplicate File Handling

When transferring files using "**Files**", filename conflicts may occur. To avoid handling conflicts manually each time, you can configure the default behavior for files with same name in advance.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/4b8bdf8048c241b88e16ef053d0312de.webp)

1. **Skip**

● **Description**: Newly transferred files will be skipped and will not overwrite files with the same name at the destination.

● **Use case**: Suitable when you want to preserve existing files at the destination, such as avoiding overwriting important data.

2. **Overwrite**

● **Description**: Newly transferred files will automatically overwrite files with the same name at the destination.

● **Use case**: Suitable when you always want the latest files to replace older ones, such as updating configuration files or replacing outdated documents.

3. **Keep**

● **Description**: Newly transferred files will be kept, and a number will be automatically appended to the filename (for example, `filename(1)`, `filename(2)` ), to distinguish files with the same name.

● **Use case**: Suitable when you want to keep all files to avoid data loss, while allowing for later manual organization.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/6cef482df7384199b74663ae29a9b9cf.webp)

4. **Ask Each Time**

● **Descriptio**n: Each time a filename conflict occurs, the system prompts you to choose how to handle it (Overwrite, Skip, or Keep).

● **Use case**: Suitable when you want flexible, case-by-case handling of file conflicts, especially when you are unsure whether a file should be overwritten.

### Code Page for Downloading or Compressing into a .zip File

You can configure the code page used when downloading files or compressing files into `.zip` archives to support different language environments.

**Steps:**

1. In the settings window, select a language from the drop-down menu (supports Unicode, Simplified Chinese, Traditional Chinese, and English).

2. Click "**Save**" to apply the settings.

### Allow Non-Admin Users to Access the Full User List

This feature allows non-administrator users to view the complete list of users on the device, making it easier to share files between users.

### Hide Specified Files

By default, "**Files**" hides files that start with `._`, as well as `thumbs.db` and `.DS_Store` files. These files are typically metadata generated by the system or applications. Hiding them helps reduce folder clutter and improves interface clarity.

## Functional Permissions

1. **Allow users to share files and set shared file link limits**: Administrators can specify which users or user groups are allowed to share files and set limits on the number of shared file links.

2. **Allow users to create file collection tasks and set file request link limits**: Administrators can specify which users or user groups are allowed to create file collection tasks and set limits on the number of file request links.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/b80cfcddd40347cdb58d007d5c74dda5.webp)

## Speed Limit

You can enable speed limits to control the maximum available bandwidth for users and groups when transferring data through Files.

To enable speed limits, check "**Enable Speed Limit**". Once enabled, you can set the maximum upload and download speeds for administrators, general users, and user groups within the device. Click "**Save**" to apply the settings.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/399206fdf0e04a8293bdffcf427ba312.webp)
