# Files

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjI0In0=

**Applicable Version:** UGOS Pro 1.11.0.0002 and later

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

**"Files"** is a powerful yet easy-to-use tool that helps you efficiently organize all your files, making it convenient to browse and categorize content. It offers a wide range of practical features, including file sharing and collection, folder permission management, network folder connections, file deduplication, and the ability to create desktop shortcuts for files and folders. Together, these features make Files more efficient, secure, and straightforward.

Below are the main functional modules and their purposes:

● **File Sharing and Collection**

**File Sharing**: This feature allows users to share files with others in multiple ways, such as generating links or QR codes. You can configure access permissions to ensure that only authorized users can view or download the files, and you may also set an expiration time to further enhance security.

**File Request**: This feature enables others to upload files to your NAS via a collection link that you provide. It is ideal for use cases such as team collaboration, assignment submission, or remote file collection. By significantly simplifying the data-sharing process, it enhances collaboration and user interaction.

● **Folder Permission Management**

**"Files**" provides fine-grained folder permission settings, allowing you to precisely control which users or user groups can access, edit, or manage specific folders. This is well suited for scenarios such as team collaboration or file sharing among family members. By ensuring that different users access data with appropriate permission levels, this feature improves both security and administrative efficiency. Permission options include **read/write**, **read-only**, and **denied access**, meeting a wide range of access control needs.

● **Network Folder Connections**

In addition to managing files stored on the NAS, "**Files**" supports connecting to network folders to mount files from other NAS devices or servers. This allows you to conveniently manage files across multiple NAS systems without frequently switching between devices. The feature enables more efficient and streamlined file transfer and management.

● **Intelligent Identification and File Deduplication**

If your storage contains a large number of duplicate files, the file deduplication feature can quickly identify all duplicates by comparing file sizes or calculating hash values. Based on intelligent filtering rules, you can then batch-delete redundant files to save storage space and keep the system efficient and well organized.

● **Fast and Accurate Search**

**"Files**" is equipped with a high-performance search engine that quickly locates the files you need, even within complex directory structures. This feature is especially valuable for users managing large volumes of data. Whether working with documents, media files, or personal data, it significantly improves search efficiency. With support for full-text search and metadata filtering, users can pinpoint specific files with greater precision.

## Files Interface

The Files app consists of three main areas: the left navigation pane, the top toolbar, and the file list on the right.

### Left Navigation Pane

This section displays all storage resources and quick-access entries available to you. You can expand, collapse, or switch between directories in the list.

● **Favorites**: Displays the folders you have added to Favorites. You can right-click any folder and select **"Create shortcut" > "Favorites"** to add it here.

● **Personal Folder**: A private space accessible only to the current account. If your administrator has enabled "Full Control" permissions, you can choose whether to hide this folder from others.

● **Shared Folder**: Contains files shared within your team or family, making collaboration easier.

● **User Folder** (Admin Only): Administrators can access all personal folders created by users on the device through this entry.

● **Network Folder**: Shows remote folders mounted via file service protocols such as SMB or WebDAV. You can access files stored on other devices here.

● **External Device**: When the NAS detects a connected USB drive or card reader, the device will appear here. You can browse, copy, or move files directly.

● **Sharings**: Displays the folders shared on the device. Through this entry, you can access folders that other users have shared with you. （This entry appears only after a file or folder has been shared with you.）

● **Mount Image**: You can right-click an ISO image file and select **"Mount image"**. The mounted content will be displayed here. When finished, right-click the mounted image and choose **"Delete"**.

● **Tag**: Displays all tag categories by color. You can assign tags to files, and the system will highlight them with distinct colors to help with quick filtering and searching.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/53b10503ecb746899cc6f80da8699cf6.webp)

### Top Toolbar

The toolbar provides commonly used file-operation buttons for quick task execution.

● **New folder**: Create a new folder in the current directory, or create a shared folder or connect a network folder.

● **Upload**: Select files from your local device and upload them to the NAS.

● **Edit Actions**: Includes basic operations such as copy, paste, cut, and rename.

● **Management**: Opens advanced options, including personal/shared folder management, sharing management, file request management, file deduplication, and recycle bin management.

● **Filter/Sort**: Sort the file list or filter by selected conditions.

● **Settings**: Adjust general settings, modify functional permissions, or set transfer speed limits.

● **View**: Switch between list view and icon view.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/ee426579de5c46b9a2d4da4948d7c4ee.webp)

### File List (Right Panel)

This area displays all file details in the current directory and supports multiple interactions.

● **File Sorting**: You can sort files by name, size, type, or modification date. Click **"···"** to select additional dimensions, such as creation date, recent accessed, or tag.

● **Multi-Select**: Hold "**Shift**" or drag with your mouse to select multiple files for batch operations.

● **Drag-and-Drop Upload**: Drag files from your computer into this area to upload them directly.

● **Right-Click Menu**: Right-click a file to quickly copy, move, share, or rename it.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/06d20ec1c5624010aea73d396fee8907.webp)

## Managing Files

In Files, you can right-click any file or folder to open the context menu and perform various operations.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/6e1abc82a41242e9b4cfa76e872a4768.webp)

### Basic Operations

Below is an overview of basic file operations. For detailed instructions, please refer to [Basic File Operations](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmMTQ2In0=).

● **Open & Preview**: Click **"Open"** to preview file contents or enter a folder.

● **Upload**: Click "**Upload**" to transfer files or folders from your local computer to the UGREEN NAS.

● **Download**: Click "**Download**" to save files from the NAS to your current local device (computer or mobile phone).

● **Copy & Cut**: Select "**Copy**" or "**Cut**" icon, then paste the file into your target location.

● **Rename**: Click "**Rename**" icon to modify the name of a file or folder.

● **Delete**: Click "**Delete**" icon to move unwanted files to the Recycle Bin.

● **Transfer to a Specific Location**: Use **"Copy to / Move to"** to send files directly to a selected folder via the pop-up directory window.

● **Compress Files**: Select one or more files and click **"Add to compressed file"** to bundle them into a compressed file.

● **Decompress**: For compressed packages, choose "**Decompress**" to unpack into the current directory, or "**Decompress to**" to specify a destination path.

● **Properties**: Click "**Properties**" to view details such as file size, location, and modification time.

● **Tag Management**: Click "**Tag**" to assign color labels to files for quicker filtering and searching.

● **Create Shortcut**: Click "**Create shortcut**" to add a frequently used folder to "**Favorites**" or your desktop.

● **Move to Vault**: Click "**Move to vault**" to transfer sensitive files into a protected, encrypted space. For more information, please refer to [Vault](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmNjczIn0=).

### Advanced Management Features

● **Personal Folder Management:**The system provides flexible configuration options for users' personal folders.

● **Shared Folder Management**: You can create and manage shared folders for team collaboration and apply strict permission policies to ensure data security.

● **Sharing Management:**This feature is ideal for temporary file transfers or sharing materials externally. You can centrally manage all generated sharing links here.

● **File Request Management:** Use this feature when you need to collect files from multiple people, such as gathering event photos, homework assignments, or documents.\

● **File Deduplication:**The system can help you detect and clean up duplicate files, freeing up storage space.

● **Recycle Bin Management:**Files includes a recycle bin to prevent accidental file deletion.
