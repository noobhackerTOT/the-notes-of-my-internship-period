# File Sharing

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTU1In0=

With the sharing feature in the "**Files**" app, you can share files or folders with "**Internal user**" or "**External user**", making data collaboration and remote access more convenient. External users do not need to register for a NAS account—they can simply click the shared link to access, download, or preview the files.

## Share with Users within This Device

1. Open the "**Files**" app, select the file or folder you want to share, and right-click to choose "**Share**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/35ec69dee0be45928a303df1211d54c0.webp)

2. On the "**Share**" page, select "**Internal user**" as the sharing target, check the desired user or user group, and click "**Confirm**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/a91375a30d1f4402b8aad20adca6d9d9.webp)

3. The system will generate a share link and a QR code. You can send the share link to the intended user. Once the user logs in through the link, they will be able to directly access and download the shared file or folder. In addition, users can preview images, audio, video, and other multimedia files online.

**Note**: the online preview feature depends on the browser's support. Certain special file formats may not be viewable directly in the browser.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/0631c3e19c914a619b66fd0e5467645f.webp)

At the same time, users within this device can view shared content under "**Files**">"**Sharings**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/3ca4017f6ae14ff98021d8deafb729ec.webp)

## Share with External Users

1. Open the "**Files**" app, select the file or folder you want to share, and right-click to choose "**Share**".

2. On the "**Share**" settings page, select "**External User**" and you can configure the following options:

● **Share Validity Period** (custom time or permanent)

● **Allow Download**

● **Password** (when enabled, recipients must enter the specified password to access the link).

● **Visit Limit** (when enabled, you can restrict how many times the shared file can be accessed; once the limit is reached, it can no longer be viewed).

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/ff1bb8689f0a41f0ad48f7f2cabc99d3.webp)

3. After setting is complete, click "**Confirm**". The system will generate a share link and a QR code. Copy the link and send it to the external user.

4. External users do not need to register; they can directly access and download files or folders through the link. Online preview of images, audio, video, and other multimedia files is also supported.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/6dca443556ad4e6cbc746dbf483bdebc.webp)

## Sharing Management

On the "**Sharing management"** page, you can centrally view and manage all created file share links. Whether sharing with other accounts on the device or generating links for external users, all shares can be maintained here.

To access this page: open the "**Files**"app, click the top toolbar "**Management**">"**Sharing management**".

### Share List Information

The page presents all share records in a list format, displaying key statuses clearly:

1. **Title**: Shows the name of the shared file or folder (e.g., Comics, .cache).

2. **Recipient**: Indicates the target of the share, distinguishing between "**External user**" (access via link) and "**Internal user**" (account-based sharing within the device).

3. **Validity**: Shows the link's expiration date. Status can be a specific date (e.g., 2026-01-01) or "**Permanent**".

4. **Status**:

5. **Sharing**: The link is currently valid and accessible.

6. **Invaild**: The link has expired and is no longer accessible externally.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/8fb4e78d9a794aa7be8a20e75480934a.webp)

### Management Actions

**Single Share Management:**

In each row of the list, the "**Actions**" column provides three shortcut icons:

● **Copy Link (first icon)**: Copy the share link and extraction code to the clipboard for easy sharing.

● **Edit Settings (second icon)**: Modify the share's validity, password, or access permissions.

● **Cancel Share (third icon)**: Immediately terminate the share; the link will become invalid and inaccessible.

**Batch Maintenance:**

The top toolbar offers efficient batch management tools:

● **Clear invaild links**: Click the "**Clear invaild links**" button to automatically remove all share records marked as "**Invaild**", quickly freeing up space in the list.

● **Delete**: Select one or more records in the list, then click the red "**Delete**" button to manually remove the selected shares.

● **Search**: Enter file title keywords in the search box at the top-right to quickly locate specific share records.
