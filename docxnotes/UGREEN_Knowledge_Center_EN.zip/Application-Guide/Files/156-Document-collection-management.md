# Document collection management

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTU2In0=

## **Create a File Request**

To allow others to upload files to your Ugreen NAS:

1. Select a target folder for storing the collected files.
2. Right-click and select "**Request Files**" from the context menu.
3. Fill in the information on the file collection page, create a file collection link or QR code, and send it to others.

![](https://pro-help.ugnas.com/ugreen-pro/admin/article/1709203311629/fe9275acaa55eb4f66af8087d9862ef928b6ce1ac5f260138550322b1d30c11a.gif)

## **Document Collection management**

**Validity icon**:Click to set the number of days of validity to see the current document collection link valid date expires on XX.

![](https://pro-help.ugnas.com/ugreen-pro/admin/article/202312/%E5%88%86%E4%BA%AB%E7%AE%A1%E7%90%861.png)

**Password icon**:Set a password for the document collection link, and when set, access to the link will require the correct password to be entered.

![](https://pro-help.ugnas.com/ugreen-pro/admin/article/202312/%E5%88%86%E4%BA%AB%E7%AE%A1%E7%90%862.png)

**Visits icon**:Set the number of visits for the document collection link.

![](https://pro-help.ugnas.com/ugreen-pro/admin/article/202312/%E5%88%86%E4%BA%AB%E7%AE%A1%E7%90%863.png)

Manage file collection links, you can edit, delete or share existing file collection links. Clear expired document collection links.

![](https://pro-help.ugnas.com/ugreen-pro/admin/article/1709273439147/d6c9ca03898eae6d281f90ffad4b755a93a4e19dfe75a7cf5702f8856aec3f0b.gif)
