# Create New Folder

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTM5In0=

## Overview

Before using the "**Files**" application, please ensure that a volume has been created.
If no volume exists on the device, the application will display the following message upon entry: "No volumes available on this device. Please go to '**Storage**' app to create before using."

## Creating a Personal Folder

You can create a folder in your personal directory using the following methods:

### Method 1: Via the Top Toolbar

1. In "**Personal Folder**", navigate to the target directory where you want to create the folder.

2. Click the "**+**" button on the top toolbar and select "**Create folder**".

3. In the pop-up window, enter a name for the folder and click "**Confirm**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/085e186fba9b410599cfd8a0a4f96fce.webp)

### Method 2: Via the Right-Click Menu

1. In the target directory of "**Personal Folder**", right-click on an empty area of the file list to open the context menu.

2. Select "**Create**">"**Folder**".

You can also choose to quickly create document, or txt here.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/00874a539b40442da6741788647ef6c5.webp)

3. Enter a name for the folder and click "**Confirm**" to create it.

**Naming Rules:**

● **Length limit:** Up to 255 bytes (including file extension).

● **Invalid characters:** Do not use special characters such as `/` or `:`.

## Creating a Shared Folder

Shared folders serve as collaborative directories for multiple users and can only be created by administrators.

**Steps**:

1. Under the "**Shared Folder**" category, click the "**+**" button on the top toolbar and select "**Create shared folder**".

2. Complete the configuration in the pop-up wizard:

● **Basic settings:** Enter a folder name (up to 255 bytes) and select the storage location.

● **Volume usage limit** (optional): Enable this option to limit the maximum storage capacity for the folder.

● **Hide in "Network"**(optional): Check this option to hide the folder from SMB, AFP, and other network protocol access.

3. **Enable Recycle Bin** (enabled by default, adjust as needed): Files deleted from this folder will be temporarily stored for recovery.

● **Admin-only access**: If unchecked, non-administrator users will also gain access to the folder.

4. Click "**Create**" to complete the operation.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/31b6710675954d5c83b5590f8972ed6a.webp)

**Note:**

● **Subfolder limit:** If a folder contains more than 10,000 subfolders, the directory may not open properly in the web version of "**Files**". It is recommended to access such folders by mounting them via SMB or AFP on a local computer.
