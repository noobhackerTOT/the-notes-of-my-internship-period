# Folder Management

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzcwIn0=

**Applicable Version**: UGOS Pro 1.11.0.0002 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## Personal Folder Management

The Personal Folder Management feature allows administrators to centrally manage personal folders on the UGREEN NAS, helping to allocate storage resources efficiently while ensuring data security.

### Accessing Personal Folder Management

1. Open "**Files**".

2. Click the "**Management**" icon in the right-side toolbar, click "**Personal folder management**" to open the settings page.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/b4b164454a524c32973bbe6b5f3e1db1.webp)

### Personal Folder Management Settings

On the "**Personal folder management**" page, you can configure the following options as needed:

1. **Set the Storage Location for Personal Folders**

Select the default storage location for personal folders (such as a specific storage pool or volume) to ensure proper allocation of storage resources.

2. **Configure Access Permissions**

Set access permissions based on different user roles:

● **Administrator Permissions**: Administrators have access to all users' personal folders by default.

● **Standard User Permissions**: Standard users can access and manage their own personal folders.

● **User Group Permissions**: Access permissions can be assigned to specific user groups to simplify batch management.

3. **Enable or Disable Full Rights**

When user's "**Full rights**" is enabled, users can decide whether administrators are allowed to access their personal folders.

● **Enabled**: Users may choose to allow or deny administrator access to their personal folders. If a user denies administrator access, file operation logs for that user will not be recorded. Enable this option with caution.

● **Disabled**: Administrators always have access, ensuring controllable and consistent data management.

**Recommendation:** To ensure complete file operation logging, it is recommended to disable "**Full rights**".

4. **Set Personal Folder Storage Quotas**

By default, personal folders have no storage limit. You can set a quota as needed, with support for the following units:

● **MB** (for small folders)

● **GB** (for everyday use)

● **TB** (for large-scale data storage)

**Tip:** Setting quotas helps prevent individual users from consuming excessive storage resources and improves overall system stability.

5. **Save Settings**

After completing the configuration, click "**Confirm**" to save and apply the settings.

**Note**

● If "**Full righs**" is enabled and a user chooses to deny administrator access, administrators will not be able to view that user's file operation logs. To avoid potential data security risks, it is recommended to disable this feature.

● When setting the storage location, ensure that the target storage space has sufficient available capacity to prevent write failures due to insufficient space.

● When configuring storage quotas, allocate limits based on actual usage requirements to avoid impacting normal user operations.

## Shared Folder Management

By navigating to "**Shared Folder**">"**Management**" icon> "**Shared folder management"**, administrators can comprehensively view and efficiently manage all top-level shared folders on the NAS.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/4cf52163564a4e218adba5a9b914ba8e.webp)

On the "**Shared folder management**" page, the following administrator-only actions are available:

1. **Create a Shared Folder**: Click "**New folder**" and follow the wizard to quickly create a new shared folder. For more details, please refer to [**Create Folder**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmMTM5In0=).

2. **View the Shared Folder List**: Displays key information for all top-level shared folders, including folder name, size, storage location, and capacity limit. Sorting by folder name and filtering by storage location are supported. Hover over the storage location to view the volume description, used/total capacity, and file system type.

3. **Edit a Shared Folder**: Hover over the target shared folder and click "**Edit**" to open the edit page. You can modify general settings such as the folder name, storage location, and capacity limit, as well as configure user or user group access permissions and NFS permissions. For more details, refer to [**File Permission Settings**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmMTQyIn0=).

4. **Delete a Shared Folder**: Hover over the target shared folder and click "**Delete**" to permanently remove the folder and all of its contents.

**Note:** Deletion is irreversible. Please ensure the operation is correct before proceeding.

5. **Search Shared Folders**: Enter a folder name in the search box to quickly locate the target shared folder. Both fuzzy matching and exact search are supported to improve search efficiency.

**Usage Recommendations**

● **Regularly review folder status**: Use the list information to adjust storage quotas in a timely manner and optimize storage resource allocation.

● **Manage permissions carefully**: Ensure that shared folder access permissions comply with security policies to prevent data leakage or accidental operations.

● **Back up important data**: Before deleting a shared folder, it is recommended to back up critical data to avoid data loss due to accidental deletion.
