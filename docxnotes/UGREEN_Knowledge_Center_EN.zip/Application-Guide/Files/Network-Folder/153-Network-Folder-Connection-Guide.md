# Network Folder Connection Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTUzIn0=

## Feature Overview

The "**Network Folder**" feature allows you to directly mount remote storage resources to your NAS. You can connect other devices, servers, or third-party cloud drives to Files and access or manage external data just like local files—without repeatedly downloading or transferring data.

## Supported Connection Types

Currently, the following mounting methods are supported:

### General Protocols

Suitable for LAN devices or remote servers.

● **SMB**: Commonly used for NAS devices or Windows shared folders within a local network.

● **FTP**: A standard file transfer protocol.

● **WebDAV**: Supports cross-network access and is commonly used to connect NAS devices or cloud storage services that support this protocol.

● **SFTP**: A secure file transfer protocol based on SSH, offering enhanced security.

### Cloud Drive Services

● **115 Drive (115 Life)**: Use the "**115 Life app**" to scan the QR code and authorize login.

● **Quark Drive**：Log in by scanning the QR code with the "**Quark app**" or by using your mobile phone number.

## Connecting a Folder via Standard Protocols

1. Open the "**Files**" app, then click "**+**"on the top toolbar and select "**Connect to network folder**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/d410d4dcfbcc41c284f44a95f173f7cf.webp)

2. Select the required protocol (such as SMB or WebDAV) and click "**OK**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/623c14f00724475ca1ee9df97c8a55c6.webp)

3. **Enter the required information**:

● Server address (IP address or domain name)

● Port number (if applicable)

● Account username and password with access permissions

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/dba4780c42c3433e8b2c758b66adf61e.webp)

4. Click "**Next**" to verify the connection. After verification succeeds, select the target folder to mount and click "**Done**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/53a4916dd39a4078a861eefc6d26f434.webp)

## Connecting a Cloud Drive Folder

1. On the connection page, select the corresponding cloud drive icon and click "**OK**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/11990ea14f71430c820f71e7cd83821a.webp)

2. A QR code will be displayed. Use the corresponding cloud drive mobile app to scan the code and confirm authorization.

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/d74eb839881649ffa4d3dc4fdf612bed.webp)

3. Once authorization is successful, the cloud drive content will be automatically loaded into the Network Folder list.

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/1590a977507c470a8f70cad259eef919.webp)

## Managing Network Folder

You can perform the following management actions on mounted folders:

![](https://file1-cn.ugnas.com/admin/article/2026-01-22/697ce2e26cf44f0bac39c830ef068d78.webp)

● **Disconnect**: Temporarily suspend communication with the remote server.

**Step**: Select the folder, right-click it and choose "**Disconnect**". To restore access, select the folder again and choose "**Reconnect**".

● **Unmount**: Completely remove the mount configuration.

**Step**: Select the folder, right-click it and choose **"Unmount"**.

Disconnecting or unmounting will not delete any original files stored on the remote server.

## Notes

● You can browse, copy, move, delete, rename, and download files in network folders. Actual permissions depend on the configuration of the remote server or cloud drive account.

● Access speed depends on the current network environment. If the remote device is powered off or the cloud service is unavailable, the folder may be temporarily inaccessible.

● If you modify connection details such as the server address or account password, you must unmount the existing connection and add it again.
