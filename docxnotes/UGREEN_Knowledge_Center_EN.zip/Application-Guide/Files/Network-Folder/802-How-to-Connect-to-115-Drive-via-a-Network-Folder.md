# How to Connect to 115 Drive via a Network Folder?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODAyIn0=

## Overview

The Network Folder feature allows you to mount your 115 Drive（115 Life） on the NAS, enabling convenient file management and seamless file transfers.

## Connection Steps

1. Open the "**Files**" application, click the "**+**" button on the top toolbar, and select "**Connect to network folder**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/237845762e704c8c9373fe04f277e902.webp)

2. On the connection type selection screen, choose "**115 Drive**" and click "**OK**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/be630b9055a4428fa77c1e3cd8a27164.webp)

3. A QR code login window will appear. Open the 115 Drive (115 Life) App on your mobile device and scan the QR code on the screen to authorize access.

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/c46b9d1c2ee646cba823fbce09dc7790.webp)

4. After successful authorization, the file directory of your 115 Drive will automatically load and appear in your network folder list.

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/b02136351ed94e8b91b817a886ddd4c9.webp)

## Supported Features

Once connected, you can manage your cloud drive files just like local files:

● Upload, download, delete, rename, and perform other standard file operations on cloud drive files.

● The network folder integrates with the Vault feature. You can move files from the cloud drive into the Vault for encryption or remove encrypted files from the Vault back to the cloud drive. For more information, please refer to [How to Securely Manage Cloud Drive Files Using the Vault?](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODAzIn0=)

## Why Some 115 Drive Files Do Not Appear on the NAS?

If the number of files displayed in the NAS network folder is less than what is shown in the 115 Life App, or if certain folders are missing, this is usually because the 115 Life App has "**Hidden Mode**" enabled, meaning the folders are encrypted. This is a security mechanism of 115 Drive. When mounted on the NAS as a third-party device, hidden or encrypted content cannot be accessed.

To access these files on the NAS, first disable encryption for the folder in the 115 Life App. After refreshing, the files will display normally. For more details, please refer to [Why Some 115 Cloud Drive Files Do Not Appear on the NAS?](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmNzk2In0=)
