# How to Enable and Manage Personal Folders for Enhanced Data Privacy Protection

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjA0In0=

A Personal Folder is a private space for users to store their files. Only the user and administrators can access these files; other standard users cannot. Once enabled, users can easily manage their files via the "Files".

## **Steps to Enable Personal Folders:**

- Administrator log in with an administrator account and navigate to [Control Panel] > [User Management].
- Edit the target user account, check the "Enable Personal Folder for This User" option in the Basic Info section, and click "Save" to activate.

## **Full Control**

To further protect Personal Folders by preventing access from other users (including administrators), enable the "Full Control" feature:

### **Administrator Actions**

- Click the [Manage] button in the "Files" toolbar, then select [Personal Folder Management].
- Locate the target user account, check "Full Control", and click "Confirm" to apply.
- Note: After activation, other users attempting to access the folder will see the error: "Insufficient permissions to perform this operation."

### **Administrator Permission Restrictions**

- Administrators can only enable "Full Control" for their own accounts or standard user accounts, not for other administrators.
- Settings take effect immediately upon enabling.

### **Common User Actions (if applicable)**

If your account is a common user account, perform the following after an administrator enables the privilege:

1. Log in to your account, navigate to Personal Folder Management in the "Files", and check the "Hide my personal files from other users" option.
2. Click "Save" to apply.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250728/8a33656c-c1fd-4a25-8936-1001fca5a90e.png)

**Notes:**

- Before enabling the "Hide My Personal Files from Other Users" option, administrators can still access your personal folder in the "Files".

- Once enabled, other users, including administrators, will not be able to access your personal folder in the "Files".

## **Usage Tips:**

- Only the folder's owner and administrators can access the personal folder contents, ensuring data security and privacy.
- Administrators can only enable or disable "Full Control" for their own administrator account and for ordinary user accounts. They cannot control the permissions of other administrator accounts.
- Once Full Control" is enabled, other users will be unable to access your personal folder, enhancing privacy protection.
