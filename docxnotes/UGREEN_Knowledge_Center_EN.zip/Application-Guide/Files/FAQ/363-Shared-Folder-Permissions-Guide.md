# Shared Folder Permissions Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzYzIn0=

**Applicable Version**: UGOS Pro 1.15.0.0114 and aboveScreenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## Differences Between Deny access, Read & Write, and Read only Permissions

Shared folder permissions include **Deny access**, **Read & Write**, and **Read only**. If no permission is assigned, it defaults to **Empty**.

| Permission | Description |
| --- | --- |
| Deny access | Prevents the user or user group from reading or modifying files in the shared folder. |
| Read & Write | Allows the user or user group to read and modify files in the shared folder, including uploading, creating, editing, deleting, and renaming files. |
| Read only | Allows the user or user group to read files in the shared folder but prevents any modifications. |
| Unassigned (Empty) | If no permission is assigned: Administrators default to Read & Write, and standard users default to Deny access. |

## Permission Logic Explanation

In shared folder permission settings, **Parent permission** refers to the permission set by the parent folder (upper-level folder) for the current user or user group. **Self permission** refers to the permission set directly on the current folder for the user or user group. By default, permission settings apply to the current folder, its subfolders, and files. If self permission is unassigned, it **inherits** the parent permission; If self permission is modified, the final effective permission is determined by combining parent and self permissions.

### 1 Permission Categories

● **Explicit permission**: Permission directly set on a folder or assigned individually to a folder.

● **Inherited permission**: Permission inherited from the parent folder.

### 2 Permission Conflicts

● **Conflict**: When either the parent permission or self permission is "**Deny access**", it is considered a conflict (Example: Parent is Read only or Read & Write, self is Deny access).

● **No conflict**: Both parent and self permissions are not "**Deny access**" (i.e., both Read only or Read & Write), in this case, permissions are additive.

### 3 Priority Rules

Case 1:**Conflicts between explicit permissions or between user and user group permissions**

Priority order: **Deny access>Read only>Read & Write>Empty**(unassigned)

Case 2: **Explicit permission vs. inherited permission**

Explicit permission takes precedence over inherited permission.

Case 3: **Combining Explicit and Inherited Permissions**

If a conflict occurs, "**Deny access**" takes precedence:

● Parent is Deny access and self permission is Read & Write → the effective permission will be **Deny access**.

If there is no conflict, permissions are combined, with self permission taking priority:

● Parent is Read & Write and self permission is Read only → the effective permission will be **Read only**.

● Parent is Read only and self permission is Read & Write → the effective permission will be **Read & Write**.

● Parent is Read only and self permission is Read only → the effective permission will be **Read only**.

## Permission Requirements for Various File Operations in Shared Folders

Different file operations in a shared folder require different permissions. The following table lists common file operations and the permissions needed:

| No. | File Operation | Required Permission on Source | Required Permission on Destination |
| --- | --- | --- | --- |
| 1 | Upload | Read & Write | Read & Write |
| 2 | Download | Read only or Read & Write | Read & Write |
| 3 | Open | Read only or Read & Write | / |
| 4 | Delete | Read & Write | / |
| 5 | Copy | Read only or Read & Write | Read & Write |
| 6 | Move | Read & Write | Read & Write |
| 7 | Cut | Read & Write | Read & Write |
| 8 | Rename | Read & Write | / |
| 9 | Decompress Files | Read only or Read & Write | Read & Write |
| 10 | Compress Files | Read only or Read & Write | Read & Write |

## Explanation of Shared Folder Permission Settings

When parent folder permissions and self (current folder) permissions differ, the actual operations allowed are as follows:

| Permission Combination | Supported File Operations |
| --- | --- |
| Parent (Read & Write) + Self (Read & Write) | Copy, Paste, Cut, Rename, Delete, Open, Upload, Download, Copy to, Move to, Paste-Overwrite, Add to compressed file, Compress to, Decompress, Decompress to |
| Parent (Read & Write) + Self (Read only) | Copy, Open, Download, Copy to |
| Parent (Read & Write) + Self (Deny access) | No file operations allowed |
| Parent (Read only) + Self (Read & Write) | Copy, Paste, Cut, Rename, Delete, Open, Upload, Download, Copy to, Move to, Paste -Overwrite, Add to compressed file, Compress to, Decompress, Decompress to |
| Parent (Read only) + Self (Read only) | Copy, Open, Download, Copy to |
| Parent (Read only) + Self (Deny access) | No file operations allowed |
| Parent (Deny access) + Self (Read & Write) | No file operations allowed |
| Parent (Deny access) + Self (Read only) | No file operations allowed |
| Parent (Deny access) + Self (Deny access) | No file operations allowed |

**Note**: Pasting requires a prior copy or move operation. Operations like "Paste" and "Decompreess to" also depend on whether the destination folder grants sufficient permissions.

## Conflicts Between User and User Group Permissions

When a standard user has both individual permissions and belongs to a user group with assigned permissions, the effective permission is determined according to the following priority: **Deny access>Read only>Read & Write>Empty**.

The table below shows all possible combinations for reference:

| User Individual Permission | User Group Permission | Effective Permission |
| --- | --- | --- |
| Deny access | Deny access | Deny access |
| Deny access | Read only | Deny access |
| Deny access | Read & Write | Deny access |
| Deny access | Unassigned | Deny access |
| Read only | Deny access | Deny access |
| Read only | Read only | Read only |
| Read only | Read & Write | Read only |
| Read only | Unassigned | Read only |
| Read & Write | Deny access | Deny access |
| Read & Write | Read only | Read only |
| Read & Write | Read & Write | Read & Write |
| Read & Write | Unassigned | Read & Write |
| Unassigned | Deny access | Deny access |
| Unassigned | Read only | Read only |
| Unassigned | Read & Write | Read & Write |
| Unassigned | Unassigned | Deny access |

**Notes:**

● When individual permissions conflict with user group permissions, the priority order is **Deny access>Read only>Read & Write>Empty**.

● If a user belongs to multiple groups and the groups' permissions conflict, the same priority rule applies among the group permissions.

● When accessing shared folders via SMB, the effective permissions reflect the logged-in user's permissions, consistent with the Files app.

● When accessing shared folders via NFS, the effective permissions follow the NFS configuration settings.

### Example

Assume there is a standard user "user1", which belongs to three groups, group1, group2 and group3.

**Note: Administrators default to Read & Write if no permission is set; standard users default to Deny access if no permission is set.**

**The folder structure is as follows:**

![](https://file1-cn.ugnas.com/admin/article/2026-05-12/6d9a212001a74607bd84ed2f7ccab4b1.webp)

| Scenario | Settings & Results | Permission Logic |
| --- | --- | --- |
| Explicit and Inherited Permission Conflict | Suppose the permissions for " Shared folder A " are set as follows: ● group1: Deny access ● group2: Read & Write ● group3: Read only Since user 1 belongs to all three groups, the highest-priority permission is determined by the order Deny access>Read only>Read & Write . Therefore, user1 's effective permission for " Shared folder A " is Deny access . | Permissions set directly on the Shared folder are considered explicit permissions. When multiple group permissions conflict, the system applies the priority: Deny access>Read only>Read & Write>Empty . |
| If a " Subfolder B " is created under " Shared folder A ", and none of the three groups have individual permissions set (all unassigned): Subfolder B has no explicit permissions and inherits from its parent. User1 's effective permission for Subfolder B is still Deny access . | When a subfolder has no permissions specified, it automatically inherits the parent folder's permissions. |  |
| If Subfolder B 's permissions are individually modified and user1 's personal permission is set to Read only : User1 now has an explicit permission (Read only) on Subfolder B, while the inherited parent permission is Deny access. Following the "Deny access priority rule," user1's effective permission on Subfolder B remains Deny access . | If either the parent permission or the explicit permission is " Deny access ", this is considered a conflict, and " Deny access " takes precedence. |  |
| No Conflict Between Explicit and Inherited Permissions | Suppose the permissions for " Shared folder A " are set as follows: ● group1: Unassigned ● group2: Read only ● group3: Unassigned The highest group permission for user1 is Read only, so user1's effective permission for "Shared folder A" is Read only . | The user group permission is Read only, and the user's effective permission inherits the group permission as Read only. |
| If a "Subfolder B" is created under "Shared folder A", and no permissions are individually set. Subfolder B inherits permissions from the parent folder. User1's effective permission remains Read only . | When a subfolder has no explicitly set permissions, it inherits permissions from the parent folder. |  |
| If Subfolder B's permissions are individually modified and user1's personal permission is set to Read & Write. The inherited permission is Read only, and the explicit permission is Read & Write. Since there is no conflict, the permissions are combined according to the additive rule. UserB's effective permission becomes Read & Write . | When there is no conflict, permissions are combined; if Read only and Read & Write are combined, the final effective permission takes the explicit (self-assigned) permission (Read & Write). |  |
