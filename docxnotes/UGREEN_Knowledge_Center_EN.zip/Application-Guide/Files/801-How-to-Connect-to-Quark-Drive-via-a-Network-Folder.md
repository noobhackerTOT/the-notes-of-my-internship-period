# How to Connect to Quark Drive via a Network Folder?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODAxIn0=

## Overview

The Network Folder feature allows you to mount your Quark Drive on the NAS, enabling convenient file management and seamless file transfers.

## Connection Steps

1. Open the "**Files**" application, click the "**+**" button on the top toolbar, and select "**Connect to network folder**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/4cc21f7976e24dc9bbea5c354053701f.webp)

2. On the network folder connection screen, select "**Quark Drive**" and click "**OK**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/3e499c86991b402fbdb61d9dae13a57f.webp)

3. In the authorization prompt that appears, click "**Allow**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/48c32cb9b2bd479c8eef95b2ec5eaa40.webp)

4. Use the "**Quark App**" to scan the QR code or log in with your mobile phone number.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/2eee203dd6dc424e9c409b462b493d43.webp)

5. After a successful login, the file directory of your Quark Drive will automatically load and appear in your network folder list.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/7a045022f6be4496be3bc1b7a78525d6.webp)

## Supported Features

Once connected, you can manage cloud drive data just like local files:

● Upload, download, delete, rename, and perform other standard file operations on cloud drive files.

● The network folder integrates with the Vault feature. You can move files from the cloud drive into the Vault for encryption or remove encrypted files from the Vault back to the cloud drive.

## Vault and Cloud Drive File Transfers

### Moving Cloud Drive Files into the Vault

**Steps:**

1. Open the "**Files**" application and click "**Network Folder**" in the left sidebar.

2. Enter the connected Quark drive, locate the target file, right-click it, and select "**Move to 'Vault'**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/81a725ea188f436092e08365236a4032.webp)

3. In the pop-up window, confirm how to handle files with duplicate names. The system will then move and encrypt the data.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/74aeaf4d7b864b0e81cc3fa4ac5fe40e.webp)

### Moving Files from the Vault to a Network Folder

1. Select the file in the Vault, right-click it, and choose "**Remove from vault**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/a400217615e24b60a80143c2e9ad674c.webp)

2. In the path selection window, select the Quark drive directory under "**Network Folder**" as the destination, and click "**Confirm**" to move the file.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/77decad96097499dbe8d142bae61d4bd.webp)
