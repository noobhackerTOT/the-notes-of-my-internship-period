# Basic File Operations

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTQ2In0=

**Applicable Version**: UGOS Pro 1.11.0.0002 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

The "**Files**" application provides comprehensive and efficient file-handling capabilities, enabling you to easily transfer, organize, archive, and share files.

## Uploading and Downloading

### Uploading Files or Folders

The system offers three convenient upload methods:

● **Method 1: Right-Click Upload**

Select the target folder in the left directory pane, then right-click in the blank area of the right pane and choose "**Upload to ‘XXX’**". Specify the file or folder you wish to upload.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/6b43b9813fd8448ba561c28614026940.webp)

● **Method 2: Toolbar Button**

Navigate to the target folder and click the "**Upload**" button in the upper-left corner of the interface.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/9ea813e884494e46a4dc3c0fbdfb685a.webp)

● **Method 3: Drag-and-Drop Upload**

Drag files directly from your local computer into the desired area within Files. The system allows you to configure the default handling of duplicate filenames during drag-and-drop uploads under "**Settings**">"**General**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/b975ca3521a44331af2a79a3dbaadb8c.webp)

### Duplicate Filename Handling Strategies

● **Overwrite**: Replace the existing file with the same name.

● **Skip**: Keep the original file and cancel the current upload.

● **Keep**: Retain the original file; the new file will be automatically renamed as "**Filename (1)**".

### Downloading Files

● **Operation**: Select one or more files (hold **Shift** or **Ctrl** for multi-selection), right-click, and choose "**Download**".
The files will be saved to your browser’s default download location.

### Task Monitoring and Logs

● **Progress Monitoring**: Click the "**Task Center**" icon in the upper-right corner of the desktop to view real-time transfer progress and speed.

● **Operation Logs**: It is recommended to Check "**Enable file logs**" under "**Files**">"**Settings**">"**General**", allowing the system to record operations such as copying, deleting, and uploading.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/17bcb5fcfd9b4428afcf42e5fb5fa4aa.webp)

## File Management

### Renaming

**Single Rename**: Right-click a file and select "**Rename**" icon, or select the file and click the "**Rename**" button on the toolbar.

**Batch Rename**:
After selecting multiple files, choose **"Rename"**. The system provides several quick modes:

● **Find/Replace**: Batch-replace specified characters in filenames.

● **Number Format**: Apply a unified numeric sequence to filenames.

● **Add content**: Append or prepend characters to filenames in bulk.

● **Edit manually**: Quickly edit filenames individually within the list.

**Note**: Filenames support a maximum length of 255 bytes and must not contain illegal characters.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/2bc1c53363c94c299dbaf53b194144a7.webp)

### Copying and Moving

**Operation Methods**:

● **Menu Operations**: Select files and use the toolbar or right-click menu to choose "**Copy/Cut**" icon, then navigate to the target location and select "**Paste**".

● **Keyboard Shortcuts**: Supports standard shortcuts on Windows (Ctrl+C/X/V) and macOS (Command+C/X/V).

● **Direct Destination Selection**: Right-click and choose "**Copy to**" or "**Move**", then select the target location directly from the directory tree in the pop-up window.

**Notes**:

● **Within the Same Voulme**: Extremely fast; only logical path changes are involved.

● **Across Different Voulme**: Slower, as physical data transfer is required. For large files, batch operations are recommended.

### Deletion and Restoration

● **Delete**: Select files and right-click to choose "**Delete**" icon.

● **Recycle Bin**: If the [Recycle Bin](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmMTU5In0=)feature is enabled for the shared folder, deleted files can be restored from the "**Recycle Bin**" directory; otherwise, the files will be permanently deleted.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/e4784328945c46c4bfd5dc5d49299f13.webp)

### File Properties

Select a file, right-click, and choose "**Properties**" to view detailed information such as file size, disk usage, MD5 value, modification time, and owner.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/232341e117704bf4b52de342f6e686ec.webp)

## Tagging Files or Folders (Color Labels)

You can assign color labels to files or folders via the right-click menu to visually categorize content. Clicking a specific color in the left navigation pane allows you to quickly filter and locate all labeled items.

### Adding Labels

You can tag files or folders by following these steps:

1. Select one or more files or folders in the file list.

2. Right-click and choose a color label from the context menu.

3. Once applied, the corresponding color indicator will appear next to the file or folder immediately.

**Notes**:

● Multiple labels can be applied simultaneously and can be cleared at any time.

● Labels only affect visual identification and do not alter the file itself or its storage path.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/65ad55c7f7f2438a8e8347ea19335f55.webp)

### Filtering Files by Label Color

When managing a large number of files, labels provide a fast way to locate content:

1. In the "**Files**" interface, click "**Tag**" in the left navigation pane.

2. Under the "**Tag**" category, click a specific color icon. The system will display all files tagged with that color in a consolidated view.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/44ebe6026fe04c0ebd9614b46d9f2e80.webp)

## Compression and Extraction

### Compressing Files

**Operation**: Select files or folders, right-click, and choose "**Compress as...**".
Select "**Add to compressed file**" to access advanced options. The system supports **.zip** and **.7z** formats and allows you to set a compression password and filename encoding to prevent garbled text.

### Decompression

The system supports common formats including **.zip, .7z, .rar, .tar, and .iso**.

**Decompression Methods**:

● **Decompress**: Unpacks files directly to the current directory, with options for "**Decompress part**" or "**Decompress all**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/48df2e5bb2cf401097864888cc778ddb.webp)

● **Decompress to**: Specify a custom destination path for the extracted files.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/b53d2f1940b8469e9a092669de3ee422.webp)

● **Batch Decompression**: Select multiple archives to extract them simultaneously.

**Filename Encoding Issues**: If filenames appear garbled after decompression, adjust the "**Code Page**" option in the decompression dialog (for example, select "**Unicode**" or "**GBK**").

## Online Preview

The NAS provides online preview capabilities for multiple file formats. You can double-click a file to view its contents directly without downloading:

● **Documents**: Supports PDF, TXT, and source code files.

● **Media**: Supports image previews such as JPG and PNG, as well as streaming playback for videos like MP4 and MKV.

● **Archives**: Allows you to open compressed files and browse their internal directory structure.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/8283cf2f3706467dbd0bc515f4f111b2.webp)
