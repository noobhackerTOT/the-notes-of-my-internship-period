# Mount Quark Drive on UGREEN NAS to Expand Local Storage and Build a Home Theater

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODE1In0=

UGREEN NAS supports mounting Quark Drive as local NAS storage, allowing you to expand storage capacity flexibly without manually downloading cloud files. In addition, the mounted cloud drive can be added to the Theater app to automatically generate a poster wall, significantly enhancing your viewing experience and meeting both storage and entertainment needs.

## Using the Cloud Drive in "Files"

After mounting, you can directly view and manage files from Quark Drive within the "**Files**" app. If you want to watch videos stored in the cloud drive, simply click to play—no need to download them to the NAS in advance.

1. Open the "**Files**" app, then click "**+**" in the top toolbar>"**Connect to network folder**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/6256aa0ce00c40569256a5c7e587b769.webp)

2. In the connection window, select "**Quark Drive**" and click "**OK**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/a3d1228d4b7b4f0da00ce2953239ac48.webp)

3. The system will open a login and authorization page in your browser. Use the corresponding mobile app to scan the QR code and confirm authorization.

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/0ea702df7d844d6b9383d765b6d7206a.webp)

4. Once authorized, the cloud drive content will automatically load into the network folder list.

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/c3bbf3419e7f4bae9c6ca75cac124a71.webp)

## Generating a Poster Wall in "Theater"

You can add the mounted cloud drive directory to the "**Theater**" app and manage it as your media library.

**Steps**:

1. Open the "**Theater**" app and click "**Settings**" icon at the top to enter the settings page.

2. In the left sidebar, click "**Library**", then click "**New library**" on the right.

3. In the pop-up window, set a name for the new library, and select the mounted cloud drive directory as the media"**Folder**".

4. Click "**Apply**" to complete the setup.

After adding, the "**Theater**" app will automatically scan and identify video files in the cloud drive. It will fetch corresponding posters from online sources and generate a visually rich poster wall. You can click any item to play the video directly.

## How to Update Media Library Content

When new videos are added to the mounted cloud drive, the Theater media library does not update in real time. To display new content, you can update the library manually or set up scheduled scans.

### Method 1: Manual Scan

If you want newly added videos to appear immediately, use manual scanning:

1. Go to "**Settings**" in the Theater app and click "**Library**".

2. Find the target library, click the "**···**" icon on the right, and select "**Scan**".

3. Choose "**Scan newly added and modified content**" to update content.

To rescan the entire directory, select "**Scan and replace all**", though for daily use, "**Scan newly added and modified content**" is recommended to save time.

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/6ee97de933b74dbfb89b4f5f35e82d1e.webp)

### Method 2: Scheduled Scan

If you prefer automatic updates in the background:

1. Go to "**Settings**" in the Theater app and click "**Background Management**".

2. Enable "**Scheduled library scan**".

3. Select the target media library and set the scan schedule. The system will then automatically scan and update content based on your configured schedule.

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/c3890daff1d54b29be3e251c3fd38311.webp)

## Notes

Please note that poster retrieval depends on external metadata sources:

● **Matching requirement**: The video file name must be searchable and match results on the TMDB website. Only then can the system successfully fetch and display posters.

● **Unavailable cases**: If the video is self-recorded or not listed on TMDB, the system cannot retrieve poster data. In such cases, only a default video icon will be displayed.
