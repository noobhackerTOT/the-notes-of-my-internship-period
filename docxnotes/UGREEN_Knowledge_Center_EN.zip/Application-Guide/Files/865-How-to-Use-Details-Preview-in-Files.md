# How to Use Details Preview in Files?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODY1In0=

## Applicability

**Applicable client:**UGREEN NAS PC client (Windows/macOS) and web browser.

**Applicable version:**NAS firmware 1.16.0.0042 or later.

The descriptions in this article are for reference only. The actual interface and operation paths may vary slightly due to system or app version updates. Please refer to the actual interface.

## Feature Overview

The new file details sidebar in**Files**lets you view key file information at a glance while browsing your file list, without having to repeatedly right-click files to check their properties. You can also rename files and quickly add tags directly from the sidebar.

## Immersive Continuous Browsing

The details panel stays open and updates as you browse, making it useful for organizing files in batches:

● **Seamless real-time switching:**As long as you do not turn off**"Details"**in the top bar, the panel on the right will update automatically when you select a different file from the file list on the left.

● **Collapse with one click:**When you no longer need to preview file information and want more space for the file list, click**"Details"**in the top bar again to collapse the panel and turn off this feature.

## Open the Details Sidebar

1. Sign in to the UGREEN NAS desktop and open "**Files**".

2. In the file list, select the file or folder you want to view.

3. Click "**Details**" on the right side of the top bar.

![](https://file1-cn.ugnas.com/admin/article/2026-06-01/12acd2cd6aba4722acdd37a2fe02633f.webp)

4. A details panel will open on the right, showing the file’s format, size, modified time, and other properties clearly.

![](https://file1-cn.ugnas.com/admin/article/2026-06-01/7afdda9d49a54e9785485d7807dea913.webp)

## Quick Editing in the Details Panel

In the details panel on the right, you can use two quick management options:

● **Quick rename:**Click**the file or folder name**in the details panel to edit it. After making changes, click anywhere blank or press "**Enter**" to save.

● **Quick tagging:**In the "**Tags**" section of the panel, click to quickly add or remove tags for the file, making it easier to find later through global category search.

![](https://file1-cn.ugnas.com/admin/article/2026-06-01/5e8d3744a51d4fd586f8b7677b59f966.webp)
