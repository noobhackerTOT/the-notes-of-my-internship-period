# How to Mount an Amazon S3 Bucket?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODYxIn0=

## Applicability

**Applicable client:**UGREEN NAS desktop client (Windows/macOS)

**Applicable version:**NAS firmware 1.16.0.0042 and later

This document is for reference only. The actual interface and operation paths may vary slightly due to system or app version updates. Please refer to the actual interface.

## Overview

UGREEN NAS lets you mount an Amazon S3 bucket using the "Cloud Drives" app. Once mounted, files in the S3 bucket can be accessed and managed just like local NAS files, without the need to download them from the cloud or transfer them back and forth.

## Preparation

Before you start mounting the bucket, log in to the AWS (Amazon S3) Management Console and prepare the following information:

● **Bucket Name**: The name of the bucket.

● **AWS Region**: The AWS Region where the bucket is located.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/93538d223e2243edb32d6ec46e691b80.webp)

● **Access Key**: The access key of the IAM user.

● **Secret Access Key**: The secret access key of the IAM user. This key can only be viewed and copied when it is created, so keep it safe.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/fe174655ad484270a3c24a5bcf5bde6d.webp)

## Add an S3 Connection in Cloud Drives

1. Open the**"Cloud Drives"**app from the UGREEN NAS desktop.

2. Click**"+ New connection"**in the sidebar.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/963288b855704189b3f4641e6d2b9d0f.webp)

3. In the cloud drive type list that appears, select "**Amazon S3**", then click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/aa8288061dab4f40b810b9409c97c037.webp)

4.In the configuration window, fill in the following parameters:

● **Server**:**"Amazon S3"**is selected by default. If your bucket is deployed in a Chinese mainland Region, select**"Amazon S3 China"**from the drop-down menu.

● **Access Key**: Enter the access key you obtained.

● **Secret Key**: Enter the corresponding secret access key.

● **Bucket**: Select the target bucket you have created from the drop-down list, or click**"New bucket"**.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/a3497c25b8e741a7b528638b2f5cc8ac.webp)

5.Click**"Connect"**.

6. Once connected, the Amazon S3 bucket will appear as a separate directory in the cloud drive connection list in the app sidebar.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/ed600939769142b79ba526451540c569.webp)

## Unmount or Delete a Cloud Drive Connection

If you no longer need to connect to the S3 bucket, you can delete it from the system at any time. This only disconnects the bucket and does not delete any files stored in Amazon S3.

1. In the connection list in the sidebar of the**"Cloud Drives"**app, find the Amazon S3 cloud drive you want to remove.

2. Hover over the cloud drive name, click the**"···"**icon that appears on the right, and select**"Delete"**.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/0eb99617a60942848657dacf8d201f2a.webp)

3. In the confirmation window, click "**Delete**" to confirm.

## Manage Files in Amazon S3

After Amazon S3 is mounted successfully, you can use**"Cloud Drives"**to transfer data between your NAS and Amazon S3. In addition to basic manual uploads and downloads, the system also supports automatic sync and log tracking.

### Upload NAS Files to Amazon S3

1. In the connection list on the left side of**"Cloud Drives"**, click the mounted Amazon S3 cloud drive.

2. In the main area on the right, find the**"Upload to Cloud Drive"**section and click**"Select file"**.

3. In the configuration window, set the save path and storage class:

● **Save path on the Cloud Drive**: Specify where the files will be stored in Amazon S3.

● **Storage class**: Select the required S3 storage class from the drop-down list.

**Note**: Click the**"ⓘ"**icon next to an option to view a brief description of each storage class.

4. After confirming the save path and storage class, click**"Select file"**.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/7555d9e9c23044749b17e1fb4e6ca81f.webp)

5. In the file picker that appears, select the files on your NAS that you want to upload, then click**"Confirm"**to start the transfer.

You can track the progress in the**"Upload"**list in the top bar.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/3e15803a179f4910946396705f2b056d.webp)

### Download Files from Amazon S3 to NAS

1. In the connection list of**"Cloud Drives"**, click the mounted Amazon S3 cloud drive.

2. In the main area on the right, find**"Download to NAS"**and click**"Select file"**.

3. In the download window, select the cloud files you want to retrieve from S3, then click**"Next"**.

4. In the location selection window that appears, choose a destination folder on your local NAS, then click**"Confirm"**to start the download.

You can track the progress in the**"Download"**list in the top bar.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/c8b6766e04e946fc80fa86c858676957.webp)

### Sync Cloud Drive with NAS

To keep a NAS folder and the S3 cloud data in sync over time, you can create a sync task:

1. In the connection list of**"Cloud Drives"**, click the mounted Amazon S3 cloud drive.

2. In the main area on the right, find**"Sync Cloud Drive with NAS"**and click**"Create sync task"**.

3. In the sync task creation window, set the sync rules. When finished, click**"Next"**.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/a3d7d6ac25d24a32b87ae0d22b1910fb.webp)

● Select the "**Cloud Drive path"**and "**NAS path**".

● Select the "**Sync direction**".

● Select the "**Storage class**".

● **Advanced settings (optional)**: In "**Advanced settings**", you can configure "**File filter**" rules, such as excluding specific file formats, and set how files should be overwritten when a file conflict occurs.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/10d806cefe42499d932b3cd9da159570.webp)

4. Set the sync**Strategies**, then select**"Manual synchronization"**or**"Scheduled synchronization"**. When finished, click**"Next"**.

If you select "**Scheduled synchronization**", you need to set the sync frequency and the first start time.

5. Enter a name for the task, then click**"Confirm"**to finish creating it. To run the task immediately, select**"Sync immediately after creation"**.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/2464dd2005744003a4f122ce1c5ef0a0.webp)

### Manage Existing Sync Tasks

1. In the connection list of**"Cloud Drives"**, click the mounted Amazon S3 cloud drive.

2. In the top bar of the main area on the right, click**"Sync task"**to open the sync task list.

3. Find the target task. You can click**"Sync now"**to run it manually.

4. Click "**More**" on the right, then select "**Edit**" to update the sync rules, or select**"Delete**" to remove the task.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/0955b6d30dcb478997dab2b26037342c.webp)

### View Cloud Drive Logs

To help troubleshoot transfer errors or review user actions, the system automatically records all operations related to the cloud drive.

1. On the main cloud drive page, click**"Log records"**in the top bar.

2. On the log page, use the tabs at the top to switch between**"File transfer records"**and**"Action log records"**.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/c9498c95b90c4862b019298b11302706.webp)

3. You can use the search box to find specific records. You can also click**"Export"**to save the records as a local file, or click**"Clear"**to remove records.

![](https://file1-cn.ugnas.com/admin/article/2026-05-27/7ae8865d8068442c9d6ab689d53dce6a.webp)

## FAQs

1. **How to resolve a "Permission error" when mounting fails?**

Go to the AWS console and check whether the entered "Access Key" is correct. If the settings are correct but the error persists, contact Amazon Support for help checking the account permissions.

2. **Why is access to files in the S3 bucket slow?**

Read and write speeds in "Cloud Drives" are highly dependent on the current network environment. For the best experience, choose an S3 bucket Region that is geographically closest to the NAS location.

3. **How to update AWS credentials on NAS after they are changed in AWS?**

The current version does not support updating credentials for an active connection. To use new credentials, delete the existing connection by following the steps in "Unmount or Delete a Cloud Drive Connection", then click "+ New connection" and add it again with the new "Access Key" and "Secret Key".

4. **What determines file operation permissions after mounting?**

Permissions for browsing, copying, moving, deleting, renaming, and downloading files in S3 through "Cloud Drives" depend on the S3 bucket policy in AWS and the permissions assigned to the IAM account. If deleting or writing files fails, check the permission settings in the AWS console first.
