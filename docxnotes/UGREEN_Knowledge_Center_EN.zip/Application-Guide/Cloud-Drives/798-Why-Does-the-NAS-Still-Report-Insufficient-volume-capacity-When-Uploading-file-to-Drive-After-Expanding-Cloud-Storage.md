# Why Does the NAS Still Report "Insufficient volume capacity" When Uploading file to Drive After Expanding Cloud Storage?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzk4In0=

## Problem Description

When uploading files from the NAS to a cloud drive, the upload fails and the system displays the message "**Insufficient volume capacity**". After the user logs in to the cloud drive and upgrades the volume, the same error message continues to appear when attempting to upload files from the NAS.

![](https://file1-cn.ugnas.com/admin/article/2026-01-21/1d4ea66b1cb944049f90ccf43467fe8e.webp)

## Cause Analysis

This issue is caused by "**cached capacity information**". When the NAS mounts a network folder, it retrieves the current volume status. If the volume is expanded on the cloud drive side, the NAS does not immediately synchronize the updated capacity information. As a result, the system continues to determine that the volume is full based on the previous capacity limit.

## Solution

To synchronize the latest capacity information, you need to "**disconnect and reconnect**" the network folder to force a refresh of the mount status.

**Steps**:

1. Open the "**Files**" application and click "**Network Folder**" in the left navigation pane.

2. Locate the target cloud drive icon, right-click it, and select "**Disconnect**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-21/daa264e77d0f423080c04388d4078686.webp)

3. After the status refreshes, right-click the cloud drive icon again and select "**Reconnect**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-21/2835a182ec574b9cb838de44983f82df.webp)

Once the reconnection is successful, the system will retrieve the latest capacity information. You can then try uploading the files again.
