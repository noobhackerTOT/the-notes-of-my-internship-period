# Cloud Drives

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzc2In0=

## Feature Overview

**"Cloud Drives**" is a cross-platform file management application provided by UGREEN NAS. It supports uploading, downloading, and synchronizing files between the NAS's internal storage and various third-party cloud drives. With this application, users can easily transfer files between the NAS and mainstream cloud storage services, enabling seamless file sharing, synchronization, and backup across multiple platforms.

## Installation and Access

1. Open "**App Center**", find "**Cloud Drives**" in the app list

2. Click "**Install**" to start the installation wizard, and follow the on-screen instructions to complete the setup.

3. Once installed, you can access the app by clicking the **"Cloud Drive"** icon on the UGREEN NAS desktop or in "**My apps**".

## Overview Page

On the "**Overview**" page, you can view the status of drives, your personal device connection information, and other users' device connection information (visible to administrators only).

**Note:** Information about other users' devices includes connection name, user, status, and the option to delete connection.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/ef8180f07af546fc990bea340b79b488.webp)

## Adding Cloud Drive

Cloud Drives supports multiple cloud services, including Baidu Netdisk, Aliyun Drive, Quark Drive, 115 Drive, Microsoft OneDrive, Google Drive and more.

**Steps:**

1. Click **"New connection" or "Create"**, select the desired cloud drive in the pop-up window, and click **"Next"**.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/7dce53a490ce4ba0860fb043bc511133.webp)

2. The system will open the login page for the selected drive. Complete login as instructed.

3. After a successful login, the cloud drive will be automatically added to the "**Cloud Drives**", allowing users to view and manage it directly.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/73384822b15f4598bfea23ce1469c1b8.webp)

● **View cloud drive status**: Open the "**Cloud Drives**", and under "**Cloud Drive Connection**" in the left panel, select your personal cloud drive to view its connection status and storage usage.

● **Manage connected cloud drives**: Click the "**…**" button on the right side of the cloud drive, select "**Management**", and customize the "**Polling period**" for the connected cloud drive.

● **Remove a connected cloud drive**: Click the "**…**" button on the right side of the cloud drive and select "**Delete**" to remove the connection.

**Note**:

● Each cloud drive account can only be connected to one user on the NAS.

● If multiple users attempt to add the same account, subsequent connections will fail.

● The "**Polling Period**" determines how often the NAS checks the cloud drive for file changes. When polling is enabled and a period is set, the NAS sends a request to the cloud drive server at the specified interval. If file changes are detected, the NAS starts synchronization (download or update). If no changes are detected, the NAS remains idle until the next polling cycle.

## Uploading NAS Files to a Cloud Drive

1. In Cloud Drives, select the target drive and go to the "**Connect**" page.

2. Click "**Upload to Cloud Drive**">"**Select file**" to open the upload settings window.

3. Choose the save path in the cloud drive and click "**Select file**".

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/62f0027cf03b49069844ea96a6d9f4c5.webp)

4. Select the files or folders on UGREEN NAS, then click **"Confirm"** to start uploading. Users can monitor task progress under the **"Upload"** tab and view historical upload tasks in **"Log records"**.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/756a7550ec934dd581fcc064fe2d7c3c.webp)

**Note:** If uploading files to the cloud drive fails, the possible reasons include:

● **Network issues**: Please check whether your network connection is functioning properly.

● **Permission issues**: Please ensure that you have sufficient permissions for the selected files and folders to perform the upload operation.

## Downloading Cloud Drive Files to NAS

1. On the **"Connect"** page of the target drive, click "**Download to NAS**"**>**"**Select file**".

2. Select the desired files or folders from the cloud drive and click **"Next"**.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/ee64e8a0808741569f23255514cf3071.webp)

3. Set the save path on your UGREEN NAS and click **"Confirm"** to start the download.

4. You can view task progress on the **"Download"** page and view historical tasks on the **"Log records"** page.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/e40d230cfbe144f6bfed35e0f735a2ac.webp)

## Creating Sync Task

● **Supported cloud drives for synchronization**:

Aliyun Drive, 115 Drive, Microsoft OneDrive, Baidu Netdisk, and Google Drive.

● **Supported synchronization directions**:

**Two-way sync**: Files are synchronized bidirectionally between the cloud drive and UGREEN NAS. Any changes on either side (such as adding, modifying, or deleting files) will be reflected on the other side.

**Sync cloud drive files to UGREEN NAS only**: Files are synchronized from the cloud drive to UGREEN NAS only. If a file is deleted from the cloud drive, the corresponding file in UGREEN NAS will also be deleted.

**Sync UGREEN NAS files to cloud drive only**: Files are synchronized from UGREEN NAS to the cloud drive only. If a file is deleted from UGREEN NAS, the corresponding file in the cloud drive will also be deleted.

● **Supported synchronization modes**:

**Real-time sync**: Enables automatic real-time file synchronization, but consumes relatively more system resources.

**Manual sync**: File synchronization occurs only when "**Sync now**" is manually clicked. Enabling manual sync helps reduce computing resource usage and server load.

**Scheduled sync**: Files are synchronized automatically at regular intervals based on a predefined schedule. When this option is selected, you can click "**New plan**" to configure the sync frequency (Every day / Every week / Every month / Once / Customize) and the start time.

### Creating Two-Way Sync Task

To keep files in the cloud and on your NAS fully synchronized (including additions, modifications, deletions, and moves), please follow these steps to create a sync task:

1. On the **"Conect"** page, click **"Sync Cloud Drives with NAS">"Create sync task"** to open the setup wizard.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/b6fa0fab930c40aaaf50a9affe40e8bb.webp)

2. Configure the sync rules by selecting the cloud drive path and the NAS path, and set the sync direction to **"Two-way sync"**.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/8965cf4158514060a0d9e6131310efe0.webp)

3. In **"Advanced settings"**(optional), you can precisely select subfolders for synchronization, configure file filtering rules, and define how filename conflicts are handled. After completing the settings, click **"Next"**.

**Description:**

● **Sync folder**: Select the remote folders to be synchronized. (Files and folders with names starting with "**.**" usually indicate hidden files and hidden folders.)

● **File filter**: You can prevent specific files from being synchronized by setting a maximum file size or by specifying file names or file extensions. This helps save storage space and ensures efficient use of cloud storage. In addition, you can click **"Add"** to create additional filtering rules.

● **File conflict**: Select how file conflicts should be handled when they occur (rename conflicting files or overwrite existing files).

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/8e50e5e2a97e49c08ea61a2f3657897f.webp)

4. After configuring the synchronization policy, click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/a3167af187604038b4fd94182e4970c4.webp)

5. Review the task settings. If everything is correct, click "**Confirm**" to create the task. Created tasks can be viewed and managed on the "**Sync task**" page.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/6b568404489240c2ac13ec90b8ad7b07.webp)

### Creating One-Way Sync Task

If you want to enable one-way synchronization between the cloud drive and the NAS (including file additions, modifications, deletions, and moves), please create a sync task by following the steps below:

1. On the **"Connect"** page, click "**Sync Cloud Drives with NAS**">"**Create sync task**" to open the setup wizard.

2. Set sync rules by selecting the cloud path, NAS path, and choosing "**Sync only data changes from the cloud storage and the NAS**" or "**Sync only data changes from the NAS to the cloud drive**". Click "**Next**" after setting.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/3b524614e26445bfa26bbf6ba53252aa.webp)

3. Set a sync strategy and Click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/b41a2c74e6b54e6b80c8c44d11bf2aed.webp)

4. Review the task settings. If everything is correct, click "**Confirm**" to create the task. The created task can be viewed and managed on the "**Sync task**" page.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/87715faa8a8144e9871fb22822c4478a.webp)

**Note:** When the synchronization mode of a sync task is set to "**Real-time Synchronization**", to prevent missed synchronizations caused by network fluctuations, you can enable the "**Polling period**" feature (on the "**Connection**" page, click the "**…**" button next to the cloud drive and select "**Management**"). This allows the system to periodically perform a full comparison of file lists. Please note that enabling the polling interval may affect hard drive hibernation.

### View Sync Task Progress

After creating a sync task, you can view detailed progress and synchronization status on the "**Sync task**" page.

● **Add a new sync task**: Click "**Add**" to create a new sync task.

● **Start a sync task immediately**: If a sync task has not started, click "**Sync now**" to start the synchronization.

● **View sync task details**: Click "**More**" to edit or delete the sync task.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/8aeccc1a6882424dbf59d551081eb379.webp)

**Notes:**

● If you have read-only permission for a remote shared folder, it cannot be set as a synchronization destination.

● When selecting a folder to synchronize, it must not be located in the same directory as another folder that is already being synchronized under the same connection.

● After deleting a sync task, if you want to reconnect, a full resynchronization is required.

## View Logs

On the "**Log records**" page, you can search and view detailed operation logs (including file transfer records and action log records). You can also export logs in TXT, CSV, or HTML format to your local computer.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/42d76bf8b1554f7ea76c6afd97d28c5d.webp)

## Admin Settings

If you are an "**Administrator**", you can enable "**Administraor mode**" in the "**Settings**" section of Cloud Drives. Once enabled, you can view and manage other users' connected drives on the "**Overview**" page.

**Note:**

● Administrator mode is disabled by default and must be manually turned on.

● In administrator mode, if no cloud drive is connected, you will not be able to view other users' cloud drive connections. To view and manage other users' cloud drive connections, please add at least one cloud drive connection first.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/daed1577d9f649d6bb8bc54b13fc918d.webp)

## FAQ

**Q: Unable to connect to Google Drive?**

**A:**Please check whether your NAS network environment can normally access Google services. If network access is restricted, try switching to a different network or reconnecting in an environment where Google services are available.

![](https://file1-cn.ugnas.com/admin/article/2025-12-25/1942a0b7b4c94b03a98eaeb12bf3f3c9.webp)

**Q: Which cloud drives are supported by the Cloud Drives?**

A: The Cloud Drives currently supports the following cloud storage services:

● Baidu Netdisk

● Microsoft OneDrive

● Google Drive

● Aliyun Drive

● 115 Drive

● Quark Drive

● Dropbox
