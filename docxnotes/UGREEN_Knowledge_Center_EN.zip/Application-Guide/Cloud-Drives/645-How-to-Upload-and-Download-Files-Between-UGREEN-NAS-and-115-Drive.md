# How to Upload and Download Files Between UGREEN NAS and 115 Drive

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjQ1In0=

With "**Cloud Drives**", you can easily connect to 115 Drive for fast file uploads and downloads. This is especially useful for data migration, backup, and when replacing your UGREEN NAS device. This guide explains how to connect 115 Drive and transfer data between UGOS Pro and 115 Drive.

## Connecting 115 Drive to UGREEN NAS

1. Open the "**Cloud Drives**" app, tap "**New connection**".

2. Choose "**115 Drive**" from the pop-up list of supported drives, and click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/13bbd3ed43374ba2b678bb4af2b16f5a.webp)

3. You will be redirected to the 115 Drive login page. Use the 115 Life App to scan the QR code and authorize the connection.

Note: If you have not yet downloaded and registered for 115 Drive, please install the app on your phone and complete registration first.

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/5a68ce6811a14e0d8c85acf4d1425144.webp)

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/74ffedcd9dae4b089d2220a22a459f99.webp)

4. Once logged in, return to the "**Overview**" page to view the connection status of 115 Drive.

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/1f0f35b6683243179619e94f58e0605e.webp)

## Uploading Files from UGREEN NAS to 115 Drive

1. Tap the connected 115 Drive to view its current storage usage.

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/a3ec48bd2756496b8ec0e7243002ca6d.webp)

2. On the "**Conect**" page, under "**Upload to Cloud Drive**", click "**Select file**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/c6b6782da6ba414dad7d49773064ede5.webp)

3. Choose the destination path in 115 Drive, then click "**Select file**" again.

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/e848008f9c304ec4b5c258f11005c4ec.webp)

4. In the "**Select file**" window, select the files or folders from "**Files**" on your UGREEN NAS, then click "**Confirm**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/165fe461fb394329b4094a9032bc5a9f.webp)

5. During the upload, you can track progress in the "**Upload**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/3f583cdd383e45f3a7703ddea7dca6b7.webp)

6. Once completed, log in to 115 Drive via the web to confirm the uploaded files in the designated folder.

## Downloading Files from 115 Drive to UGREEN NAS

1. On the "**Connect**" page, under "**Download to NAS**", click "**Select file**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/9816b0e61f894bc7b4f86947512ecfdf.webp)

2. Select the files or folders from 115 Drive, then click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/8740c29735f7483dbc2cb6c2f0fa6652.webp)

3. Set the destination path on UGREEN NAS, then click "**Confirm**" to start the download.

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/3c141b87286f4ba9b0b233326ba93347.webp)

4. During the download, you can monitor progress in the list of "**Download**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/3b1649219c934fb6803bac2fbd3ef452.webp)

5. Once completed, go to "**Files**" on UGREEN NAS to access the downloaded content.

## Setting Up a Data Sync Task Between 115 Drive and UGREEN NAS

1. On the "**Connect**" page, click "**Create sync task**" under "**Sync Cloud Drive with NAS**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/fa9c9b2aa7fb49c6b02eb3c5d285c25f.webp)

2. Configure sync rules:

**Cloud Path:** Specify the folder in 115 Drive (e.g., /picture).

**NAS Path:**Specify the folder on UGREEN NAS (e.g., /Personal Folder/Tiffany/tt).

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/4c7f907b1a3245179c9d85ab9ccda5a0.webp)

Select the sync direction:

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/a70a021d9494458db8fdb5cfde320931.webp)

**Sync only data changes from the cloud storage to the NAS:** Syncs changes from 115 Drive to UGREEN NAS only. By default, deleted files in 115 Drive are not removed from the NAS.

**Sync only the date changes form the NAS to the cloud drive:** Syncs changes from UGREEN NAS to 115 Drive only. By default, deleted files on the NAS are not removed from 115 Drive.

3. Advanced Settings: Set file type filters or exclusions as needed, then click "**Save**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/688c7534e474445787d41a25c5934be8.webp)

4. Sync Strategy: Choose a sync strategy (e.g., Manual Sync), then click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/20c77e26b42d4a21be4624fe647d63bb.webp)

5. Review the task details and click "**Confirm**" to complete the task creation.

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/337922c3814a4c1396796b79cc768d4a.webp)

6. View task progress and status in the "**Sync task**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/4d48cb9434ed4c22b3461bea3268f02c.webp)

## Notes

1. **Network Connection**: Ensure a stable network during file transfers to avoid interruptions or data loss.

2. **Available Storage**: Make sure there is sufficient available storage on both UGREEN NAS and 115 Drive to prevent transfer failures.

3. **Concurrent Task Limitations**：

● Premium users can run up to 3 concurrent tasks.

● Non-premium users are limited to 1 concurrent task.

4. **Upload & Download Speed**:

● Upload speed is approximately **500 KB/s** for both premium and non-premium users.

● Download speed: For Premium users, the download speed is approximately **12 MB/s**, while for non-Premium users, the download speed is approximately **100 KB/s**.

Actual speeds may vary depending on your network environment, server load, and other factors..

5. **File Size Limits**: Maximum file size limits depend on the user's membership tier. Refer to the 115 Membership Center for details.

6. **Rate Limiting**: Under certain conditions, 115 Drive may apply rate limits causing task failures. If this occurs, please retry the operation.

The above information is for reference only. Please refer to the official 115 Drive documentation for the latest details.

7. Why Are Some Files Missing in My 115 Life?

After mounting your 115 Cloud Drive using the NAS network folder feature, you may notice that the number of files displayed on the NAS is fewer than those shown on the 115 web or mobile app, or that some folders cannot be found.

This issue is usually caused by the "**Hidden Mode**"(encrypted folders) being enabled on your 115 account. For more details, please refer to [**Why Are Files Missing in 115 Life Drive?**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmNzk2In0=).
