# What is the Role of the Polling Period in Cloud Drives Tools?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDc4In0=

## **What is the Polling Period?**

The Polling Period refers to how frequently the UGREEN NAS Cloud Drive tool polls the public cloud (such as Baidu Netdisk) for changes and synchronizes them to the local NAS folder. For example, if you set the polling period to 1 hour, the Cloud Drive tool will connect to the public cloud every hour to check for file changes. The maximum polling period is one day (24 hours or 1440 minutes).

### **Purpose of the Polling Period**

- **Enable real-time synchronization:** The Cloud Drive tool retrieves the file list and detects changes during each polling period, allowing timely updates and ensuring file consistency across different devices.
- **Keep data up to date:** The polling period helps ensure that all connected devices quickly obtain the latest versions of files, reducing issues caused by version discrepancies.
- **Optimize system resources:** Properly configuring the polling interval helps optimize system resource usage and prevents frequent synchronizations from overloading system performance.

### **Use Case**

Suitable for real-time synchronization tasks. To prevent file sync omissions caused by network fluctuations or transfer interruptions, the Cloud Drive tool will additionally perform a full comparison of the cloud file list at each polling interval.

**Notes**

- Enabling the polling period feature may affect the hard disk sleep state.
- Under unstable network conditions, it is recommended to extend the polling interval to avoid frequent reconnections that may impact system performance.
- For scenarios involving frequent file updates (e.g., collaborative projects), a shorter polling period is recommended. For less frequent backup and sync tasks, consider extending the polling interval to conserve system resources.

## **How to Set the Polling Period？**

1. You can manually adjust the polling period to meet different usage needs. Follow the steps below:
2. Go to [Cloud Drives] > [Connect].
3. In the list of connected cloud drives, click “...” and select the [Management] option.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250716/05f9538f-0624-4a80-97d9-7662a8c46199.png)

1. Check the “On” checkbox and enter the desired time interval (the maximum polling period is 24 hours or 1440 minutes). The default value is 1 hour, but you can adjust it based on your actual needs.
2. Click the “Confirm” button to save the configuration.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250716/41277762-822e-4d79-9c09-d50ee2ba4e86.png)
