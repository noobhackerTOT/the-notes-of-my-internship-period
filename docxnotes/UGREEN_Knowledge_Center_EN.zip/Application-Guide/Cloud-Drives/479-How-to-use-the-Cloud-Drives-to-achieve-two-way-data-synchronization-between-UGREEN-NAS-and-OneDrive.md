# How to use the Cloud Drives to achieve two-way data synchronization between UGREEN NAS and OneDrive?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDc5In0=

In order to better protect data security, we want to synchronise a copy of the data or running services on the UGREEN NAS to a third-party cloud drive, so that if files are lost on the local NAS, the data can be quickly restored through the third-party cloud. Currently, the UGREEN NAS can synchronise two cloud services, Baidu Netdisk and Microsoft OneDrive, through the Cloud Drives tool. This guide takes Microsoft OneDrive as an example to teach you how to use the Cloud Drives to synchronise data between the UGREEN NAS and OneDrive!

## Connect to OneDrive

1. Log in to the UGOS Pro system and go to [Cloud Drives], and click "New connetion"’.

2. Select "Microsoft OneDrive" from the pop-up list and click "Next".

3. You will be redirected to the OneDrive account login page. Enter your registered account password to log in and authorise. If you have not registered, please complete account registration first.

4. After logging in, you can see the status of the connected OneDrive network disk on the Cloud Drives overview page.

![](https://file1-cn.ugnas.com/admin/article/2025-08-21/c758b2610f184777b5c23c40cc1f2eaa.webp)

## Set up OneDrive and UGREEN NAS sync tasks

1. Go to the [OneDrive Cloud > Connect] page and click "Create sync task".

![](https://file1-cn.ugnas.com/admin/article/2025-08-21/9e237c32833d4f1ab0c6d42dbfcac16d.webp)

2. **Set the sync rules:**

The cloud drive path specifies the folder in the OneDrive that needs to be synced (e.g. "OneDrive/Pictures"), and the NAS path specifies the corresponding folder in the UGREEN NAS that needs to be synced (e.g. "Personal Folder/Photos").

![](https://file1-cn.ugnas.com/admin/article/2025-08-21/4c5c610d2cc34d1b878152f5cccb5c53.webp)

3. **Select the direction of synchronization:**

○ **Two-way sync:** Operations such as adding, modifying, deleting or moving files in OneDrive or the UGREEN NAS on either end will be synchronized on the other end.

○ **Sync only data changes from the cloud storage to the NAS:** Only synchronize changes from OneDrive to UGREEN NAS, and file changes on the NAS will not be synchronized to OneDrive. The default option in this mode is "When NAS files are deleted, NAS files are not deleted synchronously", which can be modified as needed.

○ **Sync only the data changes from the NAS to the cloud drive:** Only synchronise changes on the NAS to OneDrive, and changes to files on OneDrive will not be synchronised to the NAS. The default option in this mode is "When NAS files are deleted, the files on the cloud are not deleted simultaneously", which can be adjusted as needed.

4. **Advanced settings**:

Here you can filter files or file types that you do not want to synchronise and access further advanced options. Then click "Next".

5. **Set the sync strategies**:

You can set the sync strategies according to your needs. Here we have selected "Scheduled synchronization" and added a new plan. After completing the settings, click "Save" and continue to "Next".

![](https://file1-cn.ugnas.com/admin/article/2025-08-21/c0ba52efa7ce4bf49a4e107eb873ee04.webp)

6. **Confirm task information**: Check the detailed settings of the sync task and select "sync immediately after creation" (if necessary). It is recommended to select a time when the device is idle to sync to reduce the impact on NAS usage. Click "OK" to create the task when finished.

7. **View sync progress**: View the progress and status of the task in the [Sync task] list, and click [More > Details] to get detailed information about the sync task.

![](https://file1-cn.ugnas.com/admin/article/2025-08-21/738fb85d74d34a8ea6abd2fa3a347369.webp)

## Notes

● When performing a synchronisation task, please ensure a stable network connection to avoid interruptions or data loss during the synchronisation process.

● It is recommended to regularly check the remaining storage space on the UGREEN NAS and OneDrive to avoid synchronisation failures due to insufficient space.
