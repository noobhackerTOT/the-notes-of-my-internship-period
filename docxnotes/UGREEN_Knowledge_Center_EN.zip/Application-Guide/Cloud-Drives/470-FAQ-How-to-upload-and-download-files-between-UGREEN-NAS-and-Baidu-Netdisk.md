# 【FAQ】How to upload and download files between UGREEN NAS and Baidu Netdisk?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDcwIn0=

In the UGREEN NAS's UGOS Pro system, the Netdisk tools can easily connect the UGREEN NAS to Baidu Netdisk to enable fast uploads and downloads of files. This is especially helpful for data migration, backup or when replacing the UGREEN NAS device. This article will explain in detail how to connect to Baidu Netdisk and enable mutual transfer of UGREEN NAS data.

## How to connect Baidu Netdisk to UGOS Pro?

1. Log in to UGOS Pro, go to "Cloud Drives > New Connection".

2. Select the netdisk you want to connect to from the list, select “Baidu Netdisk" and click "Next".

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/28010f3ee5124f74b96cec417b01beae.webp)

3. After going to the Baidu Netdisk login page, enter your account and password to log in and authorise. If you do not have a Baidu Netdisk account, you need to register an account first.

4. After you have completed the login, you can view the status of the connected Baidu Netdisk on the overview page.

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/93754077b75f43baa9d5a925a7c3982d.webp)

## How to upload UGREEN NAS files to Baidu Netdisk?

1. Click on the linked Baidu Netdisk to view the current capacity of the disk. If the upload volume is large, you can upgrade to a NAS membership to increase the capacity.

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/fc2910bc2e91403697862bd32fefe5f6.webp)

2. On the [Connect] page, select "Upload to Cloud Drive" and then click "Select file".

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/f60cc37eb0114954925d94e5914c7bd6.webp)

3. The default file upload location is the "UGREEN Cloud Drive" folder on Baidu Netdisk.Please note: According to Baidu Netdisk policies, there is a limit to the size of individual files that can be uploaded, and only NAS members can support custom storage paths.

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/e8d4f2eba3974471b31e51714a7dad87.webp)

4. In the [Select file] window, select the file or folder to upload from the NAS's Files and click "Confirm".

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/b6c2b9b62fdd4ad5923f152b2a770c5e.webp)

5. During the file upload process, you can view the current upload progress in "Upload".

6. After all files have been uploaded, you can open the "UGREEN Cloud Drive" folder in your browser to view the uploaded files.

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/834c177af1904ecb940431cc95bc492f.webp)

## How to download Baidu Netdisk files to UGREEN NAS?

1. On the [CLoud Drives > Baidu Netdisk] [Connection] page, click "Select file" under "Download to NAS".

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/5839b3c9fe31430f8ee5ab50a84bc3f0.webp)

2. Select the file or folder to be downloaded from Baidu Netdisk and click "Next".

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/d40b1e4f656441b289c97a9d4244dc2e.webp)

3. Specify the save path for the file to be downloaded to the UGREEN NAS and click "Confirm".

4. You can view the download progress in [Download] while the file is downloading.

![](https://file1-cn.ugnas.com/admin/article/2025-08-22/4faf1809347b46d5be1518487c213b94.webp)

5. After the download is complete, go to the corresponding folder path in"File" to view the downloaded file data.

**Notes**

● It is recommended to maintain a stable network connection during file transfer to avoid interruptions or data loss.

● Please ensure that the storage space of the UGREEN NAS and Baidu Netdisk is sufficient to avoid transmission failures due to lack of space.

● Some advanced features of Baidu Netdisk, such as custom upload paths, are only available to NAS members. Please select the appropriate membership package according to your needs.
