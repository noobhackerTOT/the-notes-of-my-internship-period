# How to Restore Files Accidentally Deleted in Cloud Drive Sync Tasks Via the NAS Recycle Bin?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzk5In0=

When users operate an added cloud drive in the "**Cloud Drives**" application and accidentally delete files within folders associated with a sync task, the NAS Recycle Bin supports restoring those files.

## File Deletion Rules for Sync Tasks

A cloud drive sync task links a folder on the NAS with a folder on the cloud drive. Regardless of whether the sync direction is "**Two-way sync**" or "**Sync only data changes from the cloud drive to the NAS**", when a user deletes a file or folder in the linked cloud drive directory, the NAS will also perform the corresponding delete operation.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/e033e1bf2cb34dd2b6e1f48e914aa09d.webp)

**The NAS-side file deletion behavior follows the rules below**:

● If the NAS folder has the Recycle Bin enabled, files deleted through synchronization will be moved to the NAS Recycle Bin and can be restored.

● If the NAS folder does not have the Recycle Bin enabled, files deleted through synchronization will be permanently removed and cannot be restored.

## Applicable Scenarios

To help you better understand, the table below illustrates the actual behavior on the NAS when files are deleted on the cloud drive under different configurations:

| Sync Mode | NAS Folder Recycle Bin Status | NAS File Action |
| --- | --- | --- |
| Sync cloud drive to NAS only | Enabled | File is moved to NAS Recycle Bin (restorable) |
| Two-way Sync | Enabled | File is moved to NAS Recycle Bin (restorable) |
| Sync cloud drive to NAS only | Disabled | Permanently deleted (not restorable) |
| Two-way Sync | Disabled | Permanently deleted (not restorable) |

## How to Enable the Recycle Bin

To prevent accidental data loss on the NAS caused by unintended deletions on the cloud drive, it is recommended to enable the Recycle Bin for the corresponding folders.

### On Desktop

1. Open the "**Files**" application, and click "**Manage**" button, then select "**Recycle Bin management**" from the top toolbar.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/8a4556f8ddd644b4bfa48ef526a5636d.webp)

2. On the "**Recycle Bin management**" page, locate the folder involved in the cloud drive sync task and click "**Enable Recycle Bin**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/226955222a3541d2ad3b599c864698d0.webp)

Once enabled, if files are mistakenly deleted on the cloud drive, you will still have the opportunity to restore important data from the NAS Recycle Bin.

### On Mobile

1. Open the "**Files**" application and tap the "**Settings**" icon at the top.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/3f36ad693d4440318aa2076048187832.webp)

2. Tap "**Recycle Bin Management**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/a9f92fc0011f4c889ffd8084cd45e5d5.webp)

3. On the Recycle Bin Management page, locate the folder involved in the cloud drive sync task and tap "**Enable recycle bin**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/3219ea8eab77463f8763b1fd3f59e9f1.webp)
