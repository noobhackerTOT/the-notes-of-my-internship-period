# What image formats are supported by AI recognition in UGREEN NAS Album?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTUzIn0=

## **AI Recognition Supported Image Formats**

UGREEN NAS Album currently supports AI recognition for the following image formats:

- **Common formats**: JPG, JPEG, PNG, GIF, BMP, WEBP, HEIC, HEIF
- **RAW formats**: 3FR, ARW, CR2, CR3, DNG, NEF, ORF, PEF, RAF, RW2

**Note**: AI recognition for video formats is currently not supported.

## **Enabling AI Recognition**

If your NAS device hasn’t been updated to the latest firmware version, please follow the steps below to ensure proper functionality:

**Update the Firmware**

1. Go to [Control Panel] > [Update & Restore].
2. Check if your current firmware is the latest version.
3. If an update is available, click [Update check interval] to upgrade your device.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250819/c8728b07-203a-47c3-8df9-4dc5e07722b1.png)

**Update the Album AI Model**

1. Open the UGREEN NAS Album app and tap the user avatar in the top right corner.
2. Go to [Settings] > [Intelligent].
3. In the "Intelligent" screen, check whether the AI model is up to date.

- If a new version is available, tap [Update] and wait for the model to download and install.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250819/aafb5baa-1a88-437d-b482-c47b0513f592.png)

**View AI Recognition Results**

After updating the AI model, return to the album page to view the recognition results based on the latest algorithm. The results include categories such as people, scenes, and objects.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250617/b8cc310d-1a79-49cd-ab83-8a312574eb6c.png)

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250617/e4c00323-c8fb-429d-b452-4466a85e0a80.png)

**Notes**

- To ensure the best user experience, it is recommended to regularly check whether the firmware and AI model are up to date.
- When uploading photos, try to use high-resolution and clear images to improve the accuracy of AI recognition.
