# Why Are Uploaded Photos and Videos Not in Original Quality?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzk1In0=

**Applicable Version**: UGOS Pro 1.11.0.0002 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## Why Are Uploaded Photos and Videos Not in Original Quality?

When uploading and backing up content via the mobile app, if you notice that photos or videos stored on your NAS appear blurry or have reduced resolution, please refer to the information below to identify the cause and resolve the issue.

## Cause Analysis

UGREEN NAS does not actively compress or reduce image or video quality during the upload process. By default, all files are transferred in "**original quality**". If you experience issues such as "**blurry images**" or "**non-original quality**", the most common reason is that the files stored locally on your phone are not the original versions.

This is usually related to the cloud storage optimization features of mobile operating systems (iOS/Android). When options such as "**Optimize Storage**" are enabled, the cloud stores the high-resolution originals, while the phone keeps only lower-resolution thumbnails to save local storage space.

In this situation, the NAS uploads the locally stored thumbnails, not the original files stored in the cloud.

## Solution

To ensure that photos and videos are uploaded in full original quality, you need to adjust your phone's system settings so that the original files are downloaded back to the device.

### For iOS Users (iPhone/iPad)

1. Open "**Settings**">"**Apps**", scroll down, and tap "**Photos**".

2. Under "**iCloud Photos**", change "**Optimize iPhone Storage**" to "**Download and Keep Originals**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/9f9cd11d835a4c38831caafe91a54b1d.webp)

3. Wait for the system to automatically download the original files from iCloud to your device.

4. Once the originals are fully restored locally, re-run the photo upload task in the UGREEN NAS app.

### For Android Users (e.g., Xiaomi, Huawei, etc.)

1. Open your phone's "**Cloud Service**" or "**Gallery**" settings.

2. Locate the album synchronization options.

3. Change the default "**High quality**" setting to "**Original**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-07/c803a7b19b8449edb020bf1c6357f4b1.webp)

4. After confirming that the original files have been restored locally, re-run the photo upload task in the UGREEN NAS app.

## Helpful Tip

If you prefer not to change your system's storage settings, you can try the following temporary workaround:

**Manual Preloading:**
Before starting the NAS upload task, open the photos or videos you plan to upload in your phone's gallery and view them one by one. During this process, the system typically downloads and caches the original files from the cloud to local storage. Once this is done, start the upload—your NAS will then be able to upload the files correctly in high quality.
