# How to Enable Video Face Recognition in the Photos App?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjc4In0=

**Applicable models**: DH series, DX series, DXP series, and iDX series

**Applicable clients**: UGREEN NAS PC client and web browser

**Applicable version**: UGOS Pro firmware 1.15.12.0051 and later

The screenshots in this article are for reference only. The actual interface may vary slightly depending on the system or app version. Please refer to the actual interface.

## Scenario Description

The "**People recognition**" feature in the "**Photos**" app can recognize and group faces in photos. It can also automatically recognize people who appear in videos and sort them into the corresponding People albums.

This feature is suitable for managing large numbers of family videos, event recordings, or surveillance videos, helping you find all media files by person in one place.

**Note:**Currently, videos**up to 30 minutes long**can be recognized. This feature also uses more system resources, so please keep video length within a reasonable range.

## Prerequisites

Before you begin, make sure the following requirements are met:

● **The people recognition model has been downloaded and enabled:**Video people recognition is a sub-feature of the "**People recognition**" model. You need to download and enable the "**People recognition**" model first in "**Settings**" > "**Intelligent**". If the model is not installed, follow the system prompts to complete the download.

● **The firmware and app have been updated:**We recommend updating the NAS firmware and Album app to the latest versions to ensure the feature works properly.

## Steps

1. Open the "**Photos**" app, click the "**Settings**" icon at the bottom of the sidebar, and go to the "**Intelligent**" page.

2. In the smart model list, find and enable the "**People recognition**" model, then select "**Recognize people in videos**" under the model.

![](https://file1-cn.ugnas.com/admin/article/2026-05-24/b05c28e0b8ea4fcb88fab79361460728.webp)

3. The system will start scanning photos and videos in "**Library**" and recognizing faces in them. This may take some time, depending on the length and number of videos.

4. After recognition is complete, click "**Categorization**">"**People**" in the sidebar, then click any person's profile photo to view all photos and videos of that person.

## Notes

● Face recognition in videos needs to decode video frames and detect faces, which uses more CPU and memory resources. We recommend enabling this feature when the system is idle, such as at night, and avoiding running it at the same time as tasks like data sync or file backup.

● If you turn off the "**Recognize people in videos**" switch later, the system will keep the video face recognition results that have already been generated, but newly uploaded videos will no longer be recognized automatically.
