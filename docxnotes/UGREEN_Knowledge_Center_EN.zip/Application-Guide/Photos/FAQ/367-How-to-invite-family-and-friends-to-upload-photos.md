# How to invite family and friends to upload photos?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzY3In0=

You can share an album with your family and friends and invite them to upload photos to your UGREEN NAS album, making it easier to collect valuable videos and photos.

1.Go to the [Albums] tab, hover your mouse over the album you want to share, and click the “...” icon.

2.In the pop-up menu, select “Invite Friends to Upload Photos” to open the upload invitation wizard.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250610/f08f38d9-f8c3-45fa-9e15-5b0143fc22b3.png)

3.On the wizard page, complete the following settings:

- **Name:** Enter a name for the upload invitation task (the default name is the invitation date), and optionally enter information to be displayed to friends on the upload page.
- **Path:** You can modify the personal library folder where files will be saved.(Note: Currently, only saving to personal folders is supported.)
- **Validity Period:**Select the validity period for the invitation task.
- **Upload Limit(optional):**Check and specify the maximum upload size per file, and set a password for accessing the invitation task.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250610/23fb45c9-3b42-4090-ae24-208bb92b9707.png)

4.After completing the settings, click “Confirm” to generate the invitation upload task link.Please note: To create an external invitation upload link, you need to enable the UGREENlink remote access service. For detailed instructions, please refer to: “[Enable UGREENlink Service.](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODYifQ==)”

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250610/63ed2875-84f4-41e5-8025-14cc466315eb.png)

5.Send the link to your friends. After opening the link, they can upload files to the folder. If a file with the same name already exists, the upload will be automatically skipped.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250610/8a18c719-bcbe-4710-97c3-aeeedc486eaa.png)

Please note: Uploaded photos are saved by default in the folder “Personal Folder/photos/Friend Uploads/YYYYMMDD/Uploader’s Name.”

6.You can go to [Photos] > [Tools] > [Friend Upload Management] to view created friend upload tasks, check uploaded files, creation dates, task validity periods, and file save locations.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250610/99addae2-663c-4560-8b53-e32e7757c056.png)

On the [Friend Upload Management] page, you can also copy friend upload task links, edit, or delete upload tasks.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250610/934c2db8-f582-4b31-be3b-1645e58d6e70.png)
