# How to Set a People Album Cover

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODM2In0=

You can use the "**Set as cover**" feature to manually select the most suitable or representative photo as the cover for a People album.

## PC

**Steps:**

1. Go to "**Categorization**" in Photos and open the target person album.

2. Browse and find the photo you want to use as the cover.

3. Right-click the image.

4. Click "**Set as cover**" in the menu.

The system will automatically extract the recognized face from the photo and update it as the album cover.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/2c0d060b71964c0082952ee42ae572ce.webp)

## Mobile

**Steps:**

After entering "**Categorization**" and opening the relevant People album, follow these steps:

1. Browse the album and long-press the photo you want to set as the cover.

2. Once selected, a floating action bar will appear at the bottom of the screen.

3. Scroll the bottom bar and tap "**Set as cover**".

The system will automatically extract the detected face from the selected photo and set it as the cover image of the People album.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/b56bac2990434c0a8c6ad1d6ab3f1ce6.webp)
