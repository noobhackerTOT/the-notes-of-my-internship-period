# How to Clean Up Similar and Duplicate Photos

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODM0In0=

## Applicability

**Applicable platforms**: UGREEN NAS PC client and web browser.

**Applicable versions**: UGOS Pro firmware 1.15.0.0114 and later.

The screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application versions. Some features may differ across versions; please refer to your actual interface for accuracy.

## Overview

As the number of photos stored on devices continues to grow, Photos can easily accumulate burst shots with similar images or completely identical files, which continuously take up storage space. Withthe Photos's "Similar/Duplicate" feature, you can quickly scan, compare, and clean up redundant photos, efficiently freeing up storage space.

## Prerequisites

Open the Photos app on the UGREEN NAS PC Client, then find and click "**Similar & Duplicates**" in the left sidebar. The system provides two features, "**Similar photos**" and "**Duplicate photos**." Click "**Scan**," and the system will automatically scan the entire Photos.The results will be grouped and displayed by time.

![](https://file1-cn.ugnas.com/admin/article/2026-05-06/17ddcf9fb7b8461b8e39a3c7d8424328.webp)

## Merge Duplicate Photos

This feature is used to handle redundant photos with completely identical file content.

● **View scan results**: Switch to the "**Duplicate Photos**" tab. The top banner will display the number of duplicate photo groups found and the total number of photos.

● **Confirm items to keep**: The system will automatically identify and mark a "**Kept**" item in each group of duplicate photos, ensuring that no data is lost during cleanup.

![](https://file1-cn.ugnas.com/admin/article/2026-05-06/c6cc87c82e6047a0888c41c74bcb2a0a.webp)

● **Enlarge preview**: Hover your mouse over a photo to reveal the zoom button. Click the button to view details in full screen for comparison.

● **One-click merge**: Click the "**Merge**" in the top-right corner. The system will automatically keep the photo marked as "**Kept**" and remove the other duplicate files in that group.

![](https://file1-cn.ugnas.com/admin/article/2026-05-06/2505f88c20da41e0aeb334b928831e67.webp)

● **Ignore specific groups**: If you need to keep multiple copies in a certain group of duplicate photos, click "**Ignore**" on the right side of that group. It will be excluded from the current cleanup task.

● **Update data**: If there have been recent additions or deletions in the Photos, click "**Rescan**" in the top-right corner to synchronize the latest status.

## Clean Up Similar Photos

This feature is used to handle burst shots, photos with similar compositions, or images that are visually highly alike. Since similar photos may contain subtle differences (such as facial expressions), manual selection is required.

● **View scan results**: Switch to the "**Similar photos**
" tab in the top bar. The banner will display the number of groups and the total number of similar photos.

● **Preview & favorite**: Hover over a photo to reveal the checkbox, favorite button (heart icon), and "**zoom**" button. Click the zoom button to view details in full screen for comparison. Click the "**Favorite**" button
to add preferred photos to your favorites.

● **Manual selection**
: In the time-grouped list, browse and compare each group of similar photos. Click the top-left corner of thumbnails you don't want to keep to select them (a black checkmark will appear after selection).

● **Batch delete**: After selecting, a floating action bar will appear at the bottom, showing the number of selected items (e.g., "selected: 2"). Click the "**Delete**" (trash can) on the right side of the bar to remove the selected similar photos.

![](https://file1-cn.ugnas.com/admin/article/2026-05-06/e225135d75894ced9588a5f9ce2973d0.webp)

● **Ignore specific groups**:Similarly, for burst photo groups that don't need cleaning, click "**Ignore**" on the right side to remove them from the current list.

● **Update data**:If there have been recent additions or deletions in the Photos, click "**Rescan**" in the top-right corner to synchronize the latest status.
