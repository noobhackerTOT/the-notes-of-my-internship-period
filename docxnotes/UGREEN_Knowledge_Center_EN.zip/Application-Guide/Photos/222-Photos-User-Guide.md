# Photos User Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjIyIn0=

**Applicable Series**: DH Series, DX Series, DXP Series, and iDX Series

**Applicable Platforms**:UGREEN NAS PC Client, Web Browser

**Applicable Version**: UGOS Pro firmware 1.15.12.0051 and later

Some AI features in the Photos app (such as**custom categorization**) are currently supported only on iDX series devices.Screenshots in this document are for reference only. Actual interfaces may vary slightly depending on system or application versions. Please refer to the actual interface displayed on your device.

# Overview

The **Photos** app helps you easily organize your photos and videos and share life moments with family and friends anytime. It offers a variety of practical features to quickly find content, automatically organize files, create personalized albums, and collaborate or share with others.

**Key features include**:

● **Quick filtering**: Supports intelligent search as well as multi-dimensional filtering by file type, recording time, device, and more, helping you quickly locate what you need.

● **Intelligent Organization**: Automatically groups photos into smart albums based on people, locations, pets, objects, and more. You can also create personalized themed albums to suit your needs.

● **Custom Categorization**: Create your own AI-based categories. The system can automatically recognize and classify related images in the "**Library**" based on category names.

● **Flexible sharing and collaboration**: Set sharing permissions for photos or albums and invite family, friends, or team members to collaborate and manage your "**Library**" together.

● **Granular permission control**: Assign different permissions (such as viewing, downloading, uploading, and managing) to different users, ensuring data security while improving collaboration efficiency.

● **Automatic backup**: Supports one-click backup of photos and videos from mobile devices (such as smartphones) to the NAS Photos app, freeing up device storage while securely preserving important memories for centralized management.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/c7c95bba0c0f4b14b88d8fd757922522.webp)

## Supported File Formats

● **RAW formats (mainstream cameras)**: RAW, CR2, CR3, NEF, ARW, RAF, RW2, PEF, DNG, 3FR, ORF, ICO, PSD, HIF.

● **Common image formats**: JPG, JPEG, PNG, GIF, BMP, WEBP, HEIC, HEIF.

● **Common video formats**: MP4, MOV, WMV, FLV, AVI, AVCHD, WebM, MKV, ASF, MPG, RM, RMVB, Match3gp.

# Installation & Access

1. Open the "**App Center**" and find the "**Photos**" app.

2. Click "**Install**" and follow the on-screen instructions to complete setup.

3. After installation, click the Photos icon on the desktop or in the app list to start using it.

# Interface Overview

With the top navigation bar, sidebar menu, and settings page, you can quickly browse and manage photos and albums.

## Top Navigation Bar

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/7bfc92bf3892431d90158a3a75279a9d.webp)

① **Search bar**: Enter descriptions of people, scenes, or events (e.g., "kids hugging dog") to find photos and videos.

② **Zoom slider**: Drag the slider to zoom in or out on photos and videos.

③ **Filter & sort**: Options vary by page:

● **Library/Favorites**: Filter by type (photos, videos, GIFs, Live Photos), or distinguish between "**personal and shared files**"; sort by recording time or upload time; advanced filters include device, focal length, aperture, ISO, etc.

● **Folders**: Filter by "**Personal files**" or "**Shared files**".

● **Categorization**: Filter byyour owned photos and shared ones.

● **Personal Albums**: Filter by "**Shared/Not shared**", or sort by creation time, album name, update time, or number of photos.

● **Shared Albums**: Filter by album type (common, conditional, baby album), or sort by creation time, album name, update time, or number of photos.

④ **Create & upload**: Upload photos and videos to the default or selected folder, create new albums, or generate share links to invite others to upload content.

⑤ **Minimize/Maximize/Exit**: Use these buttons to minimize, maximize, or exit the Photos interface.

## Sidebar Menu

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/6c9650e9a8684a40938fbdc52aa8540e.webp)

● **Library**:Browse all personal photos and videos, as well as those shared by others.

● **Folders**: Browse photos and videos according to file directory structure.

● **Categorization**: When enabled, automatically recognizes and classifies photos and videos in the "**Library**" based on people, locations, custom categories, etc.

● **Favorites**: Displays photos or videos you have personally favorited.

● **Personal Albums**: Create, view, and edit all albums you have created, including common albums, conditional albums, and baby albums.

● **Shared Albums**: View and manage albums shared by you or others.

● **Similar & Duplicate**: When enabled, identifies and allows batch cleanup of similar and duplicate photos and videos in albums.

● **Custom Navigation Bar**: Drag or add manually created albums or smart albums to the custom navigation bar according to your preferences.

● **Settings**: View and edit general settings, intelligent settings, folder scope, sharing management, and friend upload management.

● **Refresh**: Click the "**Refresh**" icon to manually refresh the Photos page.

● **Timeline**:Hover over the right-hand side of the "**Library**" to view photos and videos organized by year and month of capture.

## Settings

**General Settings**: Administrators can configure display ratio for images, whether to show photo provider, file name conflict handling during uploads, folder view display, and permission for standard users to share photos.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/43525de4f5b646b2b113737fc92b39cc.webp)

**Intelligent Settings**: Administrators can enable or disable GPU acceleration and AI models such as **sensitive content detection, pet detection, text recognition, face recognition, similar / duplicatephoto recognition, scene & object recognition**, and image recognition. You can also adjust parameters for face and image recognition models and reprocess recognition tasks (requires downloading and enabling model authorization in **UGREEN AI**).

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/43649d81518f4e838afdf8c91b6e8af1.webp)

**Folder Scope**: Administrators can define which folders are associated with the Photos app. Scanning associated personal or shared folders will display the photos within the app.

● **Personal Folder**: Displays linked personal folder paths. Click the "**+**" icon to add new personal folders as album sources.

● **Shared Folder**: Displays linked shared folders and associated user permissions. Supports adding new shared folders and managing access permissions for different users.

● **Scan**: Click "**Scan**" to manually trigger the system to retrieve new photos from the specified folders.

● **More Settings**: Click the "**…**" icon next to a folder to "**Set as default folder**" or "**Remove**" it. When a folder is set as default, newly uploaded photos will be stored in this location by default.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/32f623eaf53f422bbd3ae61e6a07cc2f.webp)

**Sharing Management**: Administrators can centrally view and manage internal and external sharing links, including editing link information, copying links, stopping sharing, and batch clearing expired links.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/45b0dd4b690b45069c929d05dcc44564.webp)

**Friend Upload Management**: Administrators can centrally view and manage friend upload links, including editing link details, deleting links, and batch clearing invalid links.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/9ca6dbd4b77c4c76b5749ce61512d465.webp)

# Feature Module Guide

## Library

The "**Library**" is used to view and manage all photos and videos stored in your NAS Photos app. Content is displayed in a thumbnail view, with multiple viewing modes and filtering options to help you quickly locate and organize files.

### Linked Folders for Library

In the "**Photos**" app, you can create and manage your "**Library**" by linking folders. The system will automatically scan photos and videos in the linked folders and display them in the Library.

**Steps:**

1. Open "**Photos**" app, click the "**Settings**" icon at the bottom of the sidebar, and locate "**Folder scope**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/2c851844d21d4cd4be444ea5a45a56a3.webp)

2. Click the "**+**" icon to select folders to link with the "**Library**":

● **Personal Folder**: Source of personal photos in the Library. Only you can view and manage them. The "**Personal Folder/Photos**" directory is created by default and serves as the default storage location.

● **Shared Folder**: Source of **shared photos** in the "**Library**". Multiple users can view and manage these files, with permissions controlled by the administrator.

3. After adding folders, the system will automatically scan and import photos and videos into the "**Library**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/54de5b2b63a649dea27ce2502c91030f.webp)

**Notes:**

● For non-admin users, enabling the "**Library**" and adding files for the first time requires enabling a personal folder—please contact the administrator.

● When linking folders with a large number of photos, the system will generate thumbnails and perform AI recognition (if enabled). Initial scanning time depends on the number of files and may slightly impact NAS performance.

### View Library by Personal or Shared Photos

You can filter the "**Library**" by personal files (visible only to you) or shared files (visible to users with permissions).

**Steps:**

1. Go to the "**Library**" page and click "**Filter & Sort by**" in the top menu.

2. Select "**Personal files**" or "**Shared files**".

3. The Library will refresh automatically based on your selection.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/b32593b2ef434d5ba9a1e0ddacb16974.webp)

### View Library by Timeline

By default, the "**Library**" displays photos in reverse chronological order. You can also filter using the timeline.

1. Go to the "**Library**" page and hover over the right side of the interface, then click a specific year or month on the timeline.

2. The "**Library**" will display photos and videos from the selected time period.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/82a6de5165944eae9f2bf913d68b0a43.webp)

### View and Manage Photos

On the "**Library**" page, click any photo to open the detail view, where you can perform the following actions:

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/6fe8c57b30d14d738d8815fef48f4172.webp)

① **Favorite**: Mark the photo as a favorite. You can view it later in the Favorites section.

② **View Original**: Switch between original photo and thumbnail view.

③ **Zoom**: Zoom in or out of the photo.

④ **Rotate**: Adjust the orientation of the image.

⑤ **Full Screen**: View the photo in full-screen mode.

⑥ **Delete**: Delete the current photo (it will be moved to the recycle bin).

⑦ **Details**: View file location, shooting location, device info, and camera parameters. You can also edit the file name and shooting date.

⑧ **More Options**:Click the "**...**" icon, you canShare, download, move, or copy the photo to another folder; add it to albums or People categories; or mark it as sensitive for protection.

### Batch Photo Management

On the "**Library**" page, select multiple photos to perform the following actions:

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/f94e18e611624976be729309ad89dab3.webp)

① **Share**: Share selected photos in bulk with internal or external users.

② **Download**: Save selected photos to your local device in batches.

③ **Add to Album**: Add selected photos to a specified album in bulk.

④ **Delete**: Delete selected photos in batches. Deleted files can be recovered from the recycle bin.

⑤ **More Options**: Click "**...**" icon and you can perform additional batch actions such as setting privacy protection, adding to People categories or favorites, modifying recording time, and moving or copying to a specified folder.

### Search Photos and Videos

Photos supports AI-powered content search, allowing you to quickly find specific photos by describing people, scenes, or events (e.g., "kids hugging dog").

**Prerequisites**: Enable "**Image recognition**" and "**Text recognition**" in "**Settings**"**>**"**Intelligent**".

**Steps:**

1. Click the "**Search box**" in the top menu bar.

2. Enter keywords describing the content (e.g., "kids hugging dog").

3. The system will return matched results and the number of results based on AI recognition.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/de2f51c6e23f47dabfbc750842cbdd67.webp)

## Folder View

Folder View displays photos and videos based on the directory structure. It is ideal for users who prefer organizing files by folders or need to manage photos by project, timeline, or category.

### Access Folder View

1. Click "**Folder**" in the sidebar to enter Folder View.

2. Click the "**All files**" icon in the top-left corner to display the hierarchy of linked personal and shared folders.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/7145196092f94d339d9a1a98181a332b.webp)

### Manage Folder View

● **Browse Folders**: Double-click a folder to open it. Use the navigation path to return to the parent directory.

● **Folder Management**: Right-click or select a folder to perform actions such as download, add to album, invite friends to upload, rename, change cover, move, copy, or delete.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/b14734300e024e34b627eddcc85d7cec.webp)

● **Filter**: Click the "**Filter**" button in the top-right corner to view files by "**Personal files**" or "**Shared files**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/27c849bca4fa448daa6d44787d1e3d6f.webp)

● **Hide Folder View**: To hide Folder View, go to "**General**" settings under "**Settings**", and turn off "**Show folder view**".

## Intelligent Categorization

The **Intelligent Categorization** feature uses AI recognition to automatically organize photos by **people, locations, pets, scenes, and objects**, helping you quickly find specific types of images. It also supports **custom categories** (currently available only on iDX series devices). Simply enter a category name, and the system will automatically identify and group relevant photos in the "**Library**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/37530637e11f4fa28c906957351edb78.webp)

### Enable Intelligent Recognition Models

When entering the intelligent"**Categorization**" page for the first time, you need to manually enable the AI recognition models. After the administrator clicks "**Enable now**", the system will activate any downloaded models (if not yet downloaded, follow the prompts to install them). You can also enable models via "**Settings**">"**Intelligent**" Settings:

● **Face Recognition**: Automatically detects and groups faces in photos and videos ("**Recognize people in videos**" must be enabled separately under this option).

● **Pet Detection**: 39 common cat and dog breeds such as Bulldog, Shiba Inu, and British Shorthair.

● **Image Recognition**: Understands image content and supports text-to-image search, scene/object recognition (e.g., screenshots, selfies, scenery, food, vehicles, ball sports, ID photos, receipts/invoices), and similar/duplicate photo detection ("**Recognize video frames**" must be enabled separately).

● **Text Recognition**: Extracts text from images for search.

● **Similar/Duplicate Photo Detection**: Identifies and groups similar or duplicate photos.

● **More AI Models**:Additional models can be enabled as needed.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/911c7df78ba84d0cae1c8ea5f81de4e4.webp)

After enabling, the system will automatically scan the "**Library**". The initial scan may take some time depending on the number of photos.

### People Categorization

Once "**Face Recognition**" is enabled, the system will automatically detect faces in photos and videos and group them into albums by person.

**View People Albums**

Click"**Categorization**">"**People**" in the sidebar to view all detected faces along with the number of associated photos.
**Note**: You can search for people and assign names within the full list.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/3aaa4414e81f49a1a3ec5ac43a652fd7.webp)

**Manage People Albums**

On the "**People**" page, click a person's avatar to view all related photos. Right-click or use the "**More**" button on the right to perform the following actions:

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/b71993c2b2114328a909a5f224c6bc47.webp)

● **Add to Navigation Bar**: Add the person's album to the custom sidebar for quick access (right-click again to remove).

● **Rename**: Assign or edit the person's name for easier identification.

● **Hide Person**: Hide albums you don't want displayed. Hidden albums can be restored by right-clicking again.

● **Lock Person**: Prevent the system from automatically adding new photos to this person's album (you can repeat the same action to unlock).

● **Merge People**: If the same person is recognized as multiple groups, select the avatars and click "**Merge**" to combine them into one album.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/41ce5689b7d34a0097bc3863e244b91c.webp)

● **Show Hidden People**: Click the "**Filter and sort by**" button in the top-right corner and enable "**Show hidden people**" to display previously hidden albums again.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/ef9b465137b34781b3961d8d4ae49051.webp)

### Location Categorization

Based on GPS metadata in photos, the system automatically groups images by shooting location.

**View Location Albums**

Click**"Categorization**">"**Locations**" in the sidebar. The system displays locations by city hierarchy, and you can view the distribution of photos on a map (requires photos with GPS data).

**Note**: Location recognition depends on GPS metadata. If location services were disabled when the photo was taken, or if metadata has been stripped, the results may be inaccurate.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/42d6ccc10bd84b67a51e8147337e0501.webp)

### Object Recognition & Other Categories

After enabling the **Image recognition** model, AI automatically identifies scenes and objects in photos and generates corresponding category albums.

These include categories such as **screenshots, selfies, and object-based** categorizations (e.g., scenery, food, vehicles, ball sports, ID photos, receipts/invoices, etc.).

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/13d947af9a36473bbf47c204e91f2762.webp)

Click the "**More"** button to perform the following actions:

● **Add to Navigation Bar**: Add object or other category albums to the custom sidebar for quick access (right-click or use "**More**" again to remove).

● **Search again**: If you're not satisfied with the results, you can trigger a re-analysis.

### Custom Categorization

Custom categorization allows creating personal AI category rules. The system recognizes and organizes photos based on category names, and uploaded sample photos can be used to train dedicated models. Photos that match the rules will be automatically identified and categorized.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/5c5137b926654611a31d5a11818f11b5.webp)

**Create Categories by Name**

1. On the "**Categorization**" page, select "**Custom**".

2. Click the "**Create categories by name**" card and enter a category name, such as "Birthday cake".![](https://file1-cn.ugnas.com/admin/article/2026-06-10/859b7d68ae9045dc86a020e85d03fd30.webp)

3. AI will search the Library based on the category name and automatically cluster matching photos.

**Create a Custom Category by Training Models**

When the system's automatic clustering results are not ideal, or when a specific object needs to be recognized, a dedicated model can be trained for more accurate classification. For detailed steps, see[How to Create a Custom Category with Model Training？](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODc0IiwiY2xpZW50VHlwZSI6IlBDIn0=)

### Manage Custom Categories

On the**"Custom"**page, right-click a category album or click the**"More"**button on the right to perform the following actions:

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/bec02a679148454f8d250f0444676724.webp)

● **Add to navigation bar**: Pin the category to the custom navigation bar in the sidebar for quick access.

● **Rename**: Change the name of the custom category.

● **Export model**: Export the trained model package to the NAS or a local device.

● **Delete**: Delete the category. (Note: After deletion, the training data will be lost. Any object recognition albums and conditional albums generated from this category will also be deleted).

**Note:**Custom categorization is supported only on some devices, including the iDX series. Please refer to the actual interface.

## Favorites

The **Favorites** feature allows you to mark important or preferred photos and videos for quick access, regardless of their original storage location.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/8fb295906c8a48949ea87d305071d9b0.webp)

### Add to Favorites

● **Single Item**: On the photo details page, click the heart icon to favorite the photo.

● **Batch Favorite**: On the "**Library**" page, select multiple photos, click the "**…**" icon, and choose "**Add to favorite**".

### View Favorites

Click "**Favorites**" in the sidebar to view all favorited photos and videos.

### Manage Favorites

● You can remove items from Favorites page by clicking the heart icon again.

● Filtering and sorting options are available for managing favorited items.

## Personal Albums

"**Personal Albums**" allows you to create personalized albums, including **common album**, **conditional album**, and **baby album**, to meet different photo organization and display needs.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/c81cf77afa174bb693ec2c00d5c09bb2.webp)

### Create and Manage Common Albums

A "**Common Album**" is created by manually selecting photos, making it ideal for organizing images around specific themes, events, or projects.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/c2fd11912da542dd9be1d67f1d0848ad.webp)

1. Click "**Personal Albums**" in the sidebar. Upon first entry, click "**Create album**".

2. Select "**Common album**".

3. Enter an album name.

4. Select photos from the "**Library**" (or upload from local storage / add from NAS folders).

5. Click "**Create album**" to finish.

Available Actions in a "**common album**":

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/c56289521a694be9bc1db3eb8b1edc2f.webp)

① **Edit Album Name**: Click to rename the album.

② **Add User Permissions**: Click the "**+**" button to add users in bulk and set internal sharing permissions.

③ **Link Sharing**: Create an external sharing link and set permissions, validity, whether visitors can access to photo details (enabled by default), and password.

④ **Add Photos**: Upload photos from local storage or the "**Library**", or save uploaded photos to a specified folder.

⑤ **More Options**: Click the "**...**" menu, you can download the album, create an upload link for invited users, rename, add the album to the sidebar navigation, delete the album, or stop sharing if an external link has been created.

### Create and Manage Conditional Albums

A "**Conditional Album**" automatically filters and includes photos based on defined criteria. It supports combinations of conditions such as people & pets, recording time, file type, location, object recognition, device, source, and keywords in file names.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/e0047eb0007e4921b3102aa89de68b56.webp)

1. Click "**Create album**" and select "**Conditional album**".

2. Enter an album name.

3. Set filter conditions:

● **People & Pets**: Select specific people or pets, or group photos (requires face and pet recognition models).

● **Recording Time**: Specify a date range or special dates.

● **Location**: Enter a specific place or region (e.g., Shenzhen).

● **Object Recognition**: Select scene or object tags (requires scene & object recognition models).

● **Device**: Choose the camera or device model.

● **Source**: Specify personal folders, shared folders, or custom folders.

● **File Type**: Select photos, videos, live photos, or GIFs.

● **Keywords**: Enter keywords contained in file names or custom categorization keywords (custom keywords supported only on iDX devices with image recognition enabled).

4. Combine multiple conditions as needed. The system will display the number of matching photos in real time.

5. Click "**Create**". Matching photos will be automatically added.

Available actions in a "**conditional album**":

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/4eafa606d5b340d29b2c0f4ba7aee051.webp)

① **Edit Album Name**: Click to rename the album.

② **Add User Permissions**: Click the "**+**" button to add users and configure internal sharing permissions.

③ **Link Sharing**: Create an external sharing link and set permissions, validity, visitor access to photo details (enabled by default), and password protection.

④ **More Options**: Click "**...**" menu, you can download the album, rename, edit album conditions, add to navigation bar, delete the album, or stop sharing if an external link exists.

### Create and Manage Baby Albums

A "**Baby Album**" is a special album designed for recording a child's growth. It supports storing details such as date of birth, height, and weight, and can automatically organize photos by birth month.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/07291653cad84a9a8184eea0f942979a.webp)

1. Click "**Create Album**" and select "**Baby album**".

2. Select the baby's avatar (requires face recognition), and enter basic information such as nickname, date of birth, and gender.

3. The system will automatically group photos based on the associated face.

4. Click "**Create album**" to finish.

Available actions in a "**baby album**":

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/52c6911e045b4d5f9a3d7468ff76c8e0.webp)

① **Edit Album Name**: Click to rename the album.

② **Add User Permissions**: Click the "**+**" button to add users in bulk and set internal sharing permissions.

③ **Link Sharing**: Create an external sharing link and set permissions, validity, whether visitors can access to photo details (enabled by default), and password.

④ **Upload Photos**: Upload photos from local storage or the "**Library**", or save uploaded photos to a specified folder.

⑤ **More Options**: Click "**...**" menu, you can download the album, create an upload link for invited users, rename, add/edit the baby's avatar, edit baby information (including height, weight, blood type, etc.), add the album to the sidebar navigation, delete the album, or stop sharing if an external link has been created.

### Batch Set Internal Sharing Permissions

Internal sharing is intended for users who already have NAS accounts.

1. In the "**Personal Albums**" page, right-click the target album or enter the album details page, then select "**Share**"**>**"**Internal sharing**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/65b0f6b07186412bbdb1b64b00f089ed.webp)

2. In the "**Internal sharing**" dialog, click the "**+ Add user**" to add multiple users.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/438fca6309094195bce21874b57d87ce.webp)

3. After adding users, select permissions in "**Batch set permissions**" (View Only, Download, Upload, Manage). Refresh the page for changes to take effect.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/65ccfff7fa6544cd80e555830d050963.webp)

### Create External Link Sharing

External sharing is designed for users without NAS accounts.

1. In the "**Personal Albums**" page, right-click the target album or open the album details page, then select "**Share**">"**External link sharing**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/fa5224987986480aac061f898eac8108.webp)

2. Configure the following settings as needed:

● **Access Permission**: View only or allow download.

● **Validity**: Set validity period (1 day / 3 days / 7 days / 30 days / permanently valid).

● **Allow Access to Photo Details**: Enabled by default; can be turned off.

● **Password**: Set a password for secure access.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/4118cc5fd80040f6ad7137c55e4f51f4.webp)

3. After configuration, click "**Copy link**" and share it with external users.

**Note**: You can right-click the album again and select "**Share**", or go to "**Settings**">"**Sharing management**" to view and edit external sharing links.

### Invite Friends to Upload Photos

1. In the "**Personal Albums**" page, right-click the target album or open the album details page, then select "**Invite friends to upload**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/7e3d156d13d0421792776bac5a66441a.webp)

2. In the "**Invite friends to upload**" dialog, configure settings such as link name, message, validity, photo storage location, and password.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/8d7492eda12c44868ddf15ba287871f7.webp)

3. Click "**Create and copy link**" to share with external users.

**Note**: You can right-click the album again and select "**Invite friends to upload**", or go to "**Settings**">"**Friend upload management**" to view and manage upload links.

## Shared Albums

**Shared Albums** allow you to view and manage all albums related to you, including those you've shared and those shared with you—enabling collaborative photo management for families or teams.

### View Shared Albums

Click "**Shared Albums**" in the sidebar. The "**All**" tab displays both albums you've shared and those shared with you.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/5df4d1dfc4bf4c05ac4b212c8eda990c.webp)

### Manage Albums You Shared

On the "**Shared by me**" page, right-click the target album or open its details page to perform the following actions:

● **Share**: Modify internal/external sharing permissions, link validity, access password, and more.

● **Stop Sharing**: Revoke all sharing permissions and links. Others will no longer be able to access the album.

● **Download to Computer**: Download all photos and videos in the album as a package to your local device.

● **Invite Friends to Upload**: Create or edit an invitation link that allows others to upload photos to this album.

● **Rename**: Change the album name.

● **Add to Navigation Bar**: Pin the album to the custom sidebar for quick access (right-click again to remove).

● **Delete Album**: Delete the album (only the album grouping is removed; photos and videos remain in the "**Library**" and folders).

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/6b74e3c1c9c44cc1b4a976ce6323a9fe.webp)

### Manage Albums Shared with You

On the "**Shared by others**" page, right-click the target album or open its details page to perform the following actions:

● **Add to Navigation Bar**: Add the album to the custom sidebar for quick access. Right-click again to remove them.

● **Decline This Sharing**: Remove your access to the album. The album will be removed from the list.

**Note**: Available actions (view, download, upload, manage) depend on the permissions granted by the album owner.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/d654aece41304dd1b449e03bec815c32.webp)

## Similar & Duplicate Photo Detection

The "**Similar & Duplicates**" feature helps identify and clean up duplicate or highly similar photos in your "**Library**", freeing up storage space and keeping your collection organized.

### Enable the Detection Model

1. Log in as an administrator and go to "**Settings**"**>"Intelligent**".

2. Enable the "**Similar / Duplicate photo recognition**" model.

3. Return to the "**Similar & Duplicates**" page and click "**Scan**". The system will automatically detect similar and duplicate photos.

### View and Clean Similar Photos

Similar photos are images with highly similar content but slight differences (e.g., burst shots or photos taken from similar angles).

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/b821f1deb9bf4f7f94b591388aca78b8.webp)

**Handle Similar Photos**

1. Switch to the "**Similar Photos**" tab.

2. Browse photo groups grouped by similarity.

3. Select unwanted photos and click "**Delete**" to move them to the recycle bin.

**Notes:**

● To keep an entire group, click "**Ignore**" to remove it from the list.

● Click "**Rescan**" to re-analyze similar photos in the Library.

### View and Merge Duplicate Photos

Duplicate photos are identical images, often created by repeated backups or imports.

![](https://file1-cn.ugnas.com/admin/article/2026-06-10/99765655bbbd43d1964e590258cdd47e.webp)

**Handle Duplicate Photos**

1. Switch to the "**Duplicate photos**" tab.

2. Browse duplicate groups and compare the original and copies.

3. Manually select photos to delete.

4. Click "**Delete**" icon to move them to the recycle bin.

**Notes:**

● For **batch processing**, click "**Merge**". After merging, only one "**kept**" photo remains per group; others are moved to the recycle bin.

● To keep an entire group, click "**Ignore**" to remove it from the list.

● Click "**Rescan**" to detect duplicates again.
