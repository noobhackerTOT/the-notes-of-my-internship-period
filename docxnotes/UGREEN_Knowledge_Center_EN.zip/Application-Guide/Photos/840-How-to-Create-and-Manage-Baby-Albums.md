# How to Create and Manage Baby Albums

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODQwIn0=

**Applicable Platform**: UGREEN NAS PC client and web browser.**Applicable Version**: UGOS Pro 1.15.0.0114 and aboveScreenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

A **Baby Album** is a smart album designed to record a child's growth. It not only stores photos securely, but also automatically organizes them by the baby's birth month. You can record details such as date of birth, gender, height, weight, and blood type—keeping precious memories well organized.

**Note**: Baby Albums are linked with the "**People recognition**" model. You must associate the baby's face during creation. After that, the system will automatically recognize and categorize related photos in the "Library"—no manual sorting required.

![](https://file1-cn.ugnas.com/admin/article/2026-04-30/ca23e053018f4e2a8a3e395946491424.webp)

## Enable People Recognition

When creating a Baby Album for the first time, you need to enable the "**People recognition**" model in "**Settings**"**>**"**Intelligent**".

![](https://file1-cn.ugnas.com/admin/article/2026-04-30/58b03531dfc5434798f986f353b0a95c.webp)

Alternatively, in the "**Photos**" app sidebar, go to "**Categorization**", then in the "**People**" section click "**Enable**" to start the peopel recognition model.

**Note**: After enabling, the system will begin scanning faces in your "Library". This may take some time—please wait for completion.

![](https://file1-cn.ugnas.com/admin/article/2026-04-30/3ef2ae799da14d259974e9ce60b49ff7.webp)

Once finished, you can view results under"**Categorization**"**>**"**People**". If recognition is inaccurate, you can manually adjust it (e.g., merge, lock, or hide groups).

![](https://file1-cn.ugnas.com/admin/article/2026-04-30/cf047686a536445e8bc7e2413a124f5a.webp)

## Create a Baby Album

1. In the "**Photos**" app sidebar, click "**Personal Albums**".

2. Click "**Create album**", then select "**Baby album**", and enter a name (e.g., Baby Growth Journal).

![](https://file1-cn.ugnas.com/admin/article/2026-04-30/c06c64822c0445bca50d2b3618ad1276.webp)

3. Set the baby's basic information:

● Select the baby's avatar

● Enter a nickname

● Choose date of birth, gender, etc.

4. Click "**Create album**". The system will automatically organize photos based on the linked face.

## Manage a Baby Album

On the Baby Album detail page, you can perform the following actions:

![](https://file1-cn.ugnas.com/admin/article/2026-04-30/2ad980c8bf364037b895f2349294e255.webp)

● **Rename Album**: Click the album name at the top to edit it.

● **Edit Baby Information**: Click the "**...**" icon and select "**Edit baby information**"to update height, weight, blood type, etc., building a complete growth record.

● **Manually Upload Photos**: Click "**Upload**" icon to add photos from local storage or the gallery that were not automatically recognized.

● **Change Album Cover**: Set your favorite photo as the album cover.

● **Share with Family (internal)**: Click the "**+**" button to grant access to other NAS users (e.g., family members) for collaborative management.

● **Share via Link (external)**: Create an external link with configurable permissions (view only/download), validity, and password to securely share with others. You can also use "**Invite friends to upload**" from the "**...**" menu for users without NAS accounts.

● **Pin to Navigation Bar**: Use the "**...**" menu to add the album to the sidebar for quick access.

● **Download or Delete**: Download the entire album for local backup. When deleting an album, only the album grouping is removed—the original photos remain safely stored in the "Library" and folders.

● **Stop Sharing**: If a sharing link has been created, you can disable external access anytime from the "**...**" menu.
