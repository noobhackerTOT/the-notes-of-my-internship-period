# How to Use Smart Categorization in Photos

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODMzIn0=

### Applicability

**Applicable Platform**: UGREEN NAS PC client and web browser. For mobile app instructions, please switch to the mobile version.

**Applicable Version**: UGOS Pro 1.15.0.0114 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

### Overview

The smart"**Categorization**" feature in Photos app is powered by local AI models. Once enabled, the system automatically performs multi-dimensional analysis on photos and videos in the background—recognizing faces, locations, objects, scenes, and text. This helps organize scattered media into a well-structured and searchable library.

### Prerequisites

Before using the categorization features, make sure the required AI models are enabled:

1. Open the "**Photos**" app, tap "**Settings**" in the bottom bar, then go to "**Intelligent**" settings.

2. In the "**Intelligent**" settings tab, enable the following options as needed:

○ **People recognition**: For grouping people and creating Baby Albums.

○ **Text recognition (OCR)**: Automatically extracts text from photos (OCR). Once enabled, you can quickly find images by searching for keywords in the text (such as IDs or invoice details).

○ **Similar/Duplicate photo recognition**: Automatically scans in the background and tags visually similar or identical photos, providing data for the "**Similar & Duplicate**" cleanup feature.

○ **Pet recognition**: Identifies 39 common cat and dog breeds (e.g., Bulldog, Shiba Inu, British Shorthair) and groups them automatically.

○ **Sensitive content recognition**: Automatically identifies sensitive images (such as explicit content) and applies blur by default when browsing the album list to protect your privacy and viewing experience.

○ **Image recognition**: Deeply understands image content and scene elements, enabling "**text-based image search**" for the album and providing underlying technical support for automatic scene and object classification.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/1e8068c03cf54a038f5000a20d69b309.webp)

**Notes:**

● After enabling these models, the system will scan your "**Library**" using local computing power. If you have a large number of photos, the initial analysis may take some time.

● If you notice missed or incorrect recognition, or after bulk photo imports, you can tap "**Recognize again**" next to the feature to rescan the entire Photos.

### People Categorization

#### Naming People

On the "**People**" page under "**Categorization**", right-click the avatar and select "**Rename**" to change the system default "**Unnamed**" to the person's real name.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/e8d879c2814e4cb68da3bf3a225b39ee.webp)

#### Fixing Misclassifications

After enabling people recognition in Photos, the system automatically clusters faces based on facial features. In some cases, lighting or angles may cause occasional misclassification. You can use the "**Remove**" function to manually correct and reassign photos, improving the accuracy of person albums.

**Steps:**

In the Photos app on PC, open a person album. If you find incorrectly grouped photos, you can correct them in the following ways:

**Method 1: Single-photo correction**

1. Locate the misclassified photo in the person album, right-click the photo.

2. In the menu, choose "**Move to another person**" to assign it to the correct group, or "**Remove from this person**" to simply ungroup it from the current person.

**Method 2: Batch correction**

1. Hover over the photos you want to fix and click the checkbox that appears to select multiple images.

2. After selection, a toolbar will appear at the bottom. Click the "**...**" button on the right.

3. Choose "**Move to another person**" or "**Remove from this person**" to complete the batch correction.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/828c61e0eb064cb48c539428a65f240f.webp)

#### Set a Person Album Cover

You can manually choose a preferred or representative photo and set it as the cover for a person album using the "**Set as cover**" option.

**Steps:**

1. Go to "**Categorization**" in Photos and open the target person album.

2. Browse and find the photo you want to use as the cover.

3. Right-click the image.

4. Click "**Set as cover**" in the menu.

The system will automatically extract the recognized face from the photo and update it as the album cover.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/52cce7d4abff4c2cb0df280592c476b2.webp)

#### Set Quick Access

Right-click a person's avatar and select "**Add to navigation bar**". The person will then appear in the left-side menu for quick access.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/af8fafe065a346689f72fe61fc988a5b.webp)

### Location And Footprints

**Map view**: In the "**Locations**" tab, click "**Map**" to explore your travel footprint across cities with zoomable navigation.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/8b435f47625f45aa92d4e97c63b09f76.webp)

**City grouping**: The system automatically generates city cards (e.g., Kota Kinabalu) based on GPS data. Click a card to view all photos taken in that location.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/e9896849ca0c47ce81bdc67ed131a87a.webp)

### Screenshots & Selfies

**Screenshots**:The system automatically detects and extracts screenshots (such as chat records, QR codes, etc.). This category helps separate screenshots from your main "**Library**", keeping it clean and organized.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/f0765501724346be99637ba929faf1ad.webp)

**Selfies**: Automatically groups selfie-style photos together, making it easy to review your personal photos in one place.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/50cc90b5d10440dc94126603f5901a60.webp)

### Object Recognition

The "**Object recognition**" feature in Photos leverages advanced AI technology to deeply understand image content and scene elements, enabling automatic classification by scenes and objects. The system scans and categorizes photos in the background, helping you quickly locate specific types of images within a large "**Library**".

**Steps:**

1. Go to the "**Categorization**" page and tap "**Object recognition**". You'll see a preview of some automatically generated category cards (such as "**Wedding**", "**Dogs**", "**Screenshots**", etc.).

2. Tap the expand button on the right to view all category cards, which mainly include:

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/ba61b50801e4400fa6a5935ebd91f577.webp)

● **Pets & Animals**: Accurately recognizes common cat and dog breeds and creates dedicated albums for your pets.

● **Daily & Natural Scenes**: Automatically identifies moments like gatherings, beaches, waterfalls, snow scenes, sunrises, sunsets, forests, and more.

● **Documents & Receipts**: Automatically filters and groups screenshots, IDs, product codes, text, invoices/receipts, and other useful information for quick access.

● **Other Categories**: Includes common elements such as food, selfies, and more.

![](https://file1-cn.ugnas.com/admin/article/2026-04-29/6ea6967bd14c421089c770456eaeb466.webp)

Tap any category card, and you can view all photos within it.
