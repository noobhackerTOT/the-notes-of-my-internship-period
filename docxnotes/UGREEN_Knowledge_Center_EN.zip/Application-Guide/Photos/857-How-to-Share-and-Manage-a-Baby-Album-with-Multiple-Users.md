# How to Share and Manage a Baby Album with Multiple Users?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODU3In0=

**Applicable models**: DH series, DX series, DXP series, and iDX series

**Applicable clients**: UGREEN NAS PC client and web browser

**Applicable version**: UGOS Pro firmware 1.15.12.0051 and later

The screenshots in this article are for reference only. The actual interface may vary slightly depending on the system or app version. Please refer to the actual interface.

## Scenario Description

In a family setting, multiple members, such as parents and grandparents, may each take photos and videos of the baby on their own phones. They may want to bring these scattered photos together into the same Baby Album, manage the album together, and keep uploading photos.

With**people recognition**,**sharing permissions**, and**folder association**in the Photos app, you can easily allow multiple users to manage the Baby Album together. You do not need to manually sort and organize the files. The system will automatically bring together baby photos taken by different members.

## Prerequisites

● **The administrator has created a**"**Baby album**"**:**You can refer to "[How to Create and Manage Baby Albums?](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODQwIiwiY2xpZW50VHlwZSI6IiJ9)", and make sure the baby's profile photo has been linked.

● **All members have enabled the People recognition model:**Each family member needs to go to "**Settings**">"**Intelligent**" in their own account, enable the "**People recognition**" model, and wait for the system to recognize the baby's People group. If the recognition is inaccurate, you can manually merge or rename people.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/cddb10c61d1a409684cd29239c8c9f02.webp)

● **All members have backed up their phone photos to the NAS:**Make sure family members use the automatic backup feature in Photos to sync baby photos from their phones to their own personal folders or a specified shared folder.

## Steps

Two methods are provided below. Choose the one that best fits your needs.

### Method 1: Manage through "People recognition" and "Personal albums" sharing settings

In this method, each family member has their own personal Library, and their photos are stored in their own personal folder. By sharing the "Baby album" and adding the baby from "People recognition", baby photos from different members can be collected into the same album.

1. **The administrator creates a**"**Baby album**"**and adds family members as managers**

In "**Personal Albums**", open the created "**Baby album**", such as "Baby Growth Journal". Click "**Add user**" ("**+**" icon), add family members (regular users) as internal sharing members, and set their permission to "**Manage**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/332b4d3f101245c883f7d59dfdd33154.webp)

2. **Family members add the baby to the shared "Baby album"**

● Family members log in to their own accounts, go to "**Shared Albums**">"**Shared by others**", and find the album shared by the administrator.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/f9372787c83848539085a6ad2b9a8825.webp)

● Clickthe album, click the "**…**" icon, and select "**Add baby**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/0162322ef81a48cd8419c1225014a953.webp)

● Then select the corresponding baby profile from their People recognition list. The system will automatically sync all photos of this baby to the "Baby album".**Note**: Photos added by multiple users will be automatically deduplicated.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/dc5cde378c4741c8ac3b8b818062b99b.webp)

3. **Family members manually upload photos (optional)**

Family members can also tap**"Upload"**and choose photos from their phone or personal album to add them to the "Baby album". These photos will be saved directly to the folder linked to the album and will not be synced to the uploader's "**Categorization**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/1a7fe8b2441844ebaec4ffc4d4b97454.webp)

### Method 2: Manage photos through a shared album folder

In this method, all family members back up photos and videos from their phones to the same shared folder. The administrator then sets this folder as the default folder for the album, so everyone can view all photos and videos in this folder from the album.

1.**The administrator creates a shared folder and sets permissions**

In "**Files**", create a "**Shared Folder**", such as "Family baby album", and set permissions for all family members. Select the "**Read & Write**" permission so they can back up photos and videos from their phones.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/d9bc5e9c2bab407789b7d88385450e35.webp)

2. **The administrator links the "Shared Folder" to "Photos" and sets it as the default folder**

●Open the "Photos", go to "**Settings**">"**Folder scope**">"**Shared Folder**", and click "**+**" to add the folder.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/bbce98c8805f4a6b8b82744afc2772a5.webp)

● After linking, click the "**Add user**" icon, select all family members, and grant them "**Manage**" permission so they can view and manage the shared photos and videos in "Library". You can also set permissions based on each family member's actual needs.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/a0ce9aba289542f281a19c6ef903b191.webp)

● After completing the settings, click the "**…**" icon on the right of the folder and select "**Set as default folder**". Photos uploaded through "Library" by any member later will be saved to this Shared Folder by default.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/8e3fc02c62fe4284a3806d24dc5112c2.webp)

3. **Family members configure phone backup to the same "Shared Folder"**

Family members open the "**Photos**" on mobile, go to "**Settings**">"**Photos backup**", and change the backup destination path to the Shared Folder created by the administrator. After that, new photos on their phones will be automatically backed up to this Shared Folder.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/c9920d9f5c5844e28146fa272f4300c4.webp)

4. **The administrator creates a "Baby album" and shares it with family members**

The administrator creates a Baby Album in "**Personal Albums**" and links it to the baby's profile photo. Then, the administrator shares the album with all family members through "**Internal sharing**" and sets their permission to "**Manage**". All family members can then view and manage all baby photos in one place in "Library" or "Shared Albums".

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/50221a5a36d6440985583417735ed1f9.webp)

## Additional Notes

● If multiple family members add the same baby profile, for example, if they all recognize "Baby Q", the system automatically removes duplicates to prevent the same photo from appearing more than once in the album.

● If the system does not recognize the baby correctly, refer to the methods in "[How to Intelligently Categorize People in Photos?](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmNTY3IiwiY2xpZW50VHlwZSI6IiJ9)" to manually merge, rename, or lock the person.

● Regular users cannot modify the Shared Folder scope settings. To make changes, please contact the administrator.
