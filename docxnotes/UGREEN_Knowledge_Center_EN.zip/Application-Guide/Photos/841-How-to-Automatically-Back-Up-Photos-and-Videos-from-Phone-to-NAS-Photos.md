# How to Automatically Back Up Photos and Videos from Phone to NAS Photos

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODQxIn0=

**Applicable platforms**: UGREEN NAS APP (iOS / Android)

**Applicable versions**: UGOS Pro firmware 1.15.0.0114 and later.

Actual displays may vary depending on system or application versions. Some features may differ across versions; please refer to your actual interface for accuracy.

With the automatic backup feature of Photos app in the UGREEN NAS App, photos and videos on phone can be automatically backed up to the NAS Photos, preventing data loss while freeing up storage space on your device.

![](https://file1-cn.ugnas.com/admin/article/2026-05-07/67a2cc39402d4b638ba6f78780efe90a.webp)

## Enable Photos Backup

When using the Photos backup feature for the first time, install the "**Sync & Backup**" app and the "**Photos**" app from the App Center.

1. Open "**Photos**," tap "**Settings**" in the bottom menu bar, find "**Photos backup**," and tap the "**Enable**" to start.

![](https://file1-cn.ugnas.com/admin/article/2026-05-07/56345cba4f604f538f927a1e97a90e6f.webp)

2. Go to the Photos backup page and configure the backup rules:

● **Backup source**: Select the range of albums to back up, such as "**all albums**" on the phone or specific albums.

● **Back up to**: Choose the destination, such as a personal folder or a shared folder on the NAS.

● **Backup time range**: Choose to back up all photos or only files within a specific time period.

● **Photos sorting**: Choose how files are organized—by shooting date (month/year) into separate folders, merged into a single folder, or stored according to the phone's original directory structure on the NAS.

![](https://file1-cn.ugnas.com/admin/article/2026-05-07/400de1c01cb5408d89541690c5dddcb7.webp)

3. Tap the "**Settings**" icon in the top-left corner to configure options such as enabling **Auto backup in background**, **Night backup**, **Mobile data backup**, and **Energy-saving backup**.

![](https://file1-cn.ugnas.com/admin/article/2026-05-07/5c07c9be20ee41edb06a819f71ba4617.webp)

4. After completing the backup settings, the selected photos and videos will be automatically backed up to the NAS Photos.

## Notes

● When configuring backup, it is not recommended to enable "**Mobile data backup**" to avoid consuming cellular data.

● For subsequent backups (non-initial), only newly added files will be synced, and the existing file structure will remain unchanged.

● If need to adjust the storage structure of backed-up files, the original backup must be deleted before reconfiguring and running the backup again.

● Files that have already been backed up can be safely deleted from the phone, as the data stored in the NAS Photos will not be affected, helping free up device storage space.
