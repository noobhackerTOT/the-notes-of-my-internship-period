# Logs

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjE2In0=

## Applicability

**Applicable client:**UGREEN NAS PC client (Windows/macOS).
**Applicable version:**NAS firmware 1.16.0.0042 and later.

This article is for reference only. The actual interface and operation path may vary slightly due to system or app version updates. Please refer to the actual interface.

## Feature Overview

The "Logs" app serves as the monitoring hub of the UGREEN NAS system, recording detailed event logs and transfer logs from the system layer and individual apps. Administrators can use this app to monitor system activity in real time.

● "Logs" provides precise search tools across multiple dimensions, helping administrators quickly locate and trace historical abnormal operation records.

● Log archive policies can be configured, allowing the system to regularly package historical logs and save them to a specified storage location. This helps prevent older logs from being overwritten and lost when the log volume becomes too large.

● Automatic notifications based on specific rules are supported. When a serious or specified event occurs, the corresponding log will be pushed to the NAS message center in real time, ensuring administrators can promptly stay informed of system security events.

**Note:**For system data security, the "Logs" app is visible only to administrators. Regular users cannot view or access this app from the system desktop.

## Daily Viewing and Search

On the**Log**page, administrators can monitor various system events in real time and perform precise searches across multiple dimensions.

### Switch Log Type

Click "**Event Log**" in the top bar to switch between "**Event Log**" and "**Transmission Log**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-05/e287a2513eec4306bbd171af698c89b5.webp)

### Enable Files Logs

Click the "**Settings**" icon in the upper-right corner, select "**Enable files logs**", and click "**Apply**" to turn it on. After enabled, the system will record all users’ file actions, such as uploading, deleting, and renaming files, for future tracking.

![](https://file1-cn.ugnas.com/admin/article/2026-06-05/3d962762cb7041b7ab00f1e5d0a99f2f.webp)

### Quick Search

Enter keywords from the log content in the search box at the top.

### Filter

Click the "**Filter**" icon on the left side of the search bar. Logs can be filtered by "**Level**" (such as Serious or Normal), "**Module**" (app), "**User**", and "**Date**" range.

![](https://file1-cn.ugnas.com/admin/article/2026-06-05/c4f568391d4045d4a99c4d369e041783.webp)

### Advanced Search

Log search supports advanced searches using logical operators (AND, OR, NOT) and parentheses.

![](https://file1-cn.ugnas.com/admin/article/2026-06-05/b0456e3c0a264e67a4afb6a40eca6b74.webp)

● **AND**:Displays results that contain all search terms. For example, "**disk3 and sleeping**" displays results that contain both "**disk3**" and "**sleeping**".

● **OR**: Displays results that contain either search term. For example, "**stopped or started**" displays results that contain either "**stopped**" or "**started**".

● **NOT**: Excludes results that contain the specified term. For example, "**NOT disk3**" displays results that do not contain "**disk3**".

● **()**: Parentheses can be used to define the order in which AND and OR are interpreted. For example,**(admin OR root) AND NOT logged**displays results that contain either "**admin**" or "**root**", and exclude "**logged**".

## Export and Clear Logs

For large amounts of accumulated log data, administrators can manually export logs for backup or clear them.

● **Export log backup:**In the current log list, click "**Export**" in the top bar. Logs can be exported in`.CSV`or`.HTML`format for offline archiving or data analysis on a local computer.

![](https://file1-cn.ugnas.com/admin/article/2026-06-05/23cfbf9e124441cc82a58351466e9e59.webp)

● **Clear historical logs:**Click "**Clear**" in the top bar. In the pop-up window, select the time range to clear, such as "Older than 3 months", and click "**Confirm**". In the secondary confirmation window, click "**Confirm Clear**" to clear the logs.

![](https://file1-cn.ugnas.com/admin/article/2026-06-05/9690ac33f0ea4046af11688898681ea4.webp)

## Log Archive Policy

To prevent unlimited log growth from consuming storage space, the system supports an automatic archive mechanism that periodically packages old logs and moves them to a specified folder.

### Configure Trigger Rules

1. In the left sidebar, click "**Archive Policy**" to go to the "**Policy Configuration**" tab, then select "**Enable Log Archive Policy**".

2. Configure the archive trigger conditions. The following conditions are supported: "Log Volume", "Number of Logs", and "Log Retention Time". When any condition reaches the upper limit, the system will automatically archive the logs.

3. Select the storage location in "**Archive Path**", then click "**Apply**" in the lower-right corner to save the settings.

![](https://file1-cn.ugnas.com/admin/article/2026-06-05/92b31ae1484341ddbb006c08b2f4626a.webp)

### View Archived Files

On the "Archive Policy" page, switch to the "**Archive Records**" tab to view the list of previous automatic archive tasks and their output directories.

To view historical data that has been packaged and archived, click "**Log**" in the left sidebar, switch to the "**Archive Viewer**" tab in the top bar, and click "Add Archive". Import the historical files from the corresponding path to read them online.
