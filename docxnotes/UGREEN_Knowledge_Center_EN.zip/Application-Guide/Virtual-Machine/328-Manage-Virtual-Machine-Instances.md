# Manage Virtual Machine Instances

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzI4In0=

There are functional differences between different product lines of UGREEN NAS devices. If you are using a DH Plus series device, please note that the Virtual Machine app is not available. To use virtual machine features, consider choosing a model such as the DXP series.

Within the "**Virtual Machine**" app, users can manage virtual machines from the VM homepage, performing various operations such as power control, VM configuration, snapshot management, shared link management, and VM export.

## Control Virtual Machine Power

● **Power On**: For a virtual machine that is not running, click the "**Power button**" to "**Start**" it.

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/039985ab4a814b5e9b40197ea11761e2.webp)

● **Shutdown/Force Shutdown**: For a running virtual machine, click the "**Power button**" to perform "**Shutdown**" or "**Force shut down**" operations.

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/a1a20edb54d24eb68656869f91bed6be.webp)

● **Restart/Force Restart**: Click the "**···**">"**Power**" button on the virtual machine to choose either "**Restart**" or "**Force restart**" to reboot the VM.

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/77037065bbe3442c8cdaab76d08b8351.webp)

## Deploying a Virtual Machine Creation Environment

Through the virtual machine management interface, users can easily add and manage volumes, configure virtual machine networks and images, view virtual machine logs, and perform operations such as resource allocation, snapshot creation, and shared link management.

### Creating volume

● **Add Volume**

1. On the virtual machine page, click "**Manage**">"**Volume**" to enter the "**Volume Management**" page.

2. Click "**Add volume**".

3. Select a volume suitable for storing virtual machine data, then click "**Done**" to complete the addition.

4. After the process is complete, all added volumes can be viewed on the "**Volume Management**" page.

● **Remove volume**

1. In the volume management list, select the volume you want to remove.

2. Click the "**Remove**" button next to the selected volume entry to remove it.

**Note**: A volume cannot be removed if virtual machine instances have been created within it.

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/a5d6ced2244e40848bb304ed543370b9.webp)

### Configuring Virtual Machine Networking

Under "**Manage**">"**Network"** on the virtual machine page, the system provides virtual subnets in bridge, NAT, and host-only modes by default for VMs. You can view and manage network settings here, including checking which virtual machine instances are using a specific virtual subnet.

Based on your requirements, you can also add custom virtual subnets. On the "**Network management**" page, click "**Add network**" to enter the virtual subnet creation wizard.

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/6baafffb688b4f1ea3c4d7db45a1a9cc.webp)

In the wizard, you can configure the following settings:

● **Network name**: Assign a name to your virtual subnet.

● **Mode**: Select the connection mode for the virtual subnet. You can choose between "**NAT**" and "**Host-only**" mode.

● **Map physical network**: Select the physical network interface to be used by the virtual subnet.

● **IPv4/IPv6 settings**: Choose the network protocol used by the virtual subnet. If you need to manually configure the subnet mask, gateway, or DHCP settings, uncheck "**Auto assignment**" and enter the required information manually.

After completing the configuration, click "**Confirm**" to create the custom virtual subnet. You can modify the settings of a custom virtual subnet or delete it at any time when it is no longer needed.

**Descriptions:**

● **NAT mode**: Forwards virtual machine network traffic to the host's network interface, allowing virtual machines to communicate with external networks through the host. All external communication is routed and managed by the host.

● **Host-Only mode**: Connects the virtual machine's network interface directly to the host. The virtual machine and host share the same network interface and can communicate directly with each other, but the virtual machine cannot directly access external networks.

### Configuring Virtual Machine Images

A virtual machine image is a preconfigured virtual machine file that contains the operating system, applications, and system settings—similar to a hard disk image on a physical computer. Using virtual machine images allows you to quickly deploy new virtual machine instances without manually installing the operating system or configuring the software environment.

Under "**Manage**">"**Image**" on the virtual machine page, you can manage all images in the local image repository, including uploading ISO images and deleting existing images. If the required image is not available in the local image repository, you can select an installation image from your NAS or manually upload an installation image from your computer.

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/07c7272264774545af5574784eea93aa.webp)

● **Uploading Images to the Local Image Repository**

1. On the local image repository page, click "**Add image**".

2. Select the upload source: "**From local computer**" to manually upload an image file, or "**From NAS**" to select an image stored on the NAS.

3. Select the image to upload and click "**Confirm**" to start uploading it to the local image repository.

4. After the upload is complete, the image will be available in the local image repository.

● **Deleting Images from the Local Image Repository**

1. Select the image you want to delete from the list.

2. Click "**Delete**" icon.

**Notes:**

● Images are typically created by exporting the state of an existing virtual machine or from operating system installation media.

● Supported virtual machine image format: **ISO files (.iso)**.

● When manually uploading installation files from a computer, do not close or refresh the browser during the upload process, as this may interrupt the upload.

### Viewing Virtual Machine Logs

The virtual machine logging feature records important events, warnings, and serious messages generated during virtual machine operation, helping users monitor and diagnose the status and issues of virtual machines.

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/2c1bf57cbb8046348406c9128dd4dbbc.webp)

**Virtual Machine Log Operations:**

● On the virtual machine page, click "**Manage**">"**Log**" to access the virtual machine log page.

● To locate specific log entries, enter keywords in the search bar to filter results.

● To export logs, click "**Export**" and select an export format (CSV or HTML).

● To clear logs, click "**Clear**", select a time range, and confirm. The system will remove logs within the specified period.

Log Levels:

● **Ordinary**: Records important operational events and audit-related activities, such as network configuration changes and user access.

● **Warning**: Records events and anomalies that may pose potential risks, such as abnormal operations like forced power-offs.

● **Serious**: Records events that affect normal application or system operation, such as hardware failures.

## Performing Virtual Machine Instance Operations

![](https://file1-cn.ugnas.com/admin/article/2026-01-08/3c6123b9e9d74e21bcdd4c410bdc276b.webp)

● **Create snapshots**: The snapshot feature allows you to capture the current state of a virtual machine, making it easy to restore the VM to that point in the future. Snapshots can be created at any time from the "**Settings**" page to help ensure data safety.

● **Export as an OVA file**: You can export a virtual machine as an OVA file for migration or backup purposes. This operation packages all virtual machine settings, disks, and configurations into a single file.

● **Create sharing links**: Use" **Shared link management**" to generate a sharing link for a virtual machine. You can share the link with other users, allowing them to remotely access the virtual machine through a web browser.

● **Delete virtual machines**: If a virtual machine is no longer needed, you can delete it from the virtual machine page. Deleting a virtual machine will remove all related configurations and data. Proceed with caution.

● **Snapshot management**: On the "**Settings"** page, you can view all snapshot records for a virtual machine and choose to restore, delete, rename, or create new snapshots. Snapshots capture the VM's state at the time they are created, making recovery convenient in case of misconfiguration or failure.

● **Shared link management**: Manage all generated virtual machine sharing links, view their status, and delete or regenerate links as needed to ensure secure sharing.

● **Virtual machine instance settings**: On the "**Settings**" page, you can manage a virtual machine's basic information, resource allocation (such as disks and network), and device configuration, allowing you to adjust performance and resource distribution as required.

### Basic Configuration of a Virtual Machine Instance

Within the virtual machine settings, you can modify basic configurations according to your needs, including the virtual machine name, CPU and memory allocation, image and disk configuration, and network settings. Detailed descriptions of each configuration item are provided below:

● **Image Configuration**

An image is the installation package for a virtual machine's operating system. By configuring an image, you can install or run a specific operating system on the virtual machine. Images can be selected from the local image repository. For example, you can use a "**Windows 10 image**" to install and run the Windows 10 operating system.

You can also add multiple images. For instance, after installing the operating system on a Windows virtual machine, you may want to install additional components (such as Guest Tools). In this case, you can add an extra image and use it to install the virtual machine enhancement tools.

**Note**: Virtual machine performance optimization tools (Guest Tools) are a set of driver utilities designed to improve virtual machine performance. They include Virtio drivers (for disks and networking), which enable smoother operation and more efficient performance. After installation, disk read/write speeds are significantly faster than with default drivers. For more information, refer to [Virtual Machine Performance Optimization Tools (Guest Tools) User Guide](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTIwNSwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo0MDksImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==).

● **Disk Configuration**

A virtual machine's disk functions like a physical computer's hard drive, storing files and installed programs. You can add multiple disks to a virtual machine to store different types of data. For example, you might configure two disks: one for system files (such as the Windows operating system) and another for user data. This separation allows each disk to serve a distinct purpose without interference.

● **Network Configuration**

Network configuration acts as a "**bridge**" that enables a virtual machine to connect with other devices. Different configurations are suitable for different usage scenarios. The following sections describe network adapters and network connection modes:

**Network Adapters**: A virtual machine's network adapter serves as the "**intermediary**" between the virtual machine and external networks (such as a LAN or the Internet). You can select different adapter types to control network performance and compatibility.

1. **Virtio**: An adapter optimized specifically for virtual machines, offering better network performance and lower latency. It is the best choice for high-performance virtual machines, especially those requiring fast network transfers. Linux virtual machines support Virtio adapters by default. For Windows virtual machines, Guest Tools must be installed to use Virtio; otherwise, network connectivity may not function properly.

2. **E1000**: Provides excellent compatibility and is supported by almost all operating systems, but with relatively lower performance. Suitable for virtual machines with modest network performance requirements.

3. **RTL8139**: Designed for very old operating systems (such as Windows XP or earlier). It is not recommended for use in Windows 7 or later environments.

**Network Connection Modes**: Network connection modes determine how a virtual machine accesses external networks and whether it can be accessed by other devices.

1. **VNET-NAT**: Choose this mode if you do not want the virtual machine to be directly accessible by external devices, but still need it to access the Internet or other devices on the local network.

2. **VNET-Bridge**: Select this mode if you want the virtual machine to communicate with other devices on the local network and have its own independent IP address. This is the recommended mode for most everyday use cases.

3. **VNET-HOST**: In this mode, the virtual machine can communicate only with the NAS and cannot access external networks. It is suitable for scenarios where the virtual machine needs to interact with internal NAS applications but does not require external network access.

### Advanced Virtual Machine Configuration

In advanced configuration, users can further adjust hardware- and boot-related settings to optimize virtual machine performance and overall user experience. Detailed explanations of each option are provided below:

● **Graphics Adapter**

The graphics adapter configuration directly affects a virtual machine’s graphical output capabilities. Selecting an appropriate adapter can significantly improve graphics performance, especially in scenarios that require visual processing.

1. **Cirrus**: Emulates a legacy graphics card and provides basic graphical capabilities. This option is suitable for virtual machines running simple operating systems or workloads that do not require advanced graphics.

2. **VGA**: A traditional graphics adapter that provides basic VGA-compatible output. It supports standard display requirements and is suitable for most general-purpose virtual machine scenarios.

3. **VMVGA**: A better choice when the virtual machine requires enhanced graphical processing, such as video playback or more complex user interface rendering.

4. **VIRTIO**: Recommended for virtual machines that need to run graphics-accelerated applications (for example, games, graphic design software, or video editing tools). This option provides the best graphics performance.

5. **QXL**: If the virtual machine is running a Windows operating system and improved graphics performance and user experience are required, this option is recommended. QXL is a virtualization graphics technology designed specifically to enhance Windows virtual machine graphics performance, significantly improving mouse responsiveness and screen rendering. For more details, please refer to [Installing the QXL Graphics Driver on a Virtual Machine](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTkyNCwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo2MDUsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==).

● **Boot Mode**

The boot mode determines how the operating system starts within the virtual machine.

1. **BIOS**: A traditional boot method with broad compatibility. Most operating systems support BIOS boot, but it does not support large disks (such as those over 2 TB) or some modern features.

2. **UEFI**: A modern boot method that supports larger disks (over 2 TB) and additional features such as Secure Boot.

**Note**: When using UEFI boot mode, the virtual machine does not support snapshot functionality. If snapshots are required, use BIOS boot mode instead.

● **Auto Start**

If you want the virtual machine to start automatically when the NAS powers on (for example, when the VM runs services or applications that need to remain active), you can enable the auto-start feature. Once enabled, the virtual machine will start together with the NAS.

● **Keyboard Language**

The keyboard language setting determines the language and layout used for keyboard input within the virtual machine. Selecting a preferred language (such as Chinese, English, or Spanish) can improve usability and typing accuracy.

● **Boot Source**

The boot source setting determines where the virtual machine loads the operating system from.

1. **Disk Boot**: Boots the operating system from the virtual disk. This mode is suitable for virtual machines with an operating system already installed and is the default boot option.

2. **Image Boot**: Boots from a virtual image file to launch an operating system installer. This mode is suitable for installing a new operating system. If you need to install a new OS (such as Windows 10 or Linux) on an existing virtual machine, select image boot.
