# Create a virtual machine

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjMwIn0=

# **Preparation Before Starting**

To ensure the best user experience, please configure the network for the virtual machine before creating it by changing the network mode to "Bridged Mode-LinuxBridge."

On the virtual machine homepage, click [Manage] > [Network], and change the mode of the virtual subnets [vnet-bridge0] and [vnet-bridge1] to [Bridged Mode-LinuxBridge].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250427/c7284670-f430-41f7-8c0c-1ffe86a5ed41.png)

To switch the mode, you need to set the NAS network to [Network Bridging] mode. Click "Modify immediately" to be redirected to the network connection settings in the "Control Panel" application.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250427/1a4a3ff8-4952-4cba-9b32-a5aaae97128f.png)

On the [Network Connection] page, click [Network Bridging] > [Virtual Bridging].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250427/e538959c-9d77-4339-9e00-b8e5a50eff9e.png)

Check [Enable Virtual Network Bridging], select the currently used LAN port, and click "Apply."

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250427/7877bc7a-8e12-4572-9564-a20a91266bbd.png)

Click "Continue" to create the virtual bridge network adapter. The virtual bridge network adapter will be displayed with a prefix of VBR.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250427/dfc22c67-13bb-4b7a-ba24-a8ac0ae96ea8.png)

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250427/963a87e1-cf02-496c-b6fc-17d675fafc46.png)

Return to the "Virtual Machine" application and change the mode of the virtual subnet to [Bridged Mode-LinuxBridge].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250427/7c8adf34-6610-48c2-87df-153ffde56f8e.png)

# **Create a Virtual Machine**

There are two ways to create a virtual machine: importing a virtual machine image or using a local ISO image. Below are the detailed steps:

## **Create Using an ISO Image:**

1. On the virtual machine homepage, click "New" > "New Virtual Machine" to open the creation wizard.
2. Select an ISO format image (if no images have been uploaded, click "Manually Upload" to add an image to the local image library). Click "Next."
3. Choose the storage location for the virtual machine data, and click "Next."
4. Configure the system type and leave other settings as default. Click "Finish" to create the virtual machine instance.

### **Introduction to Virtual Machine Parameters**

| Parameter Name | Description | Notes/Instructions |
| --- | --- | --- |
| Virtual Machine Name | Specifies the name of the virtual machine. | The name must be unique and comply with the system naming rules. |
| System Type | Select the system type for the virtual machine (e.g., Windows, Linux, etc.). | The image must match the version of the operating system being installed. |
| CPUs(Cores) | Specifies the number of CPU cores to be used. | Allocate based on actual needs; too many cores may impact NAS performance. It is recommended to keep the default setting. |
| Memory | Sets the amount of memory to be used by the virtual machine instance. | If the memory set exceeds the available system memory, the virtual machine will not start. |
| Disk | Sets the interface type (e.g., IDE, SATA, Virtio, SCSI) and the capacity of the virtual hard disk. | Up to 10 virtual disks can be added. Be mindful of storage space availability. |
| Network | Select the virtual network adapter type (e.g., Rtl839, E1000, Virtio) and connection mode (e.g., bridge, host, NAT). | Choose the adapter type and connection mode based on network requirements to optimize performance. It is recommended to choose the bridge connection mode. [Virtual Machine Networking Overview] |
| USB Controller | Allocates the USB controller to support communication with USB-2, USB-3, USB-C, Type-C (e.g., USB flash drives, external hard disks, hard disk enclosures, USB network cards, etc.). | Ensure that the NAS hardware supports the corresponding USB interface type, or the device may not be recognized. |
| Graphics Card | Virtual graphics card, supporting Cirrus, VGA, VMVGA, Virtio graphics card types. | To understand the differences between graphics card types, refer to the [Virtual Machine Graphics Card Introduction]. |
| Boot Type | Select the boot type for the virtual machine (e.g., BIOS or UEFI). | It is recommended to use BIOS type to support snapshot generation. [Types of Virtual Machine Booting] . |
| Auto Start | When enabled, the virtual machine will automatically start when UGOS Pro boots. | It is recommended to enable this setting. |
| Keyboard Language | Select the keyboard layout and input language for the virtual machine (e.g., English, Chinese, etc.). | It must match the operating system's language settings to avoid input issues. It is recommended to keep the default setting. |

### **Graphics Card Type Comparison Table**

| Graphics Card Type | Applicable Scenarios | Features |
| --- | --- | --- |
| Cirrus Graphics Emulator | For scenarios with low compatibility requirements, such as older operating systems or applications that don’t need high-performance graphics. | Basic compatibility support, with lower performance. |
| VGA Graphics Emulator | For most virtual machine scenarios, suitable for general applications and operating systems (e.g., office tasks, web browsing, etc.). | General graphic support, balancing performance and compatibility. |
| VMVGA Graphics Card | For scenarios requiring higher graphic performance, such as graphic design, video editing, and other professional applications. | Provides better graphic performance and functionality support, optimized for complex graphic tasks. |
| Virtio Graphics Card | For scenarios with extremely high graphic performance requirements, such as gaming, virtual reality (VR), 3D rendering, etc. | Provides hardware acceleration through virtualization technology for high-performance graphic processing. |

## **Import a Virtual Machine**

The "Virtual Machine" application provides multiple methods for importing virtual machines. Users can click the [New] button on the virtual machine management page, select [Import Virtual Machine], and open the import wizard window to start the import process.

### **Import from Disk Image**

1. When selecting [Import from Disk Image], choose the image to import. It supports manually uploading local images.
2. After selecting the image file, click [Next] to continue.
3. Specify the storage location where the virtual machine data will be stored. Users can choose the appropriate storage location based on their needs.
4. After selecting, click [Next] to continue. The system will automatically set the virtual machine’s system type based on the selected image file.
5. If users have other configuration requirements, they can adjust them at this step. For example, users can modify the virtual machine’s memory size, CPU cores, disk capacity, and other parameters to meet the virtual machine's operating needs.
6. After completing the configuration, click the [Finish] button. The system will start creating the virtual machine instance.

### **Import from OVA File**

1. If users choose [Import from OVA File], they first need to locate the required OVA image file in "Files" and click the [OK] button to add it to the import list.
2. After adding the file, click [Next] to proceed.
3. Specify the storage location where the virtual machine data will be stored. Users can choose the appropriate storage location based on their needs.
4. After selecting, click [Next] to continue.
5. In the next steps, users can configure basic information such as the virtual machine’s name, system type, and network settings, along with advanced options.
6. For example, users can set an easily recognizable name for the virtual machine and choose the appropriate system type.
7. After completing the configuration, click [Next] to proceed to the final step.
8. Once the configuration is confirmed to be correct, click [Finish] and the system will begin creating the virtual machine instance.

**Notes**

- Disk image imports support the following file formats:

| File extension |
| --- |
| .img |
| .qcow2 |
| .vdi |
| .vmdk |

- A single virtual machine instance can configure up to 10 network modes.
- For more information on the differences in virtual machine network settings, please refer to the["Virtual Machine Networking Overview"](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImlkIjo2NDIsImFydGljbGVJbmZvSWQiOjIzMywiY2xpZW50VHlwZSI6IlBDIiwiYXJ0aWNsZVZlcnNpb24iOiIiLCJwYXRoQ29kZSI6IiJ9)for detailed information.

## **About OVA**

The UGOS Pro system allows users to export existing virtual machine instances as OVA files. OVA (Open Virtualization Format Archive) is a standard format that packages virtual machine configurations and disk images, making it easier to migrate or back up virtual machines across different virtualization platforms.

By exporting an OVA file, users can save all the configuration information and data of the current virtual machine, allowing for quick recovery or migration when needed. Importing an OVA file enables users to skip the complex steps of manually configuring virtual machine parameters, offering a simpler and faster virtual machine creation process. Additionally,the import feature can be used to easily transfer virtual machines from one volume to another, enhancing data management flexibility.

### **Export OVA File**

The virtual machine's OVA file export feature allows users to package the virtual machine's configuration and data into an OVA file for sharing or backup. OVA (Open Virtualization Appliance) is an open virtual machine format that contains the virtual machine's disk, configuration files, and other necessary metadata. This feature is highly useful for simplifying the migration and recovery of virtual machines. Below are the details about the virtual machine OVA file export functionality.

### **How the OVA File Export Feature Works**

The OVA file export function works by packaging the virtual machine's disk image and configuration files into a standard OVA file. This file can be imported and used by other UGREEN NAS virtual machine applications, enabling cross-device migration and deployment of virtual machines.

### **Advantages of the Export Feature**

- By exporting an OVA file, users can easily migrate virtual machines to other UGREEN NAS devices without manually reconfiguring parameters.
- Users can share the OVA file with other users or team members, allowing for the rapid deployment of identical virtual machine environments.
- Users can export the virtual machine as an OVA file for backup purposes, enabling quick restoration of the virtual machine when needed.

### **Steps to Export OVA File**

1. Open the virtual machine management interface and select the virtual machine to export.
2. Click the [···] > [Export as OVA] option.
3. The system will prompt you to select the export path and file name. Confirm and start the export process.
4. Once the export is complete, users can share the generated OVA file with other users via network sharing, storage devices, or other methods.
5. Users receiving the OVA file can import it into their UGREEN NAS to deploy the same virtual machine environment.
6. Open the virtual machine management interface, select [New] > [Import from OVA File].
7. Choose the OVA file to import, and the system will automatically parse and import the virtual machine's configuration and data.
8. After the import is complete, users can start the virtual machine and perform relevant configurations and operations.

**Notes**

- **File Size**: The OVA file contains all the virtual machine's disk data, which can be very large. Ensure sufficient volume and bandwidth are available during export and transfer.
- **Sensitive Data**: Before sharing the OVA file, ensure that the virtual machine does not contain sensitive or private data. If necessary, perform data cleaning or encryption.

## **About Disk Image Import**

In addition to supporting the import of OVA files, the UGOS Pro system also provides the ability to import virtual machines from disk image files. Users can quickly create virtual machine instances by importing existing disk image files, allowing them to continue using their existing operating systems and applications. This feature supports various common disk image formats such as .img, .qcow2, .vdi, and .vmdk, ensuring data compatibility and flexibility across different virtualization platforms.

### **Advantages of Importing Disk Images**

1.Flexibility and Compatibility: Supports multiple mainstream virtual machine disk formats, including .img, .qcow2, .vdi, and .vmdk, allowing seamless migration of virtual machines from different platforms to the UGOS Pro system.

2.Quick Migration of Existing Systems: By importing disk images, users can quickly migrate existing virtual machine data to UGOS Pro without the need to reinstall the operating system or manually configure applications.

### **Import Process**

1.Select [Import from Disk Image], which supports uploading local image files or choosing an existing image from the image library.

2.Specify the storage location for the image data, and configure virtual machine parameters such as system type, CPU, memory, and network settings.

3.Once the configuration is complete, the system will begin creating the virtual machine and load the data from the disk image.

## **Start Virtual Machine Instance**

To start a virtual machine instance, select the virtual machine you want to power on (the virtual machine status is "Stopped"), and click [Power Control Button] > []Start].

## **Access Virtual Machine Instance**

To access a virtual machine instance, select the virtual machine you want to access (the virtual machine status is "Running"), and click [···] > [Connect from New Page]. The NAS will open the virtual machine instance in the browser.

**Notes:**

If you are not logged into UGOS Pro in the browser, you will need to log in with the administrator account when opening the virtual machine from the browser. After logging in, return to the client and click "Connect from New Page" again.

## **Delete Virtual Machine Instance**

To delete a virtual machine instance, select the virtual machine you wish to delete, then click [···] > [Delete] to remove the virtual machine instance. Please proceed with caution, as the deleted virtual machine cannot be recovered.

# **About Virtual Bridging**

A virtual machine instance configured with virtual bridging can obtain an independent IP address and network permissions within the same local area network (LAN) as the NAS. This setup allows the virtual machine to function as a separate device with its own IP address, enabling communication with external devices through the physical network.

For example, in bridge mode, the virtual machine can automatically obtain an IP address via DHCP, just like a physical machine.

The virtual machine's network traffic is transmitted directly through the NAS's physical network card, allowing external devices to detect the virtual machine's presence and enabling bidirectional communication. For instance, other devices in the LAN can directly access the services provided by the virtual machine (such as reverse proxy) using its IP address.

# **Related Link**

## [How to enable USB device passthrough for virtual machines on UGREEN NAS](https://alidocs.dingtalk.com/i/nodes/dQPGYqjpJYgjGpvmiYaLBoGlWakx1Z5N?editNotify=true&corpId=ding39a9d20442a933ec35c2f4657eb6378f&utm_medium=im_card&iframeQuery=utm_medium%3Dim_card%26utm_source%3Dim&utm_scene=team_space&utm_source=im)
