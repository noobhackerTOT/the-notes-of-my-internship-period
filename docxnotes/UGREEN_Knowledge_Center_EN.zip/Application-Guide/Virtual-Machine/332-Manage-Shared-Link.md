# Manage Shared Link

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzMyIn0=

The virtual machine sharing link feature is a convenient method that allows users to share access to a virtual machine with others. By generating and sharing a link, multiple users can simultaneously access and use the same virtual machine from different locations. This feature is highly beneficial for scenarios like team collaboration and remote access. Below are the detailed aspects of this feature.

## How It Works

The sharing link feature enables access to a virtual machine by attaching its access permissions to a generated link. Other users can access and operate the virtual machine simply by clicking the link. The link's access permissions and settings can be customized by the creator to ensure both security and flexibility.

## Key Advantages

- **Enhanced Collaboration:** Team members can simultaneously access and operate the same virtual machine, facilitating teamwork and project management.
- **Convenient Remote Access:** Users can access the virtual machine anytime, anywhere via the sharing link, making remote management easier.

## Usage Steps

1. **Generate a Sharing Link:**

- Open the virtual machine management interface and select the virtual machine you want to share.
- Choose the option **“··· > Generate Share Link.”**
- Configure the link’s access settings (e.g., access via local network or UGREENlink).
- Click **“Confirm”** to generate the link. The link will then be available under **Settings**and **Shared Link Management** in the virtual machine interface.
- Copy and share the link with other users.

1. **Access the Shared Link:**

- Users who receive the link can click it to be redirected automatically to the virtual machine interface.

1. **Manage Sharing Links:**

- Administrators can view, manage, or delete generated links at any time in the virtual machine instance settings.

**Notes**

- **Access Control:** Regularly review and manage shared links, deleting those no longer needed to prevent unauthorized access.
- **Network Requirements:** The use of sharing links relies on the network environment. Ensure the recipient has a stable network connection for seamless access.
