# Manage Snapshot

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzMxIn0=

The snapshot feature allows you to save the current state of a virtual machine and restore it at any time. This enhances efficiency in system maintenance, software testing, and fault recovery. For instance, when testing new software or configurations, creating a snapshot ensures that you can quickly revert to a previous stable state if any issues arise, without the need to reconfigure the entire system. Below is a detailed explanation of the virtual machine snapshot feature.

### **Snapshot Functionality**

A snapshot acts as a saved point based on the virtual machine's current state. When creating a snapshot, the virtual machine records the current memory contents, configuration settings, and changes to disk data. You can restore the system to the snapshot state at any time without affecting subsequent operations or data. Snapshots are typically used in the following scenarios:

- **Before System Updates**: Create a snapshot before performing system updates or software installations on the virtual machine instance. If the update or installation fails, you can quickly revert to the previous state.
- **Fault Recovery**: In case of a system failure or crash of the virtual machine instance, the snapshot feature allows rapid system recovery, improving availability and reliability.

### **Advantages of Snapshots**

- **Data Protection**: Snapshots safeguard critical data and system states, preventing data loss due to operational errors or system crashes.
- **Flexibility**: Create multiple snapshots as needed and switch between them freely, enhancing the flexibility and efficiency of virtual machine management.
- **Time and Resource Savings**: Restoring the system using a snapshot is significantly faster than reinstalling the operating system and reconfiguring the environment, saving considerable time and resources.

### **Steps to Use Snapshots**

**1. Create a Snapshot**

Open the virtual machine management interface and select the virtual machine for which you want to create a snapshot. UGOS Pro provides multiple methods to create snapshots:

- Select **··· > Create Snapshot** to quickly generate a snapshot named with the current timestamp.
- Select **··· > Snapshot Management**, then click **Create Snapshot** to generate a snapshot named with the current timestamp.
- Select **··· > Settings**, navigate to **Snapshot > Create Snapshot**, and generate a snapshot named with the current timestamp.

**2. Restore a Snapshot**

In the virtual machine management interface, select the virtual machine you want to restore. Choose **··· > Snapshot Management**, locate the desired snapshot version, and click the ”**Restore“** button. The system will revert the virtual machine to the state when the snapshot was created.

**3. Manage Snapshots**

You can rename or delete snapshots for easier management and maintenance:

- Click the “**Rename”** button to customize the snapshot name.
- Click the ”**Delete“**button to remove unnecessary snapshots.

#### **Notes**

- **Performance Impact**: Frequent creation and deletion of snapshots may affect the performance of the virtual machine due to increased disk I/O operations.
- **Storage Space**: Snapshots consume additional storage space, especially when significant data changes occur. Ensure sufficient storage capacity is available.
