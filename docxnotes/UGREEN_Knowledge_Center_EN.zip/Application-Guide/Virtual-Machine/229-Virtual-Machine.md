# Virtual Machine

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjI5In0=

**Applicable Version:** UGOS Pro 1.10.0.0092 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## App Introduction

Virtual Machine is a virtualization solution that allows you to create and manage multiple virtual machine instances on your NAS, supporting operating systems such as Windows, Linux, iStore, OpenWRT, and iKuai. This feature enables you to easily set up and manage virtualized environments in home or office settings.

Virtual Machine supports functionalities including snapshots, share links, and OVA file import/export. You can use snapshots to save and restore virtual machine states, share access via generated links, or export virtual machine configurations as OVA files for others to import and use quickly.

## Installation & Access

1. Open the [App Center], locate the Virtual Machine app in the application list, and click **"Install"** to launch the installation wizard.

2. Follow the wizard prompts to complete the installation.

After installation, you can access the Virtual Machine app through the following paths:

● **Mobile**: Open the UGREEN NAS App, and tap the [Virtual Machine] icon on the home screen or in the "All" section.

● **PC**: Log in to the NAS management interface, and click the [Virtual Machine] icon in the app center or on the desktop shortcut.

## Virtual Machine Requirements and Limitations

Before creating a virtual machine, please review the following basic requirements and limitations. This will help you better plan system resources and configure virtual machines.

1. **Set Storage Space During Initial Use**

When using the Virtual Machine app for the first time, the system will prompt you to select a storage space for storing virtual machine data and instances. You can manage storage spaces in [Manage] > [Volume].

2. **System Resource Requirements**

Virtual machines consume significant CPU, memory, and storage resources. For an optimal experience, it is recommended to have at least 16 GB of device memory.

3. **Volume**

It is recommended to use storage spaces created with SSD drives for virtual machines to achieve faster read/write speeds and more stable performance.

4. **Space Requirements**

The space required for each virtual machine instance depends on the operating system and applications it runs.

5. **Instance Explanation**

Virtual machines created within the Virtual Machine app are referred to as **"**instances**"** to distinguish them from the app itself. You can create multiple instances.

6. **Image and Network Limitations**

● A single virtual machine instance supports a maximum of 3 images.

● A single virtual machine instance supports a maximum of 10 networks.

● A single virtual machine instance supports a maximum of 10 virtual disks.

## Virtual Machine Homepage

On the Virtual Machine homepage, you can view and manage all virtual machine instances:

● **View Instance Information**: Check the virtual machine name, system type, data storage location, and operational status.

● **Start a Virtual Machine**: Click the **"Power Button"** next to the virtual machine instance and select **"Start"** to start it.

● **Access a Virtual Machine**: Select a running virtual machine, click **"···"**, and choose **"Connect from new page"** to enter the virtual machine system.

● **Manage Instances**: Click **"···"** on the right side of an instance to perform additional actions, including modifying configurations, creating snapshots, generating share links, exporting OVA files, or deleting the virtual machine.

● **Create a New Instance**: Click **"New VM"** to create a virtual machine. You can choose to upload an image or import an OVA file and configure relevant parameters.

## Management Operations

Under the [Manage] options on the Virtual Machine homepage, you can perform the following operations:

● **Volume Adjustment**: Modify the data storage location of virtual machine instances.

● **Network Settings**: View existing virtual subnets or create new custom subnets.

● **Image Management**: Upload or manage local ISO image files.

● **Log Viewing**: View and manage virtual machine operation logs.

## Virtual Machine Status

When a virtual machine is running but cannot be connected due to system errors or application exceptions, it will be displayed with an "Error" status.

![](https://file1-cn.ugnas.com/admin/article/2025-10-24/e113b0ba0c514fc5b823ad7fc0e8bebe.webp)

## Virtual Machine Performance Optimization Tools

The Guest Tools are designed to enhance virtual machine performance and improve user experience. After installation, they optimize memory display, improve virtual disk and network adapter performance, and extend graphics resolution support.

For detailed configuration steps, please refer to[Virtual Machine Performance Optimization Tools (Guest Tools) User Guide](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImlkIjoxMjA1LCJhcnRpY2xlSW5mb0lkIjo0MDksImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ%3D%3D).
