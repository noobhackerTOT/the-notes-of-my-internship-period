# Security

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTIzIn0=

## Feature Overview

"**Security**" is a security application provided by the UGOS Pro system. It is designed to scan system settings and software applications within UGOS Pro. "**Security**" delivers real-time, comprehensive protection status and scheduled malware scanning strategies to ensure your system is protected against trojans and viruses, safeguarding both the system and your data.

**Key Features:**

● Powered by the ClamAV antivirus scanning engine, enabling virus detection and removal for both system files and user files within UGOS Pro.

● Supports full scan, custom scan, and scheduled scan. Users can configure scanning strategies as needed to perform regular file scans within UGOS Pro.

● Enables "**Real-Time Protection**" to continuously monitor newly added or modified files within UGOS Pro.

● Detects and identifies suspicious files, with support for configuring default handling rules and managing files in the quarantine area.

● Automatically updates the virus definition database to address evolving network threats, ensuring detection and protection capabilities remain up to date.

● Provides detailed scan logs, supporting searches by date, severity level, and user, as well as exporting or clearing scan records.

**Installation and Usage**

1. Go to "**App Center**"＞"**Utility"**, select "**Security**", and click "**Install**".

2. After installation, you can open the application directly. You can also launch the service from the application icon in "**My apps**".

**Note:** After installing "**Security**", the application is available to all administrators by default and is not visible to general users.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/c1ae0ca8d7864b59ad983602e4f53e16.webp)

## Overview

On the "**Security**"＞"**Overview**" page, you can enable real-time protection, view the time elapsed since the last scan, check the total number of suspicious files detected so far, and perform a "**Full Scan**", "**Custom Scan**", or access the "**Quarantine**".

● **Real-Time Protection**: When enabled, the cumulative runtime of real-time protection is displayed. The system automatically detects and scans newly added or modified files on the device. If suspicious files are found, they are handled according to the default action rules.

● **Full Scan**: Initiates a scan and removal process for all files on the system.

● **Custom Scan**: Allows you to specify the scan scope, select specific file types to scan, and define how suspicious files are handled.

● **Quarantine**: Opens "**Scan Records**"＞"**Quarantine**". You can manage quarantined files, including searching, deleting, trusting, or recovering files.

## Scheduled Scan

You can manage scheduled scan strategies, create new ones, trigger scans immediately, and edit existing scan records.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/5dc98ecf0ea1455496e9844eddee47c8.webp)

### Creating a New Scan Strategy

1. Go to "**Security**"＞"**Scheduled Scan**", then click "**New**" to enter the "**New scheduled scan strategy**" wizard.

2. You can configure the following settings:

● **Strategy name**: Enter a name for the scan strategy.

● **Target scope**: Specify the scan scope by selecting "**System Files**" and/or "**User Files**" (multiple selections supported).

**System Files**: Includes system and application programs files.

**User Files**: Files accessible by this user account.

● **Scan specific file types**: Choose "**All Types**" or "**Specific**". Specific types include documents, multimedia files, compressed archives, and other formats. Multimedia includes picture, videos, and audio file type.

● **Suspicious file action**: Choose "**Ignore**" or "**Move to Quarantine**".

● **Scan frequency**: Select "**Eveyday**", "**Weekly**", or "**Monthly**". Depending on the selection, configure the corresponding date and time as guided.

● **Triger immediately after creation** (optional): When selected, the scan strategy will be triggered immediately after it is successfully created.

3. Click "**Done**" to create the scan strategy.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/80c85ac169ee41a8b3af24476c768ca3.webp)

### Editing a Scan strategy

1. Go to "**Security**"＞"**Scheduled Scan**", and select an existing scan strategy.

2. Click "**Operation**" and choose the operation you want to perform:

● **Edit**: Modify the scheduled scan strategy.

● **Enable**: Activate the scan strategy.

● **Disable**: Deactivate the scan strategy.

● **Delete**: Remove the scan strategy.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/89ac8f5e10f04de1b91b7304089a1ccc.webp)

### Running a Scan strategy Immediately

1. Go to "**Security**"＞"**Scheduled Scan**".

2. Select an existing scan strategy and click "**Scan now**".

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/03f208a51b1644048c120cdd85ff7a9f.webp)

## Scan Records

On the "**Scan Records**" page, you can view and manage all security scan logs. This page consists of four main sections: Scan Records, Real-time protection records, Quarantine, and Whitelist.

### Scheduled Scan Records

After the system executes the scheduled scan tasks you have created, all scan results are displayed in this list.

● **Handle threats**: If suspicious files are detected in the scan results, click "**Check & Handle**" for the corresponding record. You can perform actions such as "**Delete**", "**Quarantine**", or "**Trust**" on the suspicious files.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/783c176e1ae241be8429f45bb0e1b191.webp)

● **Clear records**: To remove expired or unnecessary logs, select the relevant scan records and click "**Clear Records**" in the top menu bar.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/e44f6165e8c346df8ef3c79cc448a472.webp)

● **Export records**: Scan records can be exported as local files (CSV or HTML format supported) for archiving or further analysis.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/94439e5ce2f6477d843dd7c7cc8d6dbb.webp)

### Real-Time Protection Records

This page displays security threats intercepted in real time. When the system detects file anomalies in the background, it immediately blocks the threat and records detailed information here for your reference.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/9f0fcd931c464e3ab7047de04624d6ff.webp)

● When "**Real-time Protection**" is enabled on the "**Overview**" page, the system automatically monitors file changes.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/64c5883c554f4555b117062e05ee6d2e.webp)

### Managing Quarantine

The "**Quarantine**" stores files identified as dangerous by the system and restricted from execution. Quarantined files cannot be accessed or run, ensuring system security.

You can perform the following actions on files in the quarantine:

● **Delete**: Permanently remove the file and free up storage space.

● **Trust**: Move the file to the "**Whitelist**" so it will no longer be scanned.

● **Recover**: Restore the file to its original location (ensure the file is safe before restoring).

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/205ff1e99ade420882f05e5bbaf33478.webp)

### Managing the Whitelist

The "**Whitelist**" contains all files or folders that you have marked as safe.

● **Scan rules**: Scan tasks automatically skip all files or directories in the Trusted List and no longer scan them.

● **Add to whitelist**: Click "**Add**" to select files or folders and add them to the "Whitelist".

● **Remove from list**: For files you no longer trust, select them and click "**Remove**". Once removed, the files will be scanned again during the next scan.

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/5fe11dbfec27443ca87f932e2eca431a.webp)

## Security Logs

On this page, you can view, search, export, and clear all "**Security**" logs, including log level, user, date and time, and log content.

**Searching Logs:**

1. Click the search box to enter keywords, or refine the search using the following filters:

● **Date & Time**: Specify a date range to search logs.

● **Level**: Select the log levels to display (multiple selection supported).

● **User**: Filter logs by user (multiple selection supported).

2. Click "**Confirm**" to search for logs that match the specified criteria.

**Exporting and Clearing Logs:**

1. **Export logs**: Click "**Export**" and choose to export the logs as a CSV or HTML file.

2. **Clear logs**: Click "**Clear**" to remove logs within a specified time range (3 months ago, 6 months ago, 1 year ago, or All).

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/d9b4674883334d088daff66989ca329f.webp)

## Security Settings

### Virus Definition Database

**"Security**" uses the virus definition database provided by the **ClamAV** scanning engine to ensure your system is protected with the latest virus detection capabilities. The following options are available for managing and updating the virus definition database:

● **Automatic updates**: When "**Auto Update**" is enabled, you can choose to check for and install updates daily or weekly. The system will periodically check for updates and automatically apply them when a new version is available, ensuring the virus definition database remains up to date.

● **Version information**: View the current version of the virus definition database to stay informed about the antivirus data currently in use.

● **Manual update check**: In addition to automatic updates, you can manually check for available updates at any time. Click "**Check for Updates**", and the system will verify whether a newer virus definition database is available. If an update is detected, you will be prompted to proceed with the update.

● **Update strategy**: Customize the automatic update frequency by selecting daily or weekly, allowing the system to maintain the virus definition database according to your preferences.

**Note: What Is ClamAV?**

ClamAV (Clam AntiVirus) is an open-source antivirus software originally designed for email gateways. Over time, its functionality has expanded to include file system scanning, real-time protection, and other security use cases. ClamAV is developed and maintained by the ClamAV community and aims to provide efficient, reliable, and free virus scanning services.

**Key Features:**

● **Malware detection**: ClamAV can detect and remove a wide range of malicious software, including viruses, trojans, worms, adware, and spyware. It uses an extensive virus signature database that is continuously updated to address the latest cyber threats.

● **Cross-platform support**: ClamAV supports multiple operating systems, including Windows, Linux, and macOS, providing cross-platform protection.

● **Email scanning**: Originally designed for email gateways, ClamAV efficiently scans and filters malicious content in emails, helping prevent the spread of malware via email.

● **Real-time protection**: Supports real-time scanning to monitor newly added or modified files within the file system, enabling timely detection and handling of potential threats.

● **Custom scanning**: Allows users to customize scan scopes and strategies based on their needs, such as full system scans or scans of specific folders.

**ClamAV in UGOS Pro:**

In the UGOS Pro system, the ClamAV virus scanning engine is used to scan both system files and user files on UGREEN NAS devices, ensuring the security of the device and stored data. The following are applications of ClamAV in UGOS Pro:

● **Virus detection and removal**: ClamAV is used to perform scheduled or real-time virus scanning on files stored on UGREEN NAS devices, protecting system and user files from malware.

● **Real-time protection**: Continuously monitors and scans newly added or modified files on the device, promptly detecting and handling suspicious files to provide comprehensive protection.

● **Automatic updates**: The ClamAV virus definition database can be updated automatically, ensuring virus detection data remains current and capable of responding to evolving network threats.

### Real-Time Protection

When "**Real-time Protection**" is enabled, "**Security**" automatically detects and scans newly added or modified files on the device. If suspicious files are found, they are handled according to the default action rules.

### Default Handling Rules

When suspicious files are detected, you can choose one of the following actions:

● Ignore

● Move to Quarantine (quarantined files cannot be accessed or executed)

### Intrusion Protection

Intrusion prevention strategies, such as device access control stategy, firewall, and self-signed certificate are set in [" **Control Panel** ">" **Security** "](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMCYmTmRkSFJOIn0=).

### Notification Management

When enabled, suspicious files detected during scan tasks will be reported to designated recipients via the "**Notification Center**".

● **Notification Frequency**: In the "**Send notidication**" part, You can choose to receive notifications "**when the scan is completed**", "**when suspicious files are found**", or for "**All**" events. Notifications will be sent to the "**Notification Center**" accordingly.

● **Notification Scope**: In the "**Notify to**" part, notifications are sent to the creator of the scan task by default,. You can also choose to notify "**All administrators**" and/or the "**File owners**" (multiple selection supported).

![](https://file1-cn.ugnas.com/admin/article/2025-12-26/e7abdd4bd5e6444fa4dbb9ce43b33172.webp)

## FAQ

Q: If "**Security**" is uninstalled while a scan strategy is running, will the ongoing scan task be terminated?

A: "**Security**" can be uninstalled normally; however, any ongoing scan tasks will be forcibly terminated. If an administrator has the Security application window open at the time of uninstallation, the window will be automatically closed.
