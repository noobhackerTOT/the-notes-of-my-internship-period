# File Version Explorer

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzE2In0=

## Feature Overview

**"File Version Explorer**" provides version management and recovery capabilities for folders, enabling administrators to efficiently track and restore file states at different points in time, thereby ensuring data security and integrity. In cases of accidental deletion or incorrect operations on folders, files can be recovered through File Version Explorer to prevent data loss.

Once version management is enabled for a folder, every change to frequently modified files (such as project files) is recorded, allowing quick search and restoration to any specific version.

Shared folders that have been synchronized via the "**Sync & Backup**" application support file version management and recovery. This feature enables administrators to efficiently track and restore file states at different points in time, ensuring data security and integrity.

After enabling File Version Explorer:

● **Recovery from accidental operations**: Restore files that were accidentally deleted or modified, preventing data loss.

● **File state tracking**: View the state of a file at different points in time and track how its contents have changed.

● **Version management**: Records every change to frequently modified files (such as project files), supporting quick search and restoration to any version.

## Installation and Access

1. Open "**App Center**", locate the "**File Version Explorer**" application, click "**Install**", and complete the setup by following the installation wizard.

2. After installation, you can access the application in the following ways:

**Desktop / Web**: Log in to the NAS via the UGREEN NAS desktop client or web interface, then click the "**File Version Explorer**" icon on the desktop or under "**My apps**".

## Version Retention

### Enabling Version Retention

1. Go to the "**Sync & Backup**" application.

2. On the administrator settings page, locate "**Version retention**" and enable this option.

3. Click "**File Version Explorer**" to directly jump to the File Version Explorer application for further configuration.

**Note**: Files for which "**Version Retention**" is not enabled cannot be recovered if they are accidentally deleted.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/e572f421dba94dbf86855fa2b53b477c.webp)

### Configuring Version Retention

1. **Settings**: Open the "**File Version Explorer**" application and click "**Settings**" to enter the configuration page, where all existing personal and shared folders on the system are listed.

2. **Fuzzy search**: Use partial folder names to quickly search for the folders you want to configure.

3. **Version retention**: Enable or disable version retention for folders. Personal or shared folders with active sync tasks will have version retention enabled automatically. By default, the system retains 8 versions, with a maximum of 32 versions. You can adjust the number according to your needs. When the number of retained versions exceeds the limit, older versions will be automatically deleted.

When version retention is disabled, the system will no longer keep any historical versions for the shared folder. Accidentally deleted files cannot be restored, and all existing file history versions will be permanently removed.

4. **Number**: Displays the number of versions retained for the current folder. This value can be adjusted at any time. When reducing the version count, the system will automatically delete excess versions.

5. **Size**: Shows the amount of storage space occupied by file versions for folders with version retention enabled.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/1f32e9dfdabb48c68149dcdb1538e855.webp)

## Version Management

After completing the version retention settings, enter the "**File Version Explorer**" interface. You can perform the following operations:

● **View folders with version retention enabled**: On the left side of the "**File Version Explorer**" interface, all shared folders with "**Version retention**" enabled are displayed. The file paths, directory structure, and file list are consistent with those shown in "**Files**" app. If personal folders are enabled, a "**Personal Folder**" entry will be displayed (each logged-in user can only view their own personal folders).

● **Filter change records by date**: Use the "**Date Picker**" to view or filter change records by month. By default, the date picker selects "**Today**". You can also select a specific date, and the system will display the folder and file status for that day. The file area shows all files and folders as of the selected date and earlier.

**Note**: In the "**Date picker**", days with updates are highlighted. You can click a highlighted date to jump to that day’s files. Click "**Refresh**" button at the top of the page to refresh the file and directory view.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/90995a3588d04ba68c1cfe54a5cdbd27.webp)

● **View file history versions**: The system automatically generates multiple historical versions for shared files, recording their state at different points in time. Historical version information includes the file name, last modified date, version creation date, and size.

**How to access**: In the "**File Version Explorer**" interface, open a "**Shared Folder**", select a file, right-click it, and choose "**Version histories**". Alternatively, after selecting a file, click "**Version histories**" button in the upper-right corner of the page.

**Note**: Only single-file selection is supported for viewing history versions. History versions cannot be viewed when multiple files or folders are selected.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/6ae69236fcf84ccbbcf97985e7c44901.webp)

● **Download file history versions to your computer**:

**How to access**: Select a file, click "**Version histories**" to open the history version dialog, select a specific version, and click "**Download to the Computer**" to download it to your local device. You can view the download progress in "**Task Center**".

**Note**: Only single-file downloads are supported in the "**Version histories**" dialog. To download multiple files or folders, return to the "**File Version Explorer**" home page, hold the "**Shift**" key to select multiple files, then right-click and choose **Download to the computer**. The system will create multiple download tasks.

● **Copy file history versions to the NAS**:

**How to access**: Select a file, click "**Version histories**" to open the "**Version histories**" dialog, select a specific version, and click "**Copy to**" to copy it to the directory where the original file is located. After completion, you can manage the copied file in the corresponding directory within "**Files**" app.

**Note**: By default, the file is copied to the original directory and automatically renamed as "**OriginalFileName (ModificationTime)**", for example: **aaa(2023-03-30_121003)**. This operation does not affect the current version of the file.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/623cb9ad1baa41ec9c74a902d3d47026.webp)

● **Restore deleted files and folders**:

**How to access**: In "**File Version Explorer**", select the relevant folder and enable "**Show deleted items**" in the lower-right corner of the interface. Deleted items will be displayed with a red deletion marker. Select a single deleted file or folder, right-click it, and choose "**Restore**" to recover it and view its previous versions (this action is available only to administrators and users with read/write permissions). Restoration progress can be viewed in "**Task Center**".

**Note**: Regardless of whether files or folders were deleted via "**Files**" or other file access protocols and moved to the "**Recycle Bin**", they can still be viewed for the selected date as long as "**Show deleted items**" is enabled in "**File Version Explorer**".

● **Permanently delete files and folders**:

**How to access**: Select deleted files or folders, right-click, and choose "**Delete permanently**". In the confirmation dialog, click "**Permanently Delete"** again to remove them completely from "**File Version Explorer**".

**Note**: This action is available only to administrators and users with read/write permissions.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/c2e90689ecce4e36a69c2dc6c158e933.webp)

● **Search for files and folders**: To quickly locate files or folders, enter keywords in the top-right search box to search within the current page.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/0ccb7f7d054342df9ae6a4fdab07d5f5.webp)
