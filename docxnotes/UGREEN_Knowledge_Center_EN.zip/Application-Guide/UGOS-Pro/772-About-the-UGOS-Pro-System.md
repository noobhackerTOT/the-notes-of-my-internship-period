# About the UGOS Pro System

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzcyIn0=

**UGOS Pro** is an operating system developed by UGREEN specifically for NAS devices. It combines powerful data processing capabilities with a rich application ecosystem. Centered on stability and security, UGOS Pro offers comprehensive features such as files, remote access, data protection, Docker support, and multimedia services—greatly enhancing both the practicality and scalability of NAS systems.

## **Core Features of UGOS Pro**

### **System Settings and Personalized Configuration**

With an intuitive control panel, users can easily customize the UGOS Pro system for an optimal experience. Whether it's network settings, user permission management, or hardware configuration, users can fine-tune the system to precisely meet individual or team needs.

### **App Management and Updates**

The App Center offers an efficient ecosystem for managing applications, allowing users to quickly browse, install, and receive smart-pushed version updates—ensuring that all software remains up to date. It includes a wide range of professional tools and entertainment apps, catering to both productivity and multimedia needs, and enabling seamless multi-scenario application management.

### **Efficient Storage Management**

The storage management system allows users to flexibly configure RAID storage pools, storage volumes, and SSD caching. It also supports the management of hard drives and external storage devices to meet diverse storage requirements. The system guarantees secure and reliable data protection while delivering high-speed access and maximum flexibility—ensuring worry-free data storage.

### **Remote Access and Security Management**

With features like UGREENlink, users can securely access data stored on their NAS anytime, anywhere. UGOS Pro adopts advanced encryption technologies to ensure data security during transmission. It also provides fine-grained control over user accounts and file permissions, safeguarding user privacy and preventing unauthorized access.

### **Multimedia Services and Containerized Applications**

By installing the Theater and Music apps, users can efficiently build a personalized library while enjoying smooth playback performance. In addition, UGOS Pro supports **Docker** for containerized application management, enabling fast deployment and full lifecycle control of various image-based apps—greatly expanding the functional boundaries of the device.

### **Virtual Machine Support (DXP Series Only)**

The virtual machine feature is an advanced capability of the UGOS Pro system and is not supported on DH series UGREEN NAS devices. Please review the specifications of your NAS model before purchase or use to confirm whether it supports virtual machine functionality.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250613/71fff588-fadf-4c8d-a509-6c0125568e44.png)

## **Download the Client and Learn More**

To learn more about the UGOS Pro system, please visit [the official UGREEN NAS website.](https://nas.ugreen.com)

For first-time device setup, [download the client app](https://www.ugnas.com/support/download) or access the web version within your local network by visiting find.ugnas.com to log in to the UGOS Pro system.
