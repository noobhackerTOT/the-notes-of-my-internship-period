# Universal Search User Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzM5In0=

**Supported Series**: DH Series, DX Series, DXP Series, and iDX Series**Supported Platforms**: UGREEN NAS PC Client, Web Browser**Supported Version**: UGOS Pro firmware 1.15.12.0051 and laterSome features of the Universal Search app (such as**index configuration**) are currently supported only on iDX series devices.Screenshots in this document are for reference only. Actual interfaces may vary slightly depending on system or application versions. Please refer to the actual interface displayed on your device.

## Overview

**Universal Search** is the unified search portal of UGREEN NAS, offering powerful content search and semantic understanding capabilities. It integrates search functions across multiple applications, so you no longer need to switch between Theater, Music, Photos, Files, and more. Simply enter keywords—such as file names, tags, or app names—or even descriptive phrases in a single search box to quickly locate any content on your NAS, including files, videos, music, photos, and system settings.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/b6254d30bf674b96a7c3e1b6469fc79f.webp)

## Shortcuts

● **Open Search:** You can quickly launch Universal Search in two ways:

Method 1: Use shortcuts `Command+F` (Mac) or `Ctrl+F`(Windows)

Method 2: Click the search icon at the top-right corner of the UGOS Pro desktop

● **Quick Preview/Open**: Use the PgUp `↑` and PgDn `↓` keys to navigate results and press `Enter` to open

● **Close Search**: Press `Esc` to quickly hide the search box

## Search Settings

To achieve a more complete search experience, you can configure the indexing scope as needed.

When using the search feature for the first time, click the "**Search**" icon in the top-right corner of the desktop to open Universal Search and access the settings page.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/08d5c1a6db884121a02f710a86fa4329.webp)

To adjust settings later, enter a keyword to open the search results page, then click the "**Settings**" icon in the top-right corner.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/d08c4e14009b4ed5822618ad403bce3a.webp)

Alternatively, open the "**Control Panel**" app on your NAS, go to "**Indexing Service**", locate "**Universal Search**", and then click the "**Settings**" button on the right.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/979f127953e140339d311cd90d1a5d6a.webp)

### File Search Index Configuration

On the settings page, you can enable different levels of indexing:

● **File name search**: Basic indexing, enabled by default and cannot be disabled separately

● **Content search**: Enables searching within document text

● **Semantic search (AI)**: Allows understanding and searching based on core concepts (requires AI model support). For example, searching "work summary" can return relevant documents even if the exact phrase does not appear in the file.

● **Index maintenance**: If results are incomplete, try rebuilding the index to fix issues.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/b3cfcda1dc9340e5ba498859ae08712c.webp)

**Notes:**

● After enabling content or semantic search for the first time, the system requires time to build the index. During this period, some new files may not appear in search results immediately.

● Document semantic search relies on NPU computing power and is only supported on certain devices (e.g., iDX series). Availability depends on the actual interface and requires enabling related AI models in UGREEN AI.

### Exclude Path Settings

If you do not want certain private or system folders to appear in search results, you can add them to the "**Excluded path**" list.

1. Go to "**Exclude path**" in settings

2. Click "**Add**" to include personal folders, shared folders, or user folders

3. Select the folders to exclude

**Additional Note**: The system excludes the Recycle Bin and some hidden directories by default.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/4457f22e72a44c7f9b8383acdef92d05.webp)

### Application Result Scope Settings

On the "**Application**" settings page, you can choose which app content appears in Universal Search results. For example, if you do not want to see results related to "**Music**", you can disable the Music app.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/0807890261814fd68e122c98a338476a.webp)

## Using Search

After completing setup, you can quickly search all NAS content using keywords. With semantic search enabled, you can also use natural language descriptions to find relevant content.

### Search by Category

Universal Search supports filtering by category (such as Files, Photos, Theater, Music, etc.).
You can click the category tabs below the search bar on the results page to refine your search.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/71b050ae2b6d411096ee780dbdf9a629.webp)

### Viewing Search Results

Results are ranked based on relevance, including title, content, tags, and semantic matching. The most accurate results are displayed at the top, and matched keywords are highlighted.

On the search results page, you can:

● Double-click to open apps, folders, Control Panel settings, music, videos, images, or audio files

● Click the "**...**" button to download files or folders and quickly locate their storage path

● Use the Uliya assistant for conversational search, smart summarization, and document translation (applies to single files)

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/945980573e9a4046a0afbab995ae0157.webp)
