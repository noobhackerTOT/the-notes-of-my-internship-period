# Beginner's Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjg3In0=

**Applicable Version:** UGOS Pro 1.10.0.0092 and aboveScreenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

Welcome to the UGOS Pro System! To help you complete the initial setup smoothly, this beginner's guide walks you through the essential steps, including device initialization, enabling UGREENlink remote access, performing system updates, and safely shutting down your device.

## Accessing Your NAS Device

You can discover and register your NAS using a web browser.

1. Ensure that your NAS is powered on, connected to the router via an Ethernet cable, and that your computer is on the same local network (LAN) as the NAS.

2. Open your browser and visit [find.ugnas.com](http://find.ugnas.com). The system will automatically scan and display all available devices on the LAN. If no devices are found, refer to: [Common Issues When Devices Are Not Detected](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6MTczOCwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo1ODEsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ%3D%3D)

3. Once your device appears, click "**Connect"**to begin the registration process.

## Device Initialization Setup

On the initialization screen, follow these steps:

1. Set a device name (preferably easy to identify for future management), read and check to agree to the user agreement and the option to share usage experience, then click **"Next"**.

2. Create an administrator account and password (used for device management and configuration). After entering the account name and password, click **"Next"**.

3. Select the corresponding option based on your device's region, then click **"Next"** to continue.

4. You can choose to bind an administrator email to receive a verification code and complete the verification (skipping this step will not affect the process). After reading and agreeing to the User Agreement and Privacy Policy, click **"Next"** to continue.

5. Check the **"Update System"** option, and once the settings are complete, click **"Start System Initialization"**. You can modify this setting later in**"Control Panel" > "Update & Restore" > "Update Settings"**.

6. Wait for device initialization to complete. Once initialization is finished, you can access the UGREEN NAS system interface and enable more features.

**Note:**

● Please keep your administrator password secure and avoid using simple passwords.

● Do not power off the device or interrupt the network connection during initialization.

## Enable UGREENlink Remote Access

UGREENlink is a remote access feature for UGREEN NAS that allows users to access their home NAS devices anytime, anywhere via mobile phone, computer, or web browser. After enabling this service, you can remotely manage and access files on the NAS without the need for a public IP address.

**Steps to Enable**

1. Open the "Control Panel" app, then click **"Device Connection" > "Remote access"**.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/54ee8d6203bd483da5777be68b6916b2.webp)

2. Check the **"UGREENlink remote access"** switch. The system will prompt you to verify your UGREEN Account. Click **"OK".**

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/fa8bd7dc9bd1425fbb51da3bc94cbb1e.webp)

3. Enter your UGREEN Account and password to log in. If you have not registered an account, click **"Register now"** to complete the registration and then log in.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/9c5d89f5053e4431adb36817823c9998.webp)

4. After a successful login, enter a custom ID in the UGREENlink ID field, then click **"Apply"**to save.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/ec3b43c039d742aabac98f1bb651b830.webp)

5. After the ID verification is successful, the system will automatically generate the web access link and the UGREENlink client ID. You can use the web link for remote access or enter the UGREENlink ID in the client to log in.

### UGREENlink Service Access Methods

You can access UGREEN NAS through the following methods:

**Method 1: Access via Browser**

Web Access: Use the generated link to access directly. Example: If your UGREENlink ID is `myNAS123`, the web access link would be: `https://ug.link/myNAS123`

**Steps:**Open a web browser on your computer, enter the UGREENlink web access link in the address bar, such as `https://ug.link/myNAS123`, and press the Enter key to navigate to the UGOS Pro login page.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/2ad3c8c0aec84c0287298a44aa83fd0c.webp)

**Method 2: Access via Client**

Client: Enter the UGREENlink ID to log in. Example: If your UGREENlink ID is `myNAS123`.

**Steps:**

1. Download and install the UGREEN NAS PC/mobile app.

2. Enter your UGREENlink ID, along with your UGREEN Account and password.

3. Click **"Login".**

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/240a097569a24022bf5ddafaa9a30e37.webp)

**Note:**

● When enabling the UGREENlink service for the first time, you need to log in or register a UGREEN Account.

● The UGREENlink ID is unique. If you are prompted that the ID is already taken, please choose another ID.

## Update Device Firmware, Client, and Applications

To ensure system stability and compatibility, please keep the **NAS firmware, client software, and applications** up to date. Version mismatches may cause incompatibility issues or abnormal functionality prompts.

● Keep the NAS operating system firmware updated to the latest version.

● Ensure both desktop and mobile clients are updated to the latest version to avoid connection issues or missing features caused by outdated versions.

● Update installed system applications in time to ensure proper functionality and compatibility with the latest firmware.

For detailed instructions, please refer to the documentation: [How to Update the Firmware, Client, and Apps of UGREEN NAS?](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MzgyOSwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo2NDAsImFydGljbGVWZXJzaW9uIjoiMS4wIn0=)

## Shut Down the Device

To power off the NAS device, please follow the steps below to shut it down properly and ensure data safety.

**Method 1: Shut down via the UGOS Pro desktop interface**

1. Open the UGOS Pro desktop.

2. Click the user avatar in the upper-right corner and select **"Shutdown"**.

3. The system will automatically begin the shutdown process.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/df5df5e60f7543db9aaaa35152e5d0ac.webp)

**Method 2: Shut down using the physical power button**

1. Locate the power button at the lower-left corner of the device.

2. Press and hold the button for about 15 seconds. When you hear a **"beep"**, the device will begin shutting down.

## Related Links

● [How to create a storage pool and storage volume？](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6MTA2LCJ0eXBlIjoidGFnMDAxIiwicGF0aENvZGUiOiJwcm8wMDEsam96cmNpLHJzdG9sMyIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlVmVyc2lvbiI6IiJ9)

● [RAID Type Selection](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6MTM4LCJ0eXBlIjoidGFnMDAxIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVJbmZvSWQiOjEzMiwiYXJ0aWNsZVZlcnNpb24iOiIxLjAiLCJwYXRoQ29kZSI6InBybzAwMSxqb3pyY2kscnN0b2wzLHRnZXcydyJ9)

● [UGREEN NAS Products Compatibility List](https://nas.ugreen.com/pages/compatibility)

● [How to create personal folders and shared folders？](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6MTU2LCJ0eXBlIjoidGFnMDAxIiwicGF0aENvZGUiOiJwcm8wMDEsbmo0cHQ3LHdvNWFnbyIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlVmVyc2lvbiI6IiJ9)

● [User Management](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6NDksInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksMTgzbDkxIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0%3D)
