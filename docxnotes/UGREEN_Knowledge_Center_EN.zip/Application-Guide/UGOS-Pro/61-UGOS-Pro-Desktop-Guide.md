# UGOS Pro Desktop Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjEifQ==

## Feature Overview

After successfully logging into the UGOS Pro system, you will enter the UGOS Pro Desktop. This desktop provides an intuitive interface where you can perform a range of management and configuration tasks, including:

● Viewing and managing installed applications.

● Checking device status.

● Monitoring tasks and system notifications.

● Accessing personal information.

● Customizing system settings.

● Performing system operations such as "**Reboot**", "**Shutdown**", or "**Logout**".

## Desktop Main Menu

The desktop main menu is located on the left panel of the desktop and is used to manage and access applications on your NAS device. From here, you can:

● **Open Installed Applications**: This includes applications installed via Docker containers.

● **Install and Update Applications**: Open the "**App Center**", find the desired application in the list, and click "**Install**" or "**Update**" to perform the operation.

● **Manage Desktop Shortcuts**: After an application is installed, a desktop shortcut is automatically created. To remove a shortcut, locate the corresponding application icon in the desktop main menu, right-click it, and select "**Delete shortcut**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-18/2a5ad07f0e3b470aaa2b5570eeb67b83.webp)

## Taskbar

The taskbar is located at the top of the desktop. From left to right, the functional items include: Return to Desktop, My apps, Open Applications, Task Manager, Widget, LAN connection, Task Center, Notification Center, Search, and Personal Center("**Me**" section). The taskbar provides users with quick and convenient system management functions.

![](https://file1-cn.ugnas.com/admin/article/2026-06-18/3f1e5ad8bf4f46dba3a39fcf16930ef8.webp)

● **Return to Desktop**: Click this button to quickly return to the UGOS Pro desktop.

● **My apps**: View and open applications installed on the UGREEN NAS, including Docker container applications.

● **Open Applications**: Displays currently running applications and services, allowing for quick switching or closing.

● **Task Manager**: Shows real-time CPU and RAM usage as well as upload task progress. Double-click to view more detailed information, such as process usage, task progress, and upload speeds.

● **Widget**: View system information, resource monitoring, storage status, and account activity. Click "**Edit**" to add, remove, or rearrange widgets. (Widgets can also be enabled or disabled by going to "**Me**"＞"**Personal**"＞"**Menu bar**".)

● **LAN Connection**: Displays the status of **LAN**, **P2P**, **DDNS**, and other network connections.

● **Task Center**: Records and manages all ongoing or completed tasks. When performing file operations (such as file uploads or storage migration), a task window will pop up showing progress. Running tasks do not interfere with other operations, although system performance may be affected under high load.

● **Notification Center**: Displays system messages, including index rebuilding, error alerts, status updates, and application installation notifications, keeping you informed of system activity.

● **Search**: Enter keywords to quickly search for documents, images, videos, audio files, applications, and more for fast and efficient access.

● **Me (Personal Center)**: Provides account settings, personalization options, client version information, preferences, system reboot, shutdown, account switching, and log-out functions.

## Personal Center Settings

Through the "**Me**" section, you can manage account activity, account security, storage quotas, and personalization options.

**Account Settings:**

1. On the UGOS Pro desktop, click "**Me**" in the top-right corner.

2. In the expanded menu, click your username to enter the "**Account settings**" panel.

![](https://file1-cn.ugnas.com/admin/article/2026-06-18/34bebc700b2041248d6ec7701930ab10.webp)

● **Change User Avatar**: Click the avatar to change it. You can upload an image from the NAS or your computer, or use a default avatar. Supported formats: jpg, jpeg, png, gif, bmp, webp. Maximum file size is 8 MB.

● **Change Password**: Set or update your account password. The panel also shows the date of the last password change. Passwords must include uppercase and lowercase letters, and may include numbers and symbols, with a length of 6–127 characters.

● **Bind UGREEN Cloud Account**: After binding your UGREEN Cloud account, you can obtain the device access address through the cloud account portal.

● **View Account Activity**: Record and view the current account's activity logs, including connection times, client names and IP addresses, and access protocols.

● **Account Security**: Enable or disable "**Two-factor authentication**"(2FA). When enabled, logging into a UGREEN NAS device requires both the account password and a second-step verification (OTP), enhancing account security. For instructions on enabling 2FA, see [**2FA Two-Factor Authentication**](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTQ3OCwidHlwZSI6InRhZzAwMSIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo1MTAsImFydGljbGVWZXJzaW9uIjoiMS4wMCIsInBhdGhDb2RlIjoicHJvMDAxLHdvdHMxaixwOWNja3AsRTlkQmV5In0=).

● **View Storage Quota**: Displays the used capacity and quota of your personal folder.

**Personalization Settings:**

1. On the UGOS Pro desktop, click "**Me**" in the top-right corner.

2. In the expanded menu, click "**Personal**" to enter the personalization panel.

![](https://file1-cn.ugnas.com/admin/article/2026-06-18/440cf2d47fa3425298247eb895d25ea9.webp)

● **Desktop Wallpaper Management**: Click "**Select wallpaper**" to replace the wallpaper. You can upload images from the NAS or your computer, or use the default wallpaper. Wallpaper display modes include Fill, Fit, Stretch, Center, and Tile. Supporting bmp, jpg, jpeg, png, webp, gif. And the maximum file size is 8 MB.

● **Language & Format**: Switch system language, adjust date and time formats, and select temperature units.

● **Menubar**: Customize which taskbar features are enabled or disabled, includingconnection mode, search, widget, and resource monitoring.
