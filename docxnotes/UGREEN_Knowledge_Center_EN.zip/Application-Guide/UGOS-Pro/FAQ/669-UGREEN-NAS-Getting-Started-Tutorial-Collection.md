# UGREEN NAS Getting Started Tutorial Collection

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjY5In0=

This section provides a series of beginner tutorials designed to help new users quickly understand core functions such as**device setup**,**account management**, and**file transfer**, enabling an easy start with UGREEN NAS.

| Applicable Scenarios | Tutorial Titles |
| --- | --- |
| Hardware Selection & Installation | ● UGREEN NAS Products Compatibility List |
| ● UGREEN NAS Installation and User Guide Collection |  |
| ● Choose RAID Type |  |
| Device Registration & Login | ● Beginner's Guide |
| ● Log in UGOS Pro System |  |
| ● How to Remotely Access UGREEN NAS via UGREENlink Without Public IP? |  |
| ● How to Update the Firmware, Client and Apps of UGREEN NAS |  |
| User Account Creation & Management | ● Add Users |
| ● Manage Users |  |
| File Access & Transfer | ● How to use SMB protocol to achieve fast multi-terminal file transfer on the LAN? |
| ● How to Access Files on UGREEN NAS via WebDAV? |  |
| ● How to back up photos from your phone to UGREEN NAS? |  |
| Others | ● How to choose a file system for a UGREEN NAS volume? |
| ● How Hard Disks Work and Why They Make Noise |  |

Welcome to[the UGREEN NAS Knowledge Center homepage](https://support.ugnas.com/knowledgecenter-h5/#/)to explore more features and advanced tutorials!
