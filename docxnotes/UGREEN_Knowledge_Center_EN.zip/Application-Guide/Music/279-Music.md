# Music

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjc5In0=

## Feature Overview

**"Music**" is a dedicated music player application provided by UGREEN NAS, designed to help you efficiently manage, categorize, and play your personal music collection, allowing you to enjoy high-quality music anytime, anywhere.

**Music supports the following features:**

● **Categorized management:** Display music by album, artist, genre, and other dimensions for a clear music library.

● **Playlist management:** Create personalized playlists, with options to favorite, edit, or delete.

● **Multi-device playback:** Play music via mobile apps, web, or desktop clients; remote access is smooth and seamless.

● **Automatic metadata recognition:** Automatically read embedded metadata (such as ID3 tags) for intelligent categorization.

● **Album covers and lyrics display:** Show album covers and local lyrics to enhance the listening experience.

● **Lossless playback:** Support playback of mainstream lossless audio formats such as FLAC, APE, WAV, etc.

## Library Homepage

The "**Library**" is used to store and manage audio files. By providing a structured and efficient way to organize files, it helps users easily locate, categorize, and search for audio resources.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/93fd1d9d83174e418d0169ca0810b194.webp)

● **Left Sidebar:**
Provides music search, music category list, recently played tracks, favorited songs, and playlists. Music files include content from the "**Music**" folder or other indexed folders on the UGREEN NAS, organized into the following categories:

**Library:** Browse all music.

**Folder:** Browse music according to folder structure.

**Album:** Browse by album information.

**Genre:** Browse by music genre.

**Artist:** Browse by artist information, supporting multiple artist recognition.

**Recently Played:** View recently played music.

**My Favorites:** Display personal favorite tracks.

**My Playlists:** Create and name personal playlists by clicking the **"+"** button next to playlists.

● **Right Area**: This Area is used to display the song list and supports playing all music, batch operations (play, delete, add to playlist), sorting songs by date added, name, or artist, and switching the song display mode between list view and cover view.

● **Bottom Controls**： This areainclude a music player that supports displaying lyrics (by clicking the song icon), controlling playback, adding songs to favorites, adjusting the playback mode (repeat one, shuffle, sequential), adjusting the volume, and viewing the current playlist.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/4768e1e40cc741acb81009f2dc919f5a.webp)

## Managing Music

### Adding Music

**Preparation**
To enable the music library and add audio files, personal folders must first be activated. Non-administrator users need to contact an administrator to perform this operation.

1. Open the "**Control Panel**" app, go to "**User Management**">"**User**", and find the corresponding user account.

2. In the action menu, click "**...**", select "**Edit**", go to the "**Basic info**" settings page, check "**Enable personal folderfor this user**", and save the settings.

3. Once enabled, all users with access to Music will automatically have a `/Personal Folder/Music`directory, where they can manage and store their personal music files.

**Steps to Add Music**

You can add music from personal folders or shared folders to the music library.

● **Add Music to Personal Library**

1. In the "**Library**" interface, click the "**Settings**" button to enter the music library settings, then select "**Personal library**". The default associated path is `/Personal Folder/Music`, but you can add other folders.

2. Click "**Add**" and select other folders within the "**Personal Folder**" that contain music.

3. If no music files exist in the selected folder, go to "**Files**">"**Personal Folder**", select the "**Music**" folder or another folder containing music, and upload music files.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/6f3c656da2c041c0adf76ed11b637033.webp)

● **Add Music to Shared Music Library**

1. In the "**Library**" interface, click the "**Settings**" button to enter the music library settings, then select "**Shared library**".

2. Click "**Add**", select the shared folder containing music files, and configure access permissions and view/play scope for other NAS users.

3. After configuration, the music will be visible and playable on the music library homepage.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/db4298176b6e4c52868675ed044228e7.webp)

**Notes:**

● After adding multiple folders, you can view and play music by "**Folder**" in the left sidebar.

● To share music with all NAS users, store the files in a shared folder and add that folder in the music library settings.

● Music metadata extraction relies on reading the extended properties of audio files (such as ID3 tags) to obtain information like song title, artist, album, year, genre, and album cover for classification. File names alone are not used. It is recommended to use music management tools (e.g., [Music Tag](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6NDM4MywidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo2NzIsImFydGljbGVWZXJzaW9uIjoiMS4wIiwicGF0aENvZGUiOiIifQ==)) to complete metadata for better recognition.

● **Supported lyrics format:** Standard LRC files are supported. The "**Music**" app includes time-synchronized lyric display. (Lyrics files must have the same name and be in the same folder as the audio file for automatic recognition.)

● **Supported audio formats:**

**PC / Web Browser**: `.aac`, `.mp3`, `.wav`, `.ogg`, `.flac`, `.wma`, `.dff`, `.dsf`, `.alac`, `.aiff`, `.ape`, `.m4a`.

**Mobile (iOS / Android)**: `.aac`, `.aif`, `.aiff`, `.ape`, `.au`, `.flac`, `.mp3`, `.wav`, `.ra`, `.dts`, `.wma`, `.ac3`, `.amr`, `.m4r`, `.mka`, `.alac`, `.m4a`, `.ogg`

### Editing Music Information

You can view and edit information for music files in the library, including cover art, song title, artist name, album name, and select or customize the music genre.

**Steps:**

● In the right display area, hover over a song to reveal the "**Edit**" options, click "**...**", and select "**Music information**" to enter the music information editing page.

● After editing, you can browse and play music by Album, Genre, or Artist in the left panel.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/517aecf9578f4bbb90e0589035b0654f.webp)

### Browsing Music

After uploading music files, you can browse them in the music library.

● Select a category in the left panel to browse music by type.

● You can also click the "**Switch view**" button in the right display area to switch between "**List**" and "**Cover**" views.

**Note:** When the display mode is set to "**Cover**", only music files in APE, WAV, or FLAC formats will show album covers.

### Searching Music

You can quickly find music by entering keywords in the search bar at the top-left corner of the music "**Library**" homepage.

### Playing Music

● **Play Immediately:** In the right display area of the "**Library**" homepage, hover over a song, then click the "**Play**" button on the left or "**...**">"**Play**" to play the song. You can also use the "**Play**" button in the bottom player.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/d7a721aab24d4ed9aa16978c5ccebc38.webp)

● **Play next:** To adjust the order of songs in the list, hover over a song, click the operation button, and select "**Next**". The selected song will play immediately after the current song finishes.

● **Add to playlist for playback:** At the top of the right display area, click "**Batch operation**" button, select the songs you want to add to a playlist, and click "**Play**" to add them to the playback queue in bulk.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/438d9487401144c98dc53dc7905fb86a.webp)

● **Off timer**: To control playback duration, use the "**Off timer**" feature:

1. On the "**Library**" homepage, click the "**Settings**" button at the top, go to the settings page, and select "**Playback settings**".

2. Set the duration for timed stop. You can choose "**Never**", 15, 30, 60, 90, or 120 minutes, or enter a custom time manually.

3. To stop playback after the currently playing song finishes, check "**Stop when your music ends**".

## Creating Playlists

You can create personal playlists, add multiple songs at once, customize playback order, and reorder songs or playlists according to your preference.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/2476c5343522448d8c3302a5e61166b9.webp)

**Creating a Personal Playlist**

You can create a new playlist in two ways:

**Method 1:** In the left panel, click the "**+**" button next to "**Playlist**", create a new playlist, and give it a name (up to 20 characters).

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/af16247e4b2d41019ec899a92593a53e.webp)

**Method 2:** Select a single song and click "**Add to playlist**", or select multiple songs and create a new playlist from the popup menu.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/4077a2a4ad4f4e968dd6ead0c9c79545.webp)

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/0cd7b9fb265f418d86c94a51b4eb065b.webp)

**Adding Songs to a Playlist**

● **Add a Single Song:** Hover over a song, click "**Add to playlist**", and select the target playlist.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/497ec9acd0e14d64ab63af25be909dc6.webp)

● **Add Multiple Songs:** In the right display area, click "**Batch Operation**" button, select multiple songs, click "**Add to**", and select the target playlist.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/d5c87c711eb04dc2a66ac021636e9246.webp)

**Editing Playlist Information**

To edit a playlist:

1. Click the playlist name in the left panel to open its page.

2. Click "**Edit playlist**" button next to the playlist name to change the cover, name, or introduction.

3. Click "**Save**" when finished.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/c4613142c2054d2faea8816a0b77dd0f.webp)

**Sorting Songs in a Playlist**

You can sort songs in a playlist according to your preference. By default, songs are sorted by date added in descending order. Each playlist has an independent sorting order.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/2b57bc9f8d064bd9baeb590fccebbca2.webp)

Sorting Options:

● **By added time:** Default sorting method.

● **By name:** Sort alphabetically or by character order.

● **By artist:** Sort alphabetically or by character order.

● **Manual sorting:** Long-press and drag to reorder songs. Changes sync across devices. You can reorder up to 2,000 songs at a time. Click "**Confirm**" to apply.

![](https://file1-cn.ugnas.com/admin/article/2026-01-15/381e46d8c0af43299131432d6af08832.webp)
