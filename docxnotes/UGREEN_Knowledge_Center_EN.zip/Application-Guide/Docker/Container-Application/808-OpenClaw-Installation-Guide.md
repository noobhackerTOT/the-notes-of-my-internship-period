# OpenClaw Installation Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODA4In0=

## App Overview

OpenClaw is a personal AI assistant that runs locally on the user's device. It can interact with users through commonly used communication channels. UGREEN NAS provides deep customization for users, offering a "**one-click**" installation experience for full zero-code deployment.

**Note**: This application consumes a significant amount of system resources. Please ensure that your system has at least **2 GB** of available RAM. The installation process may take over**10 minutes**, which is normal.

### Supported Models

The following models currently support the OpenClaw application. More models are being adapted:

● **DXP Series**: DXP2800, DXP4800, DXP4800 Plus, DXP4800 Pro, DXP6800, DXP6800 Plus, DXP6800 Pro, DXP8800, DXP8800 Plus, DXP8800 Pro, DXP480T Plus

● **iDX Series**: iDX6011, iDX6011 Pro

## Prerequisites

Before installing OpenClaw, please go to the "**App Center**" on your UGREEN NAS and make sure your Docker app is updated to the latest version.

**Note**: OpenClaw relies heavily on the Docker container environment. If the Docker version is outdated, it may lead to deployment failure, permission issues, or runtime errors.

## Install the App

Log in to your UGREEN NAS, open the "**App Center**", and under "**All**", locate the "**OpenClaw**" app and click "**Install**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/f8edb81211614533aa8b01197746286e.webp)

## Configure Installation Settings

When installing the OpenClaw application, you must first complete the system path and model interface settings on the "**OpenClaw installation configuration**" page.

### Path Configuration

This section defines the file access scope of OpenClaw. To ensure data security, please grant permissions with caution.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/a5220d5361704a3c9e449ac052cba89c.webp)

● **Workspace path**: This is the default working directory for OpenClaw. It is used by AI to write code, generating files, and storing temporary data. It is recommended to assign an empty folder.

● **File access path**: Authorizes OpenClaw to read or modify existing files on the NAS (such as documents and videos). Multiple directories can be configured by clicking the "**Add**" button.

**Notes:**

● Do not select folders containing private or sensitive data. Deleting, modifying, or moving authorized folders may cause application malfunctions.

● The file access path must not overlap with the "**Workspace path**" or any of its subdirectories.

### API and Model Configuration

This section is used to connect to external large language model (LLM) services.

● **API Base URL**: Enter the interface address provided by the LLM service provider (e.g., `https://api.minimaxi.com/v1`).

● **Model name**: Enter the specific model version to be invoked (e.g., `MiniMax-M2.7`).

● **API key**: Enter the dedicated access key obtained from the model provider.

● **Gateway token**: Create a custom security token. This token will be required for authentication when accessing the OpenClaw web interface via a browser, preventing unauthorized access.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/8a56d7d1bd17450fad69d6627d389fe8.webp)

### Complete the Installation

After confirming that the above configurations are correct and fully understanding the associated risks, select "**I have read and understand and the installation risks**" in the lower-left corner of the page. Then click "**Install**" in the lower-right corner to begin deploying the application.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/1a80f9b9acac46489aafc87cc8c8be58.webp)

### Risks and Precautions

OpenClaw is a highly privileged automation agent. Before installation, please carefully review the following key risks:

1. By default, the application runs within a Docker container with root privileges, allowing it to read and write files and execute system commands. It is strongly recommended not to expose this application to the public internet.

2. The current version does not provide secure multi-user isolation. If multiple users share the same application instance, they will share all tool permissions and data.

3. This open-source project is currently in the testing stage. Any legal, financial, or data-related risks arising from AI-driven automation—such as accidental file deletion or data leakage—shall be borne solely by the user.

## Usage and Connection

After installation, you need to connect via the Web console. UGREEN provides the OpenClaw Console, which serves as the core backend for managing AI large model services and multi-channel message distribution. Through this console, you can intuitively monitor container runtime status, flexibly configure large model APIs, and quickly integrate AI with external communication tools (such as Telegram, Feishu, etc.) to achieve efficient workflow for intelligent agents.

## Login and Access

1. On the UGREEN NAS desktop, locate and click the "**OpenClaw**" application shortcut. The system will automatically open your browser and navigate to the Web console page.

2. Upon first access, enter the previously configured gateway token in the prompted input field.

3. After entering the token, click the "**Sign in**" button to enter the console homepage.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/72acace7dbff499ba067ea6fb2f4f28f.webp)

## Console Overview

The overview page provides real-time monitoring of container operations and global quick access controls. The top of the page displays the current service status (e.g., "**OpenClaw running**"). Click the "**Open OpenClaw**" button in the top-right corner to open the native Web interface of OpenClaw in a new browser tab.

● **Resource and Configuration Monitoring**: The central panel shows the current container's CPU usage, memory consumption, and uptime. The "**Container info**" section below lists underlying runtime parameters such as gateway ports, process PID, and virtual memory.

● **Restore Factory Settings**: At the bottom of the page, in the Advanced/Dangerous zone, you can perform a "**Reset to factory**" operation. Note that this action is irreversible. Executing it will reset all custom configurations—including model providers, default models, channels, plugin statuses, etc.—to their initial default state. Proceed with caution.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/199f5f35670e4de791535ae1822979f3.webp)

### Model Provider

This feature allows centralized management of the AI model services used by OpenClaw.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/eab6ed2d897e4cd194060fa7a19df8b1.webp)

1. **Add a Provider**

In the "**Model providers**" section, click "**Add provider**" at the top-right corner. In the pop-up configuration window, select the corresponding provider (e.g., DeepSeek, OpenAI) and correctly enter the Base URL and dedicated API Key.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/8c70732f911c4d6baf054986c70b0e47.webp)

2. **Manage Existing Models**

The list displays all currently configured model cards. Click "**Edit**" on the right to modify the API Key or adjust specific model parameters; click "**Delete**" to remove the provider connection.

3. **Set Default Model**

In the "**Default model**" area at the bottom of the page, click the dropdown menu to select the main model that the application should prioritize. After switching, be sure to click "**Save**" on the right to apply the changes.

### Channels

This feature allows OpenClaw to connect with external communication platforms, enabling automatic receipt and response of AI messages.

1. **Enable Channel Plugin**

In the "**Plugin status**" section, select the platform you want to connect (e.g., Telegram) and click "**Enable**". The system will automatically fetch and install the plugin, and once completed, the status will change to green "**Ready**"**.**

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/5919c9659e0641c48fc1975cd7408677.webp)

2. **Configure Channel Parameters**

Taking Telegram as an example, once the plugin is ready, go to the "**Channels"**section below and click "**Add channel**" to establish a connection with the installed plugin. For channels that have already been added, click "**Edit**" to replace or update settings like Bot Token and DM Policy.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/fd395e782f5e4c438f7b9675a5b932af.webp)

### Operation Logs

This feature provides transparent display of container runtime information, aiding in troubleshooting and status tracking.

1. **Real-Time Log Stream**

The terminal on the page continuously outputs OpenClaw Docker container logs and interaction events.

By default, "**Auto-scroll**" is enabled at the top-right, ensuring that the latest logs are always displayed at the bottom of the view without manual scrolling. To clear the log view, click "**Clear**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/6c3256d79b0b445086570c476a2e12dd.webp)

## Access OpenClaw Web Page

Click the "**Open OpenClaw**" button at the top-right corner of the OpenClaw console to launch the native Web interface in a new browser tab.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/9079d6d6b7874192b4eba21ae4e567e0.webp)

## Using AI Chat

1. Click "**Chat**" in the left navigation panel to return to the conversation window.

2. Enter your question or command in the input box at the bottom of the page.

3. Click the "**Send**" button (paper plane icon) to start a conversation with your dedicated AI assistant.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/f54999ec5cc54461b9359a928522909b.webp)

## FAQs

### What if I forget the Gateway Token or folder path?

If you forget the configured gateway token or authorized folder paths, you can retrieve them through the system settings.

**Steps to retrieve:**

1. Return to the UGREEN NAS desktop and open the "**Control Panel**" app.

2. In the left sidebar, scroll to the bottom and click "**About**".

3. Switch to the "**Apps**" tab at the top.

4. Locate "**OpenClaw**" in the app list and click to open it.

5. In the pop-up "**App configuration**" window, you can view the authorized "**Accessible folder**"paths and the configured "**Gateway token**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/adad9078575849e2aff566a5172d54e6.webp)

### Folder Configuration Limitations

After OpenClaw is installed, the system does not support adding, modifying, or deleting the configured "**File access path**" or "**Workspace path**".

If you need to change or add authorized folders, the only solution is to uninstall the app completely and reinstall it with new configurations.

**Recommendation**: During the initial setup in the installation wizard, please plan ahead and select all directories to be processed by the AI at once, to avoid having to reinstall the application later due to changes.

## Related Reading

### OpenClaw User Guide

[https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODA5IiwiY2xpZW50VHlwZSI6IiJ9](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODA5IiwiY2xpZW50VHlwZSI6IiJ9)

### How to Add and Switch Models in OpenClaw

[https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODIzIiwiY2xpZW50VHlwZSI6IiJ9](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODIzIiwiY2xpZW50VHlwZSI6IiJ9)

## Security Risk Notice

● **Root Privileges and High-Risk Operations**: This application runs with **root privileges** inside a Docker container to support automation tasks. It has the ability to write/delete files, publish content, and execute system commands. **Only grant access to trusted directories, and do not mount paths containing sensitive data into the container.**

● **No Multi-Tenant Isolation**: By default, OpenClaw is designed for a single trusted operator and does not provide isolation between multiple users. If multiple users share the same agent, they will have the same level of access and permissions.

● **Public Network Exposure Risk**: If you are not familiar with security hardening and access control, do not expose this service directly to the public internet. **UGREEN NAS does not provide technical guidance for public network deployment.**If needed, consult a qualified professional.

● **Content Compliance**: When interacting externally through platforms such as QQ, Feishu, or DingTalk, you must comply with the laws and regulations of the relevant platforms and jurisdictions. Users are solely responsible for any AI-generated content.

● **Disclaimer**: This application is provided as a service integration tool. The provider offers deployment support only and does not guarantee the security, stability, or completeness of the OpenClaw software itself. Any customization, operational decisions, and resulting risks—including but not limited to data leaks, device damage, additional costs, or legal disputes—are the sole responsibility of the user. The provider assumes no liability.
