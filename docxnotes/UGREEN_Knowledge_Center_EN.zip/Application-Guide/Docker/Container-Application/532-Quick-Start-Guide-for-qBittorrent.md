# Quick Start Guide for qBittorrent

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTMyIn0=

**Applicability Statement:** This guide applies to UGOS Pro firmware version 1.6.1.2846. The screenshots provided are for reference only — the actual interface may vary slightly depending on the system or application version. Some options and features may differ across versions; please refer to the actual interface for accuracy.

## **App Overview**

qBittorrent is a powerful open-source BitTorrent client that supports magnet links, torrent downloads, multi-task parallel processing, speed limits, queue management, and more. It meets users’ needs for efficiently managing BT download tasks on a NAS.

**Default Login Information:**

- Default username: **admin**
- Default password: **adminadmin**

**Default Ports:**

- **Web access port:**8888
- **TCP/UDP forwarding port:**6888

**Note:** Do not modify the WebUI port. Changing it will cause the admin to be unable to access the qBittorrent app by clicking its icon.

- **Developer link:**[GitHub Project Page](https://github.com/userdocs/qbittorrent-nox-static)

## **Installation Guide**

To install the qBittorrent app, please follow the steps below:

1. Open the [App Center], locate the qBittorrent app, and click "Install".
2. Select a storage volume and click "Next" to continue.
3. Choose a download directory. Files downloaded via this app will be stored in this directory. Click "Install" to proceed.

## **Accessing qBittorrent**

In the system, users can access the qBittorrent app through the following methods:

### **Method 1: Access via App Center (Admin Only)**

Within the local network, administrators can click the qBittorrent app icon in the App Center. The system will redirect to the login page.

### **Method 2: Access via Local Network (Admins and Common Users)**

1. In the local network, use `http://NAS_IP:8888` to access the app. For example, if your NAS IP is `172.17.70.69`, enter `http://172.17.70.69:8888` in your browser.
2. You can find your NAS device’s IP address in [Control Panel] by navigating to [Network] > [Network Connection].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/c8c3acf3-a9cd-4a87-9ea7-531aeef90a6e.png)

### **Method 3: Access via Firefox App Outside the Local Network (Admin Only)**

Administrators can access qBittorrent outside the local network using the Firefox app installed on the NAS system:

1. Log in to the NAS using UGREEN Link and open the Firefox app.
2. After logging into Firefox, visit `http://NAS_IP:8888`. For example, if the NAS IP is `172.17.70.69`, enter `http://172.17.70.69:8888` in the browser.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/b5584f84-92b8-4d50-be5e-ea0863b0aa58.png)

**Please Note:**

1. When logging in on untrusted devices, it is recommended to clear the browser history promptly to ensure data security.
2. When accessing within the local network, it is recommended to use a browser with good compatibility (such as Chrome or Edge).
3. Administrators should properly manage the access credentials. When accessing the NAS over a public network, pay attention to data security to avoid leakage of sensitive information.

## **Logging into qBittorrent**

On the web login page, enter the default username `admin` and password `adminadmin` to log in. To ensure security, it is recommended to change the default username and password immediately after the first login (see the section [Changing Username and Password] below for details).

If you forget the login password, you will need to reinstall the qBittorrent app. **Note:** After reinstallation, application data will not be retained. You will need to reconfigure settings and re-add tasks.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/7c55ff8c-a42e-4ce7-bfa5-bc2dbe9297d0.webp)

## **Initial Configuration**

Before using qBittorrent, please complete the necessary initial setup.

### **Set the Interface Language to English**

- After logging into the WebUI, click the gear icon in the upper right corner to enter "Settings".
- Under the Behavior tab, find the Language option.
- Select "English" from the language list and click "Save" to apply the setting.
- After saving, the interface will switch to English, making subsequent operations easier to follow.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/34849369-e786-49c9-976c-55416f0a647f.png)

### **Change Username and Password**

To ensure security, please change the default username and password after your first login:

1. Click the "Options" button in the upper-right corner to enter the settings page.
2. Under the WebUI section, scroll down to find the Authentication settings area, and set a new username and password.
3. After making the changes, click "Save" at the bottom of the page.
4. The next time you log in, you will need to use the new username and password for authentication.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/e3a18c7e-9590-4fc3-9f65-b69a79225059.png)

### **Set Listening Port**

1. qBittorrent uses port `6881` by default, but this port may result in slower download speeds for certain torrents. On UGOS Pro, the default has been changed to port `6888`.
2. If you wish to use a different port, you can modify the listening port on the settings page. The change will take effect after clicking "Save".

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/e777f3ff-40b9-4e07-8c44-986cae01324d.png)

### **Disable WebUI Authentication**

In certain scenarios (such as accessing qBittorrent remotely via an intranet penetration tool), if WebUI authentication is not disabled, access may be denied with an “Unauthorized” error message.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/ebc32677-ed29-43b9-8a2e-a32d81238ea1.webp)

To ensure smooth remote access, please follow the steps below:

1. In qBittorrent’s Settings, switch to the WebUI page.
2. In the "Authentication" or "Security" section on the WebUI page, disable the following options:

- **Enable clickjacking protection**
- **Enable Cross-Site Request Forgery (CSRF) protection**
- **Enable Host header validation**

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/a7eca2fe-faf2-4006-acf4-cdcc66008d72.png)

1. After making changes, click "Save" at the bottom of the page.

## **Add Download Tasks**

qBittorrent supports multiple ways to add download tasks:

1. **Add Magnet Link**
  ● Click the "Add Torrent Link" icon on the toolbar.
  ● Enter the magnet link in the pop-up dialog and click "Download" to start downloading.
2. **Upload Torrent File**
  ● Click the "Add Torrent File" icon on the toolbar.
  ● Select a local torrent file to upload, then start downloading the resource.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/08a0bbd6-e645-4961-a2d9-4e6c8ee4fae9.png)

After adding a task, you can see that the resource is downloading.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/7bf0a4c0-c69d-400b-ab51-0fc624ea449a.png)

## **Why is my torrent download speed zero?**

The principle of BT downloading is that other users upload files to you to complete the download. Your download speed depends on the combined upload speeds of these users.

As shown in the figure, there are 7 seeders, but only 5 are successfully connected to you. Therefore, your download speed depends on the upload speeds of these 5 users.

If the resource is old and there are no seeders, the download speed will be very slow or even zero.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/c3194d06-257d-4a61-b236-ee699bb7d995.png)

## **Notes**

When using the UGOS Pro system and container applications, please pay attention to the following to ensure the normal operation of the system and apps:

1. Do not arbitrarily migrate, move, rename, or delete NAS paths mounted by container applications, as this may cause application malfunctions or data loss.
2. If you need to access container applications via a browser, please disable the Multiple Gateway option in [Control Panel] > [Network] to avoid network conflicts.
3. Container applications are suitable for novice users. For more flexible configuration management, it is recommended to deploy directly using Docker. See [Deploying a Qbittorrent Downloader on UGREEN NAS](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6MTA0NSwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjozNDgsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ%3D%3D)
4. For more flexible configuration and management, it is recommended to deploy qBittorrent directly using Docker, which allows customized configuration files and advanced features.
