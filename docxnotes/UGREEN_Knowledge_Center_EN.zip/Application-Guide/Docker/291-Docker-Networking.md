# Docker Networking

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjkxIn0=

## Managing Docker Networks

In the "Networking" interface, you can view and manage the network configuration of containers. The networking mode determines how containers interact with external networks and how they communicate with each other.

## Common Network Modes

Docker primarily supports the following three network modes, which you can select based on your actual needs:

1. **Bridge Mode**

This is Docker's default mode. Docker creates an isolated virtual network environment for containers. External communication requires **"port mapping"** (e.g., mapping container port 8080 to NAS port 80).

You can freely modify the mapped ports and access container services (such as web pages) via the format "NAS IP:port".

2. **Host Mode**

In this mode, containers directly use the NAS's IP network. If the NAS has obtained an IPv6 network, containers can also directly gain IPv6 connectivity.

3. **Macvlan**

This mode allows containers to have independent MAC addresses and LAN IP addresses. Containers behave like independent physical devices within the network, enabling direct communication with other devices without NAT forwarding. Suitable for scenarios requiring fixed independent IPs or resolving port conflicts.

## Managing Network Configuration

You can perform the following management operations in the " **Network" interface**:

● Click **"Add"** to **create** a custom network (e.g., Macvlan) to meet specific network requirements.

● Select a network mode and click " **View** " to obtain detailed configuration information such as subnets and gateways.

● For unused custom networks, select them and click " **Delete** " to release resources.

**Note**: The system default network cannot be deleted.

## Macvlan Network

Macvlan mode assigns each container a dedicated LAN IP address, completely resolving port conflicts and similar issues. Below are the complete configuration and usage steps.

### Creating a Macvlan Network

Before use, you must first create a Macvlan network interface.

1. Click " **Network** " > " **Add** " to enter the network configuration wizard.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20251217/c5f5d5f3-8c13-4c20-a280-769536e7ae84.png)

2. Enter a recognizable name (e.g.,macvlan_net).

3. From the "Network Mode" dropdown menu, select " **macvlan** ".

4. Select the physical network adapter to be used for creating the network.

5. IPv4 addresses are automatically assigned based on the network card information by default. To enable IPv6 support, check the corresponding option.

6. After confirming the configuration is correct, click " **OK"**.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20251217/5ea56e09-213e-4f3f-8667-2d15b6d80a5f.png)

**Note**: Only one Macvlan network can be created per physical network adapter. If prompted that no network adapters are available, go to **"Control Panel"** > " **Network Settings"** > " **Network Connections"** to check if the port is occupied by **a** " **Network Bridge"**.

### Applying Macvlan Network Configuration

After creating the Macvlan network, you can apply it to specific containers.

1. Locate the target container in the " **Containers** " list, then click " **···"** > " **Edit"**.

2. By default, editing permissions are locked. Click the " **Still want to edit?"** button in the top prompt to unlock modification permissions.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20251217/df30076f-20c8-498c-b6e9-8df4325dea38.png)

3. In the network configuration section, switch the network mode to " **macvlan"**.

4. In the network list below, select the name of the Macvlan network you just created and set a static IPv4 address.

Ensure this IP is not already in use by another device on your local network.

![](https://file1-cn.ugnas.com/admin/article/2025-12-13/44b2b392cc6548129640eb872fcde20c.webp)

5. Click " **Save**." After the container restarts, it will run using the new dedicated IP.

## Important Notes

● Containers created via "Projects" (Docker Compose) cannot have their network settings modified directly within the container interface. You must manually edit the corresponding Compose configuration file for the project to specify the Macvlan network.

● Container applications installed directly via **the** " **App Center** " do not support switching to Macvlan mode.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20251217/7a3f380b-8577-4224-8c8e-feb516c6c614.png)
