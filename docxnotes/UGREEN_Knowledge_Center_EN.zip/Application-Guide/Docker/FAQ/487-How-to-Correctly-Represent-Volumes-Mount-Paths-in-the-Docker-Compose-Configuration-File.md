# How to Correctly Represent Volumes Mount Paths in the Docker Compose Configuration File?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDg3In0=

## Problem Description

When configuring the Docker`docker-compose.yml`file, it is necessary to mount the data directory inside the container to a local folder on the NAS for data persistence. However, sometimes we may not be clear on how to correctly represent the local folder path, especially when dealing with the volume of the NAS.

## Solution

To simplify the path mounting operation in Docker Compose configuration, UGOS Pro provides the feature to **copy storage paths** from [Files], making it easier for users to quickly obtain the paths of shared or personal folders on the NAS. Below is a detailed guide (using the deployment of the TMM container as an example):

### Understanding the volumes Mount Path Format

In the Docker Compose file, the mount path for`volumes`is typically represented in the following format:

```
Local path: Container path
```

● The left side of the colon`(:)`is the local path, which represents the actual folder location on the host (NAS).

● The right side of the colon`(:)`is the container path, which represents the folder location inside the container.

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/29b3b6bc936e4ee6b7fe05f3233b24be.webp)

There are two types of mount paths:

#### Relative path

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/a35ba443e5834b05995d3072e5109a6c.webp)

A relative path is based on the directory where the`docker-compose.yml`file is located. For example:

```
./config:/config
```

● `./config`：`./`represents the directory where the`docker-compose.yml`file is located, and`config`is a subfolder within that directory.

● Inside the container`/config`：This mounts the local`config`folder to the`/config`folder inside the container.

This method is suitable for quickly creating and managing the necessary folders for the container in the current working directory.

#### Absolute path

An absolute path directly specifies the exact folder location on the host (NAS). For example:

```
/volume1/docker/tmm/config:/config
```

● `/volume1/docker/tmm/config`：Represents the absolute path on the NAS volume.

● Inside the container`/config`：This mounts the contents of this path to the`/config`folder inside the container.

This method is more suitable for explicitly specifying shared folders or user-specific folders on the NAS.

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/1612f0179e664091bd8bc8499af26973.webp)

### How to Copy the Folder Path on NAS

#### Copy the path of a secondary shared folder

Shared folder paths are typically used for collaboration and sharing data:

1. Go to [Files] > [Shared Folder], and find the target subfolder.

2. Right-click on the folder, select "Properties," and click "Copy Storage Path Location" to get the path.

Please note: The path copying feature is not supported for the top-level shared folder directory.

Example path:`/volume1/Shared Folder/Subfolder`

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/f77de32fd76e4178a9e3fd4801674781.webp)

#### Copy the Path of a Personal Folder

Personal folder paths are commonly used for individual user data storage:

Go to [Files] > [Personal Folder], and similarly, copy the path via [Properties].

Example path:`/home/username/Personal Folder`

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/f623a71857104a4baf58c6ecb8785c0a.webp)

### Using Paths in the Docker Compose File

After copying the path, you can directly insert it into the`volumes`configuration in the`docker-compose.yml`file. For example:

```
services:
    tinymediamanager:
        image: 'dzhuang/tinymediamanager:latest-v5'
        extra_hosts:
            - 'api.themoviedb.org:13.35.67.86'
            - 'image.tmdb.org:104.16.61.155'
            - 'api.themoviedb.org:13.224.161.90'
        ports:
            - '5900:5900'
            - '5800:5800'
        environment:
            - ENABLE_CJK_FONT=1 
            - TZ=Europe/Madrid 
            - USER_ID=0 
            - GROUP_ID=0 
        volumes:
            - /volume1/media:/media 
#Mount the media folder from the NAS storage to the container's /media directory，so that TMM inside the container can access these files.
            - /volume1/docker/tmm/config:/config
#Mount the folder used for saving configuration data from the NAS storage to the container's /config directory to save settings, logs, and other data.
        container_name: tinymediamanager
```

**Note:**Please ensure that the local paths used in the Docker Compose file actually exist. Otherwise, it may result in the container deployment failure.
