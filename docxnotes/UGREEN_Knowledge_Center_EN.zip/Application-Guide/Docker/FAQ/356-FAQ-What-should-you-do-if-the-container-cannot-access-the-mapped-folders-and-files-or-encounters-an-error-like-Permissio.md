# [FAQ] What should you do if the container cannot access the mapped folders and files or encounters an error like "Permission denied" or "Access denied" when downloading?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzU2In0=

## **[Issue Description]**

If your container is unable to access the mapped folders and files on UGOS Pro or encounters errors during downloading, and you see "Permission denied," "File error alert," or similar errors in the container logs, the container may have unexpectedly stopped running. You might see error messages like the following in the logs:

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/b8d91b09-5403-41cc-8ac9-8df03d45da49.png)

## **[Environment Information]**

- Docker application version: V1.0.0.0215 or higher.
- Firmware version: V1.0.0.1107 or higher.

## **[Diagnostic Information]**

This error is usually caused by the user using a manually created directory as the container mount path, rather than using the automatically generated Docker directory. The automatically generated Docker directories have 755 permissions (read, write, and execute permissions), while manually created directories often lack sufficient permissions, causing the container to be unable to access the required files.

## **[Solution]**

To avoid the above permission issues, make sure the mount directory used by the Docker container has sufficient permissions. The specific solutions are as follows:

1. Use the Automatically Generated Docker Shared Directory:- After installing the Docker application, a Docker shared directory will be automatically generated in the files. Please place the container's mount path within the shared directory under the Docker directory, as it has default sufficient permissions (755), ensuring the container can access it properly.
2. Adjust Permissions for Manually Created Directories:- If you must use a manually created directory, make sure it has appropriate permissions. You can set the directory permissions using the following command:

```
chmod -R 755 /path/to/your/manual/directory
```

- This command will recursively set read, write, and execute permissions for the directory and its subdirectories and files.

By using these methods, you can ensure that the container has sufficient permissions to access the required files and folders, thus avoiding "Permission denied" errors.
