# [FAQ] What Preparations Are Needed Before Installing an Image Container Using the Docker Panel?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzkwIn0=

Q: What do I need to prepare before starting to install a container using the Docker panel?

A: Before installing a container using the UGOS Pro Docker panel, you need to create the required storage folders and subfolders for the container in advance to ensure the container can run smoothly and that data can be stored and managed correctly.

To avoid permission issues during container operation, it’s recommended to place these folders under the`/Shared Folders/docker`directory. Here’s a detailed guide on how to create and manage these subfolders for the container.

Create the Base Folder

First, create a base folder in UGOS Pro’s files, which will serve as the primary storage directory for the container. For example, if you are preparing to install a Plex container, you can create a base folder named`plex`.

#### **Steps:**

1. Access Files：In the UGOS Pro management interface, navigate to Files.
2. Create the Base Folder:- Navigate to the appropriate storage location (e.g., the Docker shared folder).
  - Create a new folder and name it`plex`.

Create Necessary Subfolders

According to the container's requirements, create the necessary subfolders within the base folder. For example, for many application containers, you might need to create subfolders like`config`,`logs`, and`data`.

#### **Steps:**

1. Create subfolders:- Go to the`plex`folder.
  - Create the following subfolders:- `config`：Used to store configuration files.
    - `logs`：Used to store log files.
    - `data`：Used to store application data.
