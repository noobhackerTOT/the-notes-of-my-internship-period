# Guide to Configure Docker Image Acceleration and Repository Pull

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjk3In0=

## **Configure Docker Mirror Accelerator**

By configuring a mirror accelerator address, you can optimize the access path for domestic nodes, significantly reducing the pull time for overseas mirrors (such as Docker Hub).

**​Steps**

1. Open the UGOS Pro desktop, click the [Docker] icon, and select [Image] from the left menu.
2. Click the [Settings] button on the top toolbar, then go to the [Image Repository] tab and select [Registry Settings].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/3fcb3d3d-d013-40f0-b594-86121915104d.png)

1. Enter the mirror accelerator URL. Below are some recommended accelerator addresses for reference.

```
https://docker.1ms.run
https://k-docker.asia
```

1. Click [Confirm] after entering the URL. The Docker engine will restart, and the system will automatically refresh the image index.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/eca18d45-b161-4f03-abfd-c49ad8a19ef2.png)

## **Pull Images from a Repository**

The [Download from Package Source] feature allows users to pull images from third-party registries such as GitHub Container Registry (GHCR) and private repositories.

**Steps**

1. **Access the [Image] Interface**

- Navigate to the [Image] page. → Click [Local Images] on the right panel.→ Select [New Image] from the top menu.→ Click [Package Source].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/cbfcef45-c16a-4edb-ac85-f6473b35e516.png)

1. **Enter Image Details**

- Image Name Format: Specify the full repository URL, e.g.,`ghcr.io/open-webui/open-webui`.
- Version: It is recommended to use a specific version tag (e.g.,`latest`,`v2.3.1`, or`main`) to avoid pulling incorrect versions.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/a7ee0e27-18bd-4150-882c-1e06443aa040.png)

1. Click [Confirm], and the system will automatically fetch and download the image using the configured accelerator.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/9208ed85-cb4f-4177-877b-631feb81148c.png)

## **Create a Custom Image Repository**

To add a custom image source to Docker, such as using DaoCloud’s domestic acceleration node, follow these steps:

#### **Steps**

1. Open the "Docker" Application, Navigate to [Image] from the left-side menu, click [Image Database] at the top and click the [Settings] button.
2. In the settings, click [Add]. In the pop-up window, enter the repository alias (it's recommended to use a concise identifier, such as "daocloud") and the source URL (paste the full repository URL, e.g.,`https://docker.com`).

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/b64ddc7e-79bb-4f82-93e6-2a8b4f6c270a.png)

1. Click [Confirm] to complete the setup. The configuration will take effect immediately.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/122034d5-246b-41ce-a431-c060447f8017.png)

## **Why Is Image Pulling Still Slow After Using an Accelerator or Mirror Source?**

1. **Server Performance and Location:** Different mirror accelerator sources have varying server performance and geographic locations. If you are too far from the server, the speed may be slow.
2. **Maintenance and Upgrades:** Some mirror accelerator sources may undergo regular maintenance or upgrades, which could lead to service interruptions. You can check the official announcements or status monitoring pages of the service provider to verify if there are any issues. For example, you can check [the Docker status page.](https://status.1panel.top/status/docker)

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250729/d2e13a28-1875-4482-81ad-05ee62190d51.png)

1. **Switching Mirror Sources:** If the current mirror source is slow, you can try switching to another available mirror source for testing.

**Note:**After switching mirror sources or proxy settings, please restart the Docker application to avoid pull failures caused by cache issues.

## **Related Links**

- [Recommended Docker Mirror Acceleration Addresses](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImlkIjoxMzU1LCJhcnRpY2xlSW5mb0lkIjo0NTMsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=)
- [Why Is Image Pulling Still Slow After Using an Accelerator or Mirror Source?](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTY3NCwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiZW4tVVMiLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo1NDgsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==)
