# Configuring Docker to Download Images via Proxy on UGREEN NAS

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzM1In0=

With the HTTP and HTTPS proxy features provided by UGOS Pro for Docker, users can conveniently download Docker images and accelerate the download process, especially under poor network conditions. This feature allows users to configure HTTP and HTTPS proxy addresses, enabling Docker to retrieve images through a proxy server. Below are the detailed configuration steps and important notes.

UGREEN NAS does not provide proxy server addresses for Docker image acceleration. If needed, users are advised to search for relevant resources online.

## Setting Up HTTP and HTTPS Proxies

1. Open the “Docker” app. In Docker, go to [Images] > [Image Database], then click the [Settings] button to open the settings page.

2. On the settings page, switch to the [Proxy] tab and toggle on [Enable Proxy]. Then enter your proxy server address in the [Proxy Server Address] field. The address must begin with http:// or https://.

3. After confirming the configuration is correct, click “OK.”

4. In the pop-up prompt, click “Confirm” again to add the proxy server.

![](https://file1-cn.ugnas.com/admin/article/2025-08-07/b1cbc5104de74c578b16a55acd424ed3.webp)

#### Using a Proxy Server to Download Images

1. Enter the image name in the search bar of the image registry to search for the desired image.

2. From the search results, select the image you want to download and click [![](https://file1-cn.ugnas.com/admin/article/2025-08-07/ae6c3092685146868b0e2d2160d8e4fb.webp)Download]. The default version tag is latest. If you need a specific version, enter the desired version tag in the [Version] field.

3. Click “OK” to start downloading the image.

4. Once the download is complete, the system will send a notification through the Notification Center.

![](https://file1-cn.ugnas.com/admin/article/2025-08-07/2fbf9153e647413a9eb7ce045f8f6126.webp)
