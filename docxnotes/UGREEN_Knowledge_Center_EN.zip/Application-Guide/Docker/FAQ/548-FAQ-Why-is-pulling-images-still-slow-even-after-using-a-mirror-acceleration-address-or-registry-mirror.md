# [FAQ] Why is pulling images still slow even after using a mirror acceleration address or registry mirror?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTQ4In0=

## **Problem Analysis**

Even after configuring mirror acceleration addresses or registry mirrors, the image pull speed may still be affected by the following factors:

**Server Load:** The registry mirror servers may become congested due to high user traffic, which can result in slower download speeds.

**Network Environment:** Your local network might have bottlenecks, such as limited bandwidth or high latency.

**Geographic Restrictions:** Some mirror servers may be located far from your region, or the network path between your ISP and the mirror may have poor quality.

**Mirror Compatibility:** Some mirrors may not be fully compatible with your current Docker version or specific images, causing degraded performance.

## **Solution**

**Switch to a Different Mirror:**

Different registry mirrors vary in performance and geographical coverage. If your current mirror is slow, try switching to another one for testing. Here are some commonly used Docker registry mirror addresses:

```
https://docker.1ms.run
https://k-docker.asia
https://docker.1panel.live
https://dockerproxy.cn
```

**Optimize Local Network Conditions:**

Check and improve your network bandwidth to ensure there are no other high-bandwidth activities (such as streaming media or large file downloads) that might affect Docker’s image pull speed.

**Use a Proxy Service:**

If your network has restrictions or performance issues when accessing international registry mirrors, consider configuring an HTTP/HTTPS proxy to improve connectivity.

**Check the Mirror Status:**

Some registry mirrors may undergo periodic maintenance or upgrades, which can lead to temporary service interruptions. Refer to the official announcements or status pages of the mirror service providers to verify if there are any ongoing issues. For example:[https://status.1panel.top/status/docker](https://status.1panel.top/status/docker)

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250717/e275035b-fd4e-401c-a181-8b63e7e1e44b.png)

## **Notes**

After switching registry mirrors or updating proxy settings, be sure to restart the Docker service to avoid pull failures caused by caching issues.

## **Related reading**

[[FAQ] How to Configure Docker Registry Mirrors and Acceleration Sources](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6ODkzLCJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVJbmZvSWQiOjI5NywiYXJ0aWNsZVZlcnNpb24iOiIiLCJwYXRoQ29kZSI6IiJ9)

[[FAQ] How to Download Docker Images via Proxy on UGREEN NAS](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6MTAxNiwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjozMzUsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ%3D%3D)
