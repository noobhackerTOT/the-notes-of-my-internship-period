# How to Obtain PUID and PGID？

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzY5In0=

When using UGREEN NAS (UGOS Pro), configuring PUID (User ID) and PGID (Group ID) is crucial to ensure that Docker containers can correctly access and manage the file system. PUID and PGID are identifiers for users and groups in Linux systems, and using these identifiers ensures that Docker containers have the appropriate permissions to access files on the host machine.

### **What are PUID and PGID?**

- PUID（User ID）: Identifies a specific user in the system.
- PGID（Group ID）: Identifies a specific user group in the system.

Applications running in Docker containers need appropriate file permissions to read and write files on the host machine. By setting PUID and PGID, you ensure that these applications run with the correct user identity, thus obtaining the necessary permissions.

### **Why is it necessary to set PUID and PGID?**

1. Permission Management: Ensures that applications within the container run under a specific user identity, preventing permission errors.
2. File Access: Ensures that applications within the container can correctly access the file directories on the host machine.
3. Security: Limits applications within the container to run with specific user permissions, reducing security risks.

### **How to Obtain and Set PUID and PGID?**

Here’s how to obtain PUID and PGID on UGREEN NAS:

1. Log in to the NAS: Access the NAS via SSH.
2. Obtain the User ID (PUID): Replace`<username>`with the username you want to run the Docker container. The command will return the user ID for that user.
3. Obtain the Group ID (PGID): Similarly, replace`<username>`with the username of the user. The command will return the group ID for that user.
4. Example: If the username is`nasuser`, you can obtain its PUID and PGID using the following commands.

```
id nasuser
# To obtain a user's UID and GID values
id -u nasuser
# To obtain a user's UID value
id -g nasuser
# To obtain a user's GID value
```

1. Once you have obtained the PUID and PGID values, you can use these IDs to run a Docker container.

### **Using PUID and PGID in Docker**

When running a Docker container, you can use the following command-line parameters to set PUID and PGID:

```
docker run -d \
  --name=container_name \
  -e PUID=<user_id> \
  -e PGID=<group_id> \
  -v /path/to/config:/config \
  -v /path/to/data:/data \
  image_name
```

- `-e PUID=<user_id>`：Set the user ID for the container to run.
- `-e PGID=<group_id>`：Set the group ID for the container to run.
- `-v /path/to/config:/config`：Map the configuration file directory.
- `-v /path/to/data:/data`：Map the data directory.
- `image_name`：The name of the Docker image.

### **Example**

1. Download a remote connection tool (e.g., MobaXterm).
2. Enable SSH in the [Control Panel]-[Terminal].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/d6b974b2-4f86-402a-a5c5-f2408ef9211d.png)

1. Open MobaXterm and click on "Session."

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/4547fcf2-66a7-4f60-9adb-0e52573dbb3a.png)

1. Click on SSH, and in the Remote host field, enter the device address. For the Port field, enter 22.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/32460fc6-af5f-4afb-9616-e4705abb5214.png)

1. Enter the username and password to log in to the device's underlying system.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/26e46904-b25a-430c-b108-3096d96f3075.png)

1. After logging in, type the command`sudo -i`and press Enter. Then, enter your password to gain root privileges.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/6ce4038a-af63-43f3-8030-b899d30c2119.png)

1. When the prompt changes from [$] to [#], it means you have gained root privileges.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/c5db8da4-b63e-4ade-a39d-12f0c8666829.png)

1. Use the command id + username to obtain the PUID and PGID. For example, type`id ugreen`.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250415/52819833-950c-4a84-b365-88109f568c12.png)

By following the above steps, you can obtain the correct PUID and PGID values on UGREEN NAS. By properly setting the PUID and PGID parameters, you can ensure that applications within the Docker container have the correct permissions to access and manage files on the host machine, preventing various issues caused by permission problems.
