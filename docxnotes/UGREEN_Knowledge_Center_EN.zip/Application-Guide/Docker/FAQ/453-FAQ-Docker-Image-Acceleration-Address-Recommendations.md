# [FAQ] Docker Image Acceleration Address Recommendations

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDUzIn0=

To improve the speed of pulling Docker images, you can use some mirror acceleration sources. These acceleration sources help you obtain the required images from Docker Hub more quickly through proxy or caching methods. Please note that due to the fact that most of these acceleration sources are not dedicated mirror stations, their stability and availability are somewhat limited.

## Available Docker Image Acceleration Sources

Below is a list of currently available image acceleration sources. If the sources in the list do not include "https://", please add it yourself:

●[https://docker.1ms.run](https://docker.1ms.run)

●[https://k-docker.asia](%20)

● https://docker.1panel.live

● https://dockerproxy.cn

● https://docker.nastool.de

● https://docker.agsv.top

● https://docker.agsvpt.work

● https://docker.m.daocloud.io

● https://dockerhub.anzu.vip

● https://docker.chenby.cn

● https://docker.jijiai.cn

The use of these image sources can effectively alleviate delays during image pulling, especially when the network is unstable or access to Docker Hub is slow.

## Features and Precautions of Image Sources

Although these image sources provide convenient acceleration services, they are not specifically designed for long-term storage or high-speed caching of image stations. Therefore, you may encounter the following issues during use:

● **Speed and stability are not guaranteed:** Most of these acceleration sources rely on proxy and caching mechanisms, and their speed and stability may fluctuate due to network conditions or server load.

● **Limited capacity:**The cache of image acceleration sources is not permanent storage. Some images may not be obtained during the first pull, or cached images may be cleared due to space limitations, requiring a re-pull from Docker Hub.

● **Regional restrictions:**Some image sources may be faster only in specific regions or network environments. Therefore, you can test multiple image sources based on your network conditions to find the most suitable one.

## How to Configure Docker Image Acceleration Sources

Using an image acceleration source is very simple; you just need to add the acceleration address in the Docker configuration file. The specific steps are as follows:

1. In the Docker application, click on "Image" > "Image Database", click the settings button.

![](https://file1-cn.ugnas.com/admin/article/2025-09-01/55ca9a38b1c54d8e842a95712f11e805.webp)

2. Select the image source you want to accelerate and click on "Registry Settings".

![](https://file1-cn.ugnas.com/admin/article/2025-09-01/b14fdc2b7088421ca598a8d866f39e7c.webp)

3. Paste the registry address into the "Please enter the source accelarator URL" field, and click "Confirm".

![](https://file1-cn.ugnas.com/admin/article/2025-09-01/798b324a43784bcc9d0255f71eb25696.webp)

4. Click "Confirm" again in the prompt dialog box to restart the Docker engine.

![](https://file1-cn.ugnas.com/admin/article/2025-09-01/2f9a90452c154b6082896d94cd3a0620.webp)

5. After the restart, try the acceleration effect, and it should be able to download normally.

![](https://file1-cn.ugnas.com/admin/article/2025-09-01/7893dce41d7042fa8db23b6867edd051.webp)

In this way, you can use the accelerated image sources to improve the speed of pulling Docker images.

## FAQs

**Q1: Why is the image pulling still slow sometimes?**

A1: The speed of the image acceleration source may be affected by various factors, including the load of the server itself and your network environment. If the speed of the current acceleration source is not ideal, it is recommended to switch to other acceleration sources for testing.

**Q2：What is the reason for the failure of some image pulls?**

A2：Since the acceleration source does not permanently cache all Docker Hub images, some images may not be obtained through the acceleration source during the first pull, especially some unpopular or newer images. In this case, Docker will pull directly from Docker Hub.

**Q3：Are the cached images in the image acceleration source cleared?**

A3：Yes, due to storage capacity limitations, the cache in the acceleration source may be regularly cleared. If the image is cleared, it may be re-obtained from Docker Hub during the next pull.

**Q4：Can all images be accelerated through these acceleration sources?**

A4：Most images can be accelerated through these acceleration sources, but for some private image repositories or images with access restrictions, other methods may be required to obtain them.

Using image acceleration sources can effectively improve the speed of pulling Docker images, but their stability and caching mechanisms sometimes bring a certain degree of uncertainty. It is recommended to test several different acceleration sources during the configuration process and adjust the configuration as needed.

## Related Links

[Docker Image Acceleration Address Recommendations.](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTM1NSwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo0NTMsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==)

[Why is pulling images still slow even after using a mirror acceleration address or registry mirror?](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTY3NCwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo1NDgsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==)
