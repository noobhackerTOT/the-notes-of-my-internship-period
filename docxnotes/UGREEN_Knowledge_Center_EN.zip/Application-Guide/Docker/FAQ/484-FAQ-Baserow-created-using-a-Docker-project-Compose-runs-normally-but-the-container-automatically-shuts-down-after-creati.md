# [FAQ] Baserow created using a Docker project (Compose) runs normally, but the container automatically shuts down after creation

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDg0In0=

## **[Issue Description]**

When creating a Baserow instance using Compose, it runs normally. However, if you pull the image directly via Docker and create a container, the container will automatically shut down, and the service cannot be accessed successfully.

## **[Image Name]**

Image: baserow/baserow:latest

## **[Diagnostic Information]**

When deploying the Baserow application using containers, you need to mount a host directory and ensure that this directory has appropriate permissions. Since the PostgreSQL database creates and runs under the`postgres`user, the mounted directory should have permissions set to 700 or 750. If the permissions are lower than this threshold, the container will report a permission error and automatically shut down.

## **[Solution]**

### **Option 1**

If you do *not* need to map the database directory to a NAS directory/file, simply add the environment variable`DISABLE_VOLUME_CHECK=yes`when creating the container.Note: Without mapping, all data inside the container will be lost once the container is deleted. Conversely, if you do map the directory, the database data will persist even if the container is removed.

### **Option 2**

If you need to map the database and other files to the host or network storage, follow these steps:

1. Before creating the container, use Files to create a subdirectory named`baserow_data`under the shared folder docker.
2. Select`baserow_data`, right-click to view properties, and copy its location (i.e., the actual path).
3. Using an SSH terminal, run a permission change command on the actual path of`baserow_data`. For example:`chmod 755 /volume1/docker/baserow_data`.This ensures proper access permissions.
4. When creating the container, in the storage settings, map the NAS directory/file`docker/baserow_data`to the container path`/baserow/data`, and set the container permission to Read & Write.
5. After completing the above configuration, you can proceed to create the container.
