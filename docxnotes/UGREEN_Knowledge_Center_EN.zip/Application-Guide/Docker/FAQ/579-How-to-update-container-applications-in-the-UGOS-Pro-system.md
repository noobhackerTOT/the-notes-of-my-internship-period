# How to update container applications in the UGOS Pro system?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTc5In0=

## **Problem Description**

The UGOS Pro system has introduced a container application feature. However, users have found that these container applications cannot be manually updated using traditional Docker tools (e.g.,`docker pull`commands).

## **Cause Analysis**

**1. Containerized Application Update Mechanism:**

- Container applications in the UGOS Pro system are centrally managed by the system. Their update mechanism is different from that of traditional Docker containers.
- Currently, these container applications can only be updated through the system's “App Center.”

**2. Updates Rely on System Push:**

UGOS Pro performs version verification and compatibility testing before releasing updates to ensure they do not negatively impact system functionality or performance. As a result, container applications can only be updated when officially pushed by UGREEN.

## **Solution**

Currently, container applications in UGOS Pro can be updated as follows:

Open the "App Center" in the UGOS Pro system and go to the Container Applications management page. Check the update status of the target container application. If a new version is available, click the “Update” button to complete the process.

**PC side:**

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250718/0ffd0b3f-4f5f-48d6-a768-29fba626da5d.png)

**Mobile side:**

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250718/a111b550-3e79-4e79-84af-947b9d059a95.jpg)

**Notes**

1.The update schedule for container applications is not fixed. It is recommended to visit the "App Center" regularly to check for new version releases.

2. The UGOS Pro development team is continuously improving the container application functionality, and more flexible update methods may be supported in future versions.
