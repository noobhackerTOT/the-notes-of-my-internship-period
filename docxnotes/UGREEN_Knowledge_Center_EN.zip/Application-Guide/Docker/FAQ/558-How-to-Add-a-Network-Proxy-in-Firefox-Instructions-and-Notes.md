# How to Add a Network Proxy in Firefox: Instructions and Notes

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTU4In0=

When using the Firefox app on the UGOS Pro system, please exercise caution when configuring a network proxy in the Firefox browser. Once a proxy is added, access requests may be routed through the proxy server, which can lead to issues such as the inability to access local resources within the LAN, including containers, virtual machines, and other devices. This article provides a detailed guide on how to add a network proxy in Firefox, along with important notes and troubleshooting tips.

## **Adding a Network Proxy**

1. **Open Firefox**: Launch the Firefox browser.
2. **Go to Settings**: Click the menu button (≡) in the top right corner and select "Settings".
3. **Network Settings**: In the General panel, scroll down to “Network Settings” and click "Settings".
4. **Configure the proxy server for accessing the internet**:
5. Select “Manual proxy configuration”.
6. Enter the proxy server’s address and port number.
7. Click "OK" to apply the settings.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250523/c08a3cd9-f247-486b-a443-2d7ba5b456a0.png)

## **Solutions**

1.**Disable the network proxy**:

If you need to access resources within the local network, temporarily disable the network proxy settings in Firefox. You can find and turn off the proxy option in the browser's network settings.

2.**Set exception rules**:

If you must use the network proxy, you can add address ranges that bypass the proxy in the browser’s network settings, such as 192.168.*.* or 10.*.*.*, to ensure local network resources remain accessible.

## **Notes**

1.**Impact of the proxy server**:

After adding a network proxy in Firefox, all network requests may be routed through the proxy server. This may result in the inability to directly access devices within the LAN (such as containers and virtual machines), since the requests are redirected to the proxy server.

2.**LAN access restrictions**:

Due to the proxy server's routing, you may find yourself unable to access LAN resources. This includes but is not limited to NAS devices, containers, and virtual machines. The reason is that proxy servers typically cannot access private IP addresses within a local network.

3.**Security**:

When using Firefox on an untrusted device, it is recommended to clear your browsing history promptly to ensure data security. Proxy servers may log your browsing activity.
