# Docker

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjM2In0=

**Applicable Version:** UGOS Pro 1.10.0.0092 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

It is not recommended to install this app on ARM-based devices with ≤ 4 GB of RAM, as it may affect system performance and stability.

## Feature Overview

Docker is a powerful containerization tool. On UGREEN NAS, Docker can be used to quickly deploy various services and applications, such as personal blogs, download tools, private cloud notes, DDNS resolution services, and more.

With Docker, users can flexibly create, run, and manage multiple independent application containers on the NAS, achieving "**multiple uses on a single device**". This allows the NAS to function not only as a storage device but also as a powerful multi-application platform.

## Install the App

1. Open "**App Center**", locate the Docker app in the app list,.

2. Click "**Install"** to start the installation wizard, and follow the wizard prompts to complete the installation setup step by step.

## Overview

The **Overview** page serves as your digital dashboard, allowing you to quickly understand the overall health and operational status of the service.

● **Resource Monitoring**: The system displays real-time CPU and memory usage of the Docker service.

● **Status Summary**: You can view the total number of containers and projects, how many are currently running, as well as the number of images stored locally.

● **Storage Usage**: View the amount of volume used by images and containers (this data does not include application data generated inside containers).

● **Container Resource Usage**: The system provides detailed resource statistics for running containers, including CPU usage, memory usage, network upload speed, and download speed. You can view a single container or compare multiple containers side by side.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/4198aa0ab6994a41b2476f67a4106671.webp)

## Project

The "**Project**" page is used to manage containerized services deployed with Docker Compose. By using orchestration files (docker-compose.yml), you can start or stop a group of interrelated containers at once, enabling efficient batch management of multi-container applications.

### Managing the Project List

On the Projects page, you can view all created project configurations and quickly locate target projects using search, filter, and sort functions.

● **Status Control**: You can "**Enable**" or "**stop**" existing projects.

● **Access Settings**: For more detailed management, double-click a project entry or click **"···**">"**Settings**" on the right side of the project to enter the project details page.

### Creating a New Project

You can create a new Docker Compose project by following these steps:

1. **Create Project**: Click the "**Create**" button and enter the project name.

2. **Automatic Directory Creation**: The system automatically creates a folder with the same name as the project under the shared `docker` directory to store project data and configuration files.

3. **Configuration File**: The system supports Compose configuration files with `.yaml` or `.yml` extensions.

### Via the Project Settings

Double-click the project you want to access to enter its settings page. In this page, you can switch between different tabs to monitor and maintain the project:

● **Container**: View the list of all container instances included in the project.

● **Resource monitoring**: For running projects, view real-time CPU and memory usage.

● **Logs**: View project runtime logs to help troubleshoot issues.

● **Compose Configuration**: View or edit the current YAML configuration file.

**Note**: If you modify the configuration, be sure to click "**Redeploy**" for the new settings to take effect.

## Container

The "**Container**" page displays all containers created on the device. Regardless of how a container was created, you can monitor and manage it centrally from this interface.

### Unified Container View

The system provides a centralized view of all containers on the device, with support for search and filtering. Containers typically originate from the following four sources:

● Containers manually configured and enabled by users using local images.

● Containers created by importing JSON configuration files.

● Containers deployed through "**Project**".

● Containers installed via the "**App Center**" rely on Docker to run and function as associated components.

### Differentiated Editing Permissions

Different management policies apply based on the container's source:

● **Directly Editable**: For containers created manually or imported via JSON, you can click "**Edit**" to modify parameters directly.

● **Edit in Project**: For containers deployed through "**Project**", you must go to the "**Project**" page, modify the corresponding Compose configuration, and redeploy the project.

● **Not Editable**: For containers associated with apps installed from the App Center, configuration changes are not supported to ensure system stability.

### Basic Management

In the "**Container**" list, you can perform the following management actions directly on containers:

● **Enable/Shutdown**: Control the running state of the container.

● **Restart**: Reload the container service.

● **Delete**: Remove container instances that are no longer needed.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/112b220ee33f43c79d9b4d7c8409bd88.webp)

### Deep Debugging in Settings

After entering a container's settings page, you can use the following tools for troubleshooting:

● **Terminal**: Access the container's command line directly to execute debugging commands.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/bc3726cd9eed4da6aeaed42171fb1c40.webp)

● **Log**: View the container's real-time running logs to quickly identify the cause of startup failures or runtime issues.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/9d069ccc9eec40469dfcab9a31d34485.webp)

### Container Settings

The method for accessing a container's Settings varies depending on the container's source:

**Standard Containers**:On the "**Container**" list page, locate the target container and click "**···**">"**Settings**" to enter.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/1b432c7e378f493c840a61b7c2c24082.webp)

**Project-Associated Containers**:If the container is part of a container group created through a "**Project**", you can access a specific container's settings via either of the following methods:

**Method 1: From the "Container" List**

1. On the "**Container**" list page, locate the container belonging to the project.

2. Click "**···**"**>"Settings**" to enter.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/dc8901f56a534fcca753e3fe71b2206d.webp)

**Method 2: From the "Project**"**List**

1. On the "**Project**" list page, double click the target project or click "**···**"**>"Settings**".

2. In the project settings, go to the "**Container"**tab and click the specific container you want to manage.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/df563db564e545f5918646f1e0d72942.webp)

### Image Updates and Quick Access

● **Smart Updates**: When update detection is enabled and a new image version is available, a notification will appear in the list. You can update the container with a single click.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/afa22b4c43444765a554ae8ee90e022d.webp)

● **Desktop Shortcuts**: You can create desktop shortcuts for frequently used containers. If you are logged in with a **UGREENlink ID**, these shortcuts also support remote direct access to the container's web interface.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/74714ccc52524620bf1a28a6219d2100.webp)

## Image

The Docker application provides a comprehensive image management system. From this interface, you can easily access official resources from Docker Hub, manage locally stored images, and configure network settings to optimize the download experience.

### Searching and Downloading Images

In the "**Image Database**", you can search for and browse official images available on Docker Hub. Once you find the application you need, you can download it locally to prepare for container creation.

### Managing Local Images

In the "**Local**" tab, you can manage all downloaded resources and clearly view each image's name, file size, and specific tag (version) information.

● **Create Container**: Use an image from the list to quickly create and run a new container instance.

● **Free Up Space**: Delete unused or outdated image versions to reclaim NAS volume.

### Advanced Image Settings

In Image's "**Settings**", you can customize network and image source configurations:

● **Configure Accelerator**: Add image accelerator addresses to improve download speed.

● **Add Image Sources**: In addition to the official registry, you can manually add third-party image source addresses.

● **Configure Proxy**: The application supports proxy configuration (you must set up your own proxy server) to ensure image access in special network environments.

## Network

The "**Network**" page allows you to view and manage all network configurations within the Docker environment. Network modes determine how containers interact with external networks and how containers communicate with each other.

**Viewing the Network List**

You can view all network modes currently available on the system, mainly including the following types:

● **Bridge**: The default network mode. Containers are isolated from the NAS network and communicate through port mapping.

● **Host**: Containers directly share the NAS network and do not require port mapping.

● **Macvlan**: Containers can obtain independent LAN IP addresses and exist on the network like physical devices.

## Log

On the "**Log**" page, logs refer to operational records and key event logs of the Docker system.

● **Operation Audit**: Records who performed start, stop, or delete operations on which containers and when.

● **System Events**: Records errors or status changes at the Docker engine level, helping you quickly identify the cause of service issues.

## Management

On the "**Management**" page, you can enable image update detection. When enabled, the system periodically checks whether new images are available for projects and containers and displays update notifications in the container list. Scheduled updates can also be enabled.

Data migration is supported, allowing Docker application user data (including containers, images, and container configurations) to be moved to a new storage location. All newly generated user data will also be stored in the new location.

On the "**Management**" page, you can perform global maintenance for the Docker service, including configuring image update detection and migrating the data storage location.

### Image Update Detection

The system supports automatic image version detection to help keep containers up to date.

● **Update Detection**: When enabled, the system periodically checks whether newer image versions are available for your projects and containers.

● **Update Notifications**: Once a new version is detected, an update notification icon is displayed in the list on the "**Container**" page.

● **Scheduled Updates**: You can enable "**Update as scheduled**" and set a specific time period. The system will automatically perform updates during the specified time.

### Data Migration

When volume is insufficient or a drive replacement is required, you can use the data migration feature.

● The system migrates all Docker application user data (including containers, images, and container configurations) to the new storage location you specify.

● After the migration is completed, all newly generated Docker data will also be stored in the new target location.
