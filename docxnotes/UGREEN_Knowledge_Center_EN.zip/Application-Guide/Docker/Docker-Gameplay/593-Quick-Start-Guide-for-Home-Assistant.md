# Quick Start Guide for Home Assistant

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTkzIn0=

## Application Overview

Home Assistant is an open-source home automation platform that connects local smart home devices and enables automated control.

### Default Login Information

● **Default Access Port:** 8123

● **Local Network Access:**In your browser's address bar, enterhttp://NAS_IP:8123. For example, if the NAS IP is 172.17.70.86, enterhttp://172.17.70.69:8123in the browser to access it.

**Note:**

●You can find [Network Settings] in the "Control Panel," click [Network Connection], and check the IP address of the NAS device.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/3410359b3a6040b48ae877167b4e4852.webp)

●Please do not modify the WebUI port number to avoid causing the admin's ability to navigate via the UGOS Pro App Center icon to become non-functional.

### Configuration Path

● This is the path where the application stores its configurations. For example, you can place plugins like HACS, Homekit, Xiaomi official, etc., in this path.

● Once the configuration folder is set up, please do not delete, move, or rename the folder, as doing so may cause the functionality to become abnormal.

● The folder for the configuration path must be a "Shared Folder" and cannot be a "Personal Folder."

### Path Mounting Rules:

After the application is installed, you can view the corresponding path in the Configuration section on the application details page.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/fbd549eb01c74574a9962e88988fa278.webp)

## Installation Guide

To install the Home Assistant app, please follow these steps:

1. Open App Center, find the Home Assistant app, and click "Install App".

2. Select the volume and click "Next" to continue.

3. Choose the configuration path. The app will read the plugin information from the path. Click "Install" to continue.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/fd265822eb8341ceaecb92e8e174f31d.webp)

## Access Home Assistant

You can access the Home Assistant application using the following methods:

### Method 1: Access via the Application Center (Admin Only)

● Click the Home Assistant application icon, and the system will redirect you to the login page.

### Method 2: Access via Local Area Network (LAN) (Admin and Regular Users)

Access via http://NAS_IP:8123 within the local network. For example, if the NAS IP is 172.17.70.69, enter http://172.17.70.69:8123 in the browser to access it.

### Method 3: Access via Non-Local Network (Admin only)

Admins can access Home Assistant in a non-local network environment through the Firefox app installed on the NAS system:

1. Log in to NAS using UGREEN Link, and open the Firefox browser.

2. After logging into Firefox, usehttp://NAS_IP:8123to access Home Assistant. For example, if the NAS IP is172.17.70.69, enterhttp://172.17.70.69:8123in the browser to access the web interface.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/b3f3e9b54f184be39d926027c35507dc.webp)

## Initial Configuration

When using Home Assistant for the first time, you need to complete the initial setup:

1. Click Create My Smart Home to start the setup guide.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/4b63b6d5a1294e27a93d36ca37be1b13.webp)

2. Create a user account by following the prompts to enter your name, username, and password.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/9954dc2455e842e3ac6aaf7cb86141a4.webp)

3. Set your home location. After completing the setup, click Next to continue.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/fe318c2ec929479c86c264f83ea6d4f5.webp)

4. Choose whether to enable certain features as needed, then click “Next” to proceed.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/86e13076c26348a3b39a6c0e6c85eeb4.webp)

5. Once you reach this step, the initial setup is complete. Click “Finish” to enter the Home Assistant dashboard.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/dd7597a272b04343b3aed3a01823eef1.webp)

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/ad3bd70ddc47446aa57a700d7a082efb.webp)

## Change Language

If you need to change the language, you can set the system language to your preferred language in the User Settings. Click on your username, and in the User Settings menu, switch the language.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/ffa3ed889aaf45ac8954f47349c2ba1d.webp)

## Install Plugins (Integrations)

In Home Assistant, plugins (integrations) are the core tools for extending smart home functionalities. They seamlessly connect devices and services from various brands into the system for unified management. Here are the installation methods for some commonly used plugins, including the HACS plugin store, Xiaomi official plugin, third-party Xiaomi plugins, and Apple HomeKit configuration:

### Install HACS Plugin Store (Prerequisite)

HACS (Home Assistant Community Store) is a community-driven plugin store for Home Assistant, providing a vast array of third-party plugins and themes for easy installation, updating, and management. To install HACS, follow these steps:

1. Visit GitHub to download the latest HACS release package. If you don't have a GitHub account, you’ll need to register for one before downloading the HACS package.

2. As of writing, the latest version of HACS is 2.0.5. Download and install the latest version based on your needs:[https://github.com/hacs/integration/releases](https://github.com/hacs/integration/releases)

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/04c56fb06c304db1aa73236039807eb3.webp)

3. Open the file manager and create the following two folders under the application's configuration directory:

● www: This folder is used to store static resources.

● custom_components: This folder will serve as the plugin directory.

4. The configuration directory is the path you set during the application installation. You can view this path in the Configuration section of the application's details page.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/04c893825c4748b583fe57b84bd9c579.webp)

5. After downloading the HACS ZIP file, extract thehacs.zipfile and upload the extracted folder to the custom_components directory inside the application’s configuration directory.

6. After uploading the plugin, return to the Home Assistant page, go to Developer Tools, and restart Home Assistant

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/9781449b76d14844be7b613aa04cc2eb.webp)

7. After the restart is complete, go to the Home Assistant page, click Settings > Devices & Services, and select Add Integration. Then search for and add HACS.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/3c7d4ee57d8b48888fc697879a451cb5.webp)

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/ffacaaf2f8ba44559cf69bfd6e2d045e.webp)

8. After selecting all the options, click “Submit”.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/b1b7d2c0acd44c2187c3d3d57330d1e5.webp)

9. If the message "could_not_register" appears after submission, please restart the NAS device and try submitting again.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/d32c774ec1ae458db91a76aed05a4fe6.webp)

10. Copy the code from the pop-up window, and click the GitHub URL in the pop-up to proceed with the account binding. If you don't have a GitHub account, you can register one and follow the prompts to complete the GitHub account binding.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/52f12564bad64e70b89385c86e57636c.webp)

11. Follow the instructions to complete the GitHub account binding.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/fcd1e54cfe1c49d18ebbffeb835a7c60.webp)

12. After entering the code, click Continue to proceed.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/5fe24c264bf146f299db354f5fda7bac.webp)

13. Click “Authorize hacs”。

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/3c2224ac4a1e4e74be371b67a288bcd7.webp)

14. Once this is displayed, it means the authorization was successful.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/abe29a60c55a4aeeb7e09f62bb1b1e75.webp)

15. After the binding and authorization are successful, you can see the HACS option in the sidebar of Home Assistant.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/a8cd49b5fa8b49f9a31a843590ae6278.webp)

### Xiaomi Official Plugin (xiaomi_home)

Xiaomi has officially released the xiaomi_home plugin for Home Assistant, which can be accessed on GitHub. This plugin connects Xiaomi devices (e.g., air conditioners, sockets, sensors, etc.) to Home Assistant through the official Xiaomi API, providing stable official support for users who require it.

The installation method is the same as for HACS plugins. Simply place the files in thecustom_componentsdirectory.

Installation Steps:

1. Go to GitHub to download the latest release of the xiaomi_home plugin from[Releases · XiaoMi/ha_xiaomi_home](https://github.com/XiaoMi/ha_xiaomi_home/releases). If you don’t have a GitHub account yet, you can register one and then download the compressed package.

2. At the time of writing, the latest version of xiaomi_home is v0.1.5b2. It is recommended to download and install the latest version based on your needs.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/c89bb33be9eb47dc9edb845a44eafda0.webp)

3. Once the xiaomi_home zip file is downloaded, extract the contents of thexiaomi_home.zipfile and upload the extracted folder to thecustom_componentsdirectory within the application configuration folder.

4. After uploading the plugin, return to the Home Assistant page, go to Developer Tools, and restart Home Assistant.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/4fc5534e7ab44254a9fad9381de8e1b0.webp)

5. After the restart, go to the Home Assistant page, click Settings > Devices & Services, select "Add Integration," search for and add Xiaomi.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/c83b3470b32341128d74b3d438eea059.webp)

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/5e6d38dd6b0a483e862f1b382274b9fb.webp)

6. Check the risk notice box and click "Next" to continue.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/f7a8bf27fe814d66b6a75e756b5be31b.webp)

7. Click "Next" to proceed.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/e2c546515c3c4da8907d3cadf25d921b.webp)

8. Click to log in.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/d5bb9c08ebe545aea0b821aff517b829.webp)

9. Log in with your Xiaomi account.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/ff622cb3d02c42e9a375af9e4c7f84bc.webp)

10. Clicking "Log in" will redirect you to the following page. Change the address from homeassistant.local to the NAS IP address in the address bar, then re-access the address. After doing so, the page will automatically close, and you will return to Home Assistant.

**Note:** You can find [Network Settings] in the "Control Panel," click [Network Connection], and check the IP address of the NAS device.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/6fc96b19398c4455844699abfb0476d8.webp)

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/66f52936f1a44db2a2424a30d2bcd35e.webp)

11. Return to the Home Assistant page, select the home where you want to import devices, and click "Next" to continue.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/857dd3d922814cdab335c8b16466eea8.webp)

12. At this point, you should see your home devices, indicating that the deployment was successful. Click "Finish" to close the page.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/9695da2c546b4450922b7eed378e1d20.webp)

### Install the xiaomi-miot Plugin

In addition to the official Xiaomi plugin, the community also offers a third-party plugin calledxiaomi-miot. This plugin supports more Xiaomi devices via the MIoT protocol, including some devices not supported by the official plugin.

Follow these steps to install xiaomi-miot via HACS:

1. Search for "Xiaomi Miot Auto" in the HACS store, then download the plugin.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/1472c5c5a419479fa1b4b0a7d3323ffd.webp)

2. Click "Download" to start the download. Once the download is complete, restart the Home Assistant container. You can either restart the Home Assistant container in the [Docker] app or click "Restart" in the [Developer Tools] section of the Home Assistant page.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/b634f41e9e3645d791218b5eae80f31e.webp)

3. After the container restarts, go to [Settings > Devices & Services] in Home Assistant, click "Add Integration", search for "xiaomi miot auto", find it, and click the icon to add it.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/186cfe8d4c404fb596d632620e58b586.webp)

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/c49804832d50464b98e3528fe5075478.webp)

4. Select "Add Devices Using Mi Account" and click "Next".

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/417c9c51f05a4b218aa09888d40c2610.webp)

5. Enter your Xiaomi ID and password, select "Automatic" mode, and click "Submit".

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/cf4ce4262d744b1eb80ee9442d2cb651.webp)

6. Select the devices to include or exclude based on your needs, and complete the integration setup. The inclusion rule is to manually select the devices you want to bind, while the exclusion rule is to manually select the devices you don't want to bind.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/0d355cc7c7d64688bc354d8c5e7eaee4.webp)

7. After submitting, we can view the devices we've added on the [Overview] page. From here, we can control all the Mi Home devices integrated into Home Assistant.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/d11c6723f3bf4100bbfd3d4e067b31bb.webp)

### Configure Apple HomeKit

Apple HomeKit is Apple’s smart home platform. Home Assistant offers integration with HomeKit, allowing users to control Home Assistant devices through Apple’s Home app or add HomeKit devices to Home Assistant for unified management.

If you want to add devices from Home Assistant to the Apple Home app, follow these steps to configure it:

1. In Home Assistant, click Settings > Devices & Services, click Add Integration, search for “apple,” and click the Apple icon to enter the next menu.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/4c00e4125dd74db4b327f361f4148201.webp)2.

2. After entering, click HomeKit Bridge. You can choose the domains you want to include based on your needs. Domains can be understood as different types of devices. After selecting, click "Submit".

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/8dc93cc33a5a41b892bb49bfc0277e53.webp)

3. In the "Pair with HomeKit" step, follow the guide and click Submit > Finish.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/d071a9e6907f49d8a105f77a4400b9c8.webp)

4. Click "Notifications" in the sidebar, then use the Apple Home app to scan the generated QR code to complete the pairing.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/97c21b9363af4886ae49aca316daefeb.webp)

## Enable Remote Access for Home Assistant

UGREEN NAS supports exposing container applications for remote access. Using Home Assistant as an example, users can remotely access its management interface via a web browser, PC, or mobile device, enabling a seamless smart home control experience across devices.

Please ensure that both your UGOS Pro system firmware and the container application are updated to the latest version. Remote access is not supported in older versions.

The remote access feature is only available when logging into the system using a UGREENlink ID. Click the container application icon, and the system will automatically redirect to the remote access interface. This feature is not available for users logging in via DDNS or other methods.

### Preparation Before Configuring Remote Access

1. Open the [App Center], go to the Home Assistant application's details page, and click the [Configure] button to view the configuration file path for the application.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/e95c04dce18a44d3aa858cbd4062c790.webp)

2. In [Files], navigate to the configuration path obtained in the previous step and locate theconfiguration.yamlfile. If you cannot edit the file directly, please install the [TextEdit] app from the App Center.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/1685b0f8ef7c4ae3a89858cdcfb4ed64.webp)

### Edit the configuration.yaml File

Open theconfiguration.yamlfile using the [TextEdit] app. Add the following content to the file, then save the changes and close the editor.

```
http:
  use_x_forwarded_for: true
  trusted_proxies:
    - 0.0.0.0/0
```

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/b6d0b493421042cba65248ad4be3d8cd.webp)

### Restart the Home Assistant Application

After completing the configuration, you can restart the application using either of the following methods:

● Click “Restart” within the Home Assistant application interface;

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/1001cffef2f24f30b64c02caa5070d5f.webp)

● In the [App Center], disable the Home Assistant application and then re-enable it.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/493fa43b6fa244a99408682430625f08.webp)

After a successful restart, you can click the Home Assistant icon in the UGOS Pro system, and the system will automatically redirect you to the remote access interface.

![](https://file1-cn.ugnas.com/admin/article/2025-08-08/b074f58c27b649a9bcccb0c6c36b7dd7.webp)

Please ensure that you are currently logged in with a UGREENlink ID account, as the remote access feature will only function properly under this condition.

## Usage Tips

To ensure the best experience and protect your data while using NAS devices and related applications, please keep the following points in mind:

1. When accessing the NAS within a local network, it is recommended to use the Chrome browser for a more stable and smooth experience.

2. If you log in to the NAS from an untrusted device or on a public network, be sure to clear your browser cache, cookies, and browsing history afterward to prevent data leaks.

3. Regularly update your password with a strong and complex one to enhance security and reduce the risk of unauthorized access.

4. When multiple people share a device (such as accessing the NAS via the Firefox app), it is recommended to disable the “Remember Password” feature and regularly clear browsing history to protect your account.

5. Avoid moving, renaming, or deleting NAS folder paths that are mounted by container applications, as this may cause malfunctions or data loss.

6. When accessing container applications through a browser, open the “Control Panel” app and disable the multi-gateway option under [Network Management] to avoid network conflicts.

7. Container applications are suitable for beginners. However, if you need more flexible configuration options, it is recommended to use Docker directly for greater control over config files and access to advanced features.
