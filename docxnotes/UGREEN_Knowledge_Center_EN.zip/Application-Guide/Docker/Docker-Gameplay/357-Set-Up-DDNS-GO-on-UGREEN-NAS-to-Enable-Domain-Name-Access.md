# Set Up DDNS-GO on UGREEN NAS to Enable Domain Name Access

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzU3In0=

DDNS-GO is a Dynamic DNS service tool that supports Docker container deployment. Its main function is to automatically update the dynamic public IP address of a local network to a domain name service provider, allowing users to access internal network devices and services via a fixed domain name.

Note: It is not recommended to use this container together with the Lucky container.

# Usage Instructions

Below are the basic steps to deploy DDNS-GO using Docker:

## Pull the Image

Go to [Docker] > [Image] > [Image Database], search for`jeessy/ddns-go`, use the default latest version, and click "Confirm" to start pulling the image.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/fd245adf984a4d889b6199df3cb9ddeb.webp)

## Create a Directory for Storing the DDNS-GO Configuration File

Open Files, and create a shared folder named docker under Shared Folders. It is recommended to place the docker shared folder on SSD storage for better performance. This directory will be used to store configuration files for future Docker deployments. Then, inside the docker folder, create a subfolder named ddnsgo, which will be used to store the configuration files for this DDNS-GO deployment.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/fd9b23ee16ec4c17bd8ff06490541efc.webp)

## Domain Name Purchase

Alibaba Cloud:[https://wanwang.aliyun.com/](https://wanwang.aliyun.com/)

Tencent Cloud:[https://dnspod.cloud.tencent.com/](https://dnspod.cloud.tencent.com/)

1. It is recommended to purchase domain names from Alibaba Cloud or Tencent Cloud. In this example, we will demonstrate the process using Alibaba Cloud. After logging in to Alibaba Cloud, enter your preferred domain name in the search bar, select the desired domain suffix, and click "Domain Search". It's recommended to choose a numeric XYZ domain. After selecting it, click "Add to Cart" in the domain field, then click "Buy Now".

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/7598294cc4c84858a157cd6bd128b6f2.webp)

2. Select the subscription period, fill in the information form as required to complete the real-name verification, then click "Buy Now" to proceed to payment.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/ce5b80fdbc28401f8f14cb2b6e5db40a.webp)

3. After a successful purchase, click the avatar icon at the top right corner to enter AccessKey Management.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/077d01af558b42dda9c92503bf853747.webp)

4. Create AccessKey, then save the Key ID and Secret securely, as you will need them later.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/5e8c4b532a3f4542a4f80df5951f132b.webp)

5. Add a DNS record: click [Cloud DNS](https://account.aliyun.com/login/login.htm?oauth_callback=https%3A%2F%2Fdns.console.aliyun.com%2F&lang=zh#/)/ [Domain Resolution](https://account.aliyun.com/login/login.htm?oauth_callback=https%3A%2F%2Fdns.console.aliyun.com%2F&lang=zh#/dns/domainList)to navigate to the domain resolution page, then select your domain and click "DNS Settings". Add a record in the DNS settings.

6. If you want to use the root domain to access your site (for example, if your domain is`20240709.xyz`), simply enter **"@"** in the host record field.If you want to use a subdomain, enter the desired subdomain name in the host record field—for example, add "ugreen" here.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/10f57ecf1f5e44c08e64846c1c24180e.webp)

## Create and Configure the Container

1. After the image has finished downloading, start creating the container. From the local image list, select the recently downloaded`jeessy/ddns-go`image. Click`+`Create Container and configure the container parameters.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/1964bd0508184a59ae4d33ca39eef617.webp)

2. In the Basic Information section, enable "Auto restart".

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/6fb9801040db4ba4842da6f3003011d3.webp)

3. Add the NAS directory in the storage space and set it to the ddnsgo directory we just created. Enter /root as the container directory, and set the container permission to Read/write.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/31ea82b0dbeb41f486b26567656efac9.webp)

4. The default network mode is bridge. You can set a custom port on the NAS side—make sure the port does not conflict with others.If you need to use IPv6 networking, please change the network mode to host.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/d116d2995db8462cb997f975645f0e06.webp)

5. Keep the advanced settings at their default values. After confirming the configuration is correct, click "Confirm" to create the container.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/04e9e20685e34d8fa487950cf643eaef.webp)

6. After the container is successfully created, you can manage the created containers on the Container page.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/1cd8484c815f4465993db4f65bd5415a.webp)

## Initial Configuration

1. After the container starts, you can access the DDNS-GO Web UI through a browser by visiting the URL: `http://<NAS_IP>:36779` Replace`<NAS_IP>`with your NAS device's actual IP address. For example, enter`http://172.17.70.69.36779`as shown below.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/b7cf98ec0d014dc7b363901eefc333da.webp)

2. Select Alibaba Cloud as the service provider, then enter the AccessKey ID and Secret obtained earlier into the corresponding input fields.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/e0f057278bf345499a1065970d2c6643.webp)

3. Next, configure the DNS settings according to your public IP type. If you have an IPv4 public IP, enter the domain name you have already set up in Alibaba Cloud into the Domains field. If you have an IPv6 public IP, change the IP acquisition method to obtain via network interface, and ensure that the NAS network interface has IPv6 enabled. The domain name in the Domains field can be the same for both IPv4 and IPv6.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/2f1ae5cbe4ad4f9da61c49bb3e762fcb.webp)

4. After confirming the configuration is correct, click the [Save] button at the bottom or top-left of the page. Wait a moment, and you will see logs in the list on the right indicating that the DNS resolution was successful.

## Accessing the Container via Domain Name

To access the container using a domain name, you first need to set up port forwarding for the container's Web UI port on your router.Port forwarding settings vary between different router models. Please consult the user manual provided by your router manufacturer for detailed instructions.The screenshot below shows an example of port forwarding on a Xiaomi router:

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/c49451407b4f4882beb0f824ef7b4216.webp)

## Enable Public Network Access

To enable public access to DDNS-GO, please disable [Deny from WAN], set up your username and password, and then configure port forwarding for port 9876 on your router.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-08/b0f887c5b9e147fba5fb80c492e98237.webp)

## Note

● The images mentioned in this tutorial are developed and maintained by third parties. This tutorial is for reference only. UGREEN does not assume any liability for risks caused by improper operations, software vulnerabilities, or image updates, such as file corruption or data leakage. Please use trusted images to ensure system and data security.

● Container file paths can be customized. When accessing via a web browser, the container port and the local port must be the same, and local ports of different containers must not conflict.

● Container web links are only accessible in bridge mode.

● The images are provided solely for setup guidance. For specific usage and features, please refer to online resources. For configuration changes and bug fixes, follow the official updates.

● It is recommended to store the Docker configuration directory on an SSD to avoid performance degradation caused by mechanical hard drives.

#####
