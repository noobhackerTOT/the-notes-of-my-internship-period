# [Docker Usage] Setting Up SiYuan via Docker for Efficient Personal Knowledge Management

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDE5In0=

SiYuan is a widely popular Markdown editor and knowledge management software. It helps users establish connections between various notes in a graph-like manner, forming a personal knowledge network, making it highly suitable for building a personalized knowledge management system. This article will introduce how to deploy SiYuan on the UGOS Pro system using Docker and briefly explain its highlights and advantages.

## Highlights and Features of SiYuan:

1. **Bidirectional Linking:**One of the core features of SiYuan. Users can create interactive relationships between notes through automatic or manual bidirectional links, forming a networked knowledge structure. This web-like structure effectively promotes information association, thought divergence, and knowledge innovation.

2. **Markdown Support:** SiYuan is fully compatible with Markdown syntax, making notes clear and readable with high cross-platform compatibility and portability.

3. **Blockquote Feature:**Users can quote a specific text block rather than the entire document. This flexibility adds a sense of hierarchy to information reuse and organization, increasing the precision of data citation.

4. **Powerful Plugin Ecosystem:** SiYuan supports a rich plugin system that can extend its functionality, such as calendars, task management, mathematical formulas, Gantt charts, etc., almost meeting any personalized work requirements.

5. **Local Storage and Data Security:**Data is stored locally rather than in the cloud, ensuring the privacy and security of user information. Additionally, database encryption provides extra protection for data security.

6. **Graph-like Knowledge Organization:** Users can construct a visual interface of knowledge graphs through drag-and-drop operations, helping to understand the connections between notes more intuitively.

7. **Version History:**Every note edit automatically saves a historical version, allowing users to trace back and restore to any historical version at any time, making it ideal for documents that are frequently modified.

## How to Deploy SiYuan with Docker Compose

To accommodate the special configuration requirements of SiYuan, it is recommended to use Docker Compose for deployment. Here are the steps to deploy SiYuan using a Docker Compose project: [What is project (Docker Compose?)](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAxIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImlkIjozMzIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiJwcm8wMDIsOWpvcDV3LGUyZVNueiJ9)

**Enter the Docker Project Interface:**

In the UGOS Pro system, open the Docker application, click [Project] > [Create] to launch the project creation wizard.

**Configure the Docker Compose File:**

When creating a project, you need to provide a Docker Compose configuration file. Here is an example of a configuration file:

```
version: "3.9"
services:
  main:
    image: b3log/siyuan  # docker image
    container_name: siyuan # Container name
    user: '0:0' # Username and user group for read/write permissions 
    command: ['--lang=zh_CN','--workspace=/siyuan/workspace/', '--accessAuthCode=123456'] # Specify the workspace directory/siyuan/workspace/ and set the access password (password to be set by you)
    environment:
      # A list of time zone identifiers can be found at https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
      - TZ=Asia/Shanghai  # Set the time zone
      - LANG=zh_CN.UTF-8
    ports: # Port mapping
      - 6806:6806  # The port before the ":" can be set by you. This maps the container's internal port 6806 to the NAS's port 6806.
    volumes: # Folder mapping
      - ./workspace:/siyuan/workspace # The path before the ":" can be set by you. "./" represents the directory where the current Docker Compose file is located.
    restart: unless-stopped # Always enable the container after NAS restart
```

**Parameter Explanation:**

● `image`：Specifies the Docker image for running SiYuan.

● `container_name`：The container name for identification and management.

● `command`：Specifies the startup command, sets the language to Chinese, defines the workspace path, and sets the access password.

● `ports`：Maps the container's internal ports to the NAS ports to allow access via a web browser.

● `volumes`：Maps the local workspace to the container to ensure data persistence. Mounts the NAS's`./workspace`to the container's`/siyuan/workspace`path.

● `./workspace`：In this context,`./`represents the directory where the current Docker Compose file is located.`./workspace`refers to a directory on UGOS Pro, specifically the`workspace`subdirectory within the directory where the Docker Compose file resides.

● `restart`：Configures the container to automatically restart after the NAS reboots.

● `environment`：Sets environment variables.

● `user`：The image defaults to using the default user siyuan (uid 1000/gid 1000) created by the image to start kernel processes, which does not have sufficient permissions, so it needs to be changed to root permissions (uid 0/gid 0).

**Deploy the project:**

After confirming that all configurations are correct, click the "Deploy Now" button. The system will pull the image according to the YAML file, create, and run the container.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-05/dbe4996392724e0e893dc7f5ceda99bf.webp)

**Access SiYuan:**

After successful deployment, open a web browser, enter the NAS IP address and the mapped port number in the address bar, for example:`http://192.168.66.43:6806`. Enter the set access password (e.g.`123456`), and click "Unlock Access" to enter the SiYuan interface.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-05/e14d9673459747bdb61a7a5683b82b4e.webp)

**Initial Setup and Usage:**

Since we set the language to English in the startup command, the system will automatically display a user guide in English after entering the interface. The guide includes detailed instructions on how to use SiYuan, and you can quickly get started by reading the guide.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-05/085bf874f5ef4284950a0865b174eb59.webp)

If you accidentally close the user guide interface, you can continue to browse the "User Guide" on a blank page.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-05/9d038b207d6f42c28b81c2d3a3346bc3.webp)

### Notes

1. **Storage and Hard Drive Hibernation Problems:** It is recommended to store the Docker configuration directory on an SSD to avoid mechanical hard drives from failing to enter hibernation, which can affect system performance.

2. **Backup and Sync:**The Docker version of SiYuan supports local access, and no additional synchronization tools are required for daily use. If synchronization is needed, you can use the synchronization/backup feature of UGOS Pro to synchronize the workspace directory to other devices. Learn about ["Sync & Backup"](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTgzLCJ0eXBlIjoidGFnMDAxIiwicGF0aENvZGUiOiJwcm8wMDIsazZybGJzIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=)features.

By deploying SiYuan with Docker, you can access your notes anytime, anywhere through a browser and enjoy the security and privacy protection brought by local data storage. For users with high knowledge management needs, SiYuan provides a powerful and flexible tool to build a personal knowledge system.
