# Deploy a Personal Novel Reader (Reader) on UGREEN NAS

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDQxIn0=

## Application Overview

**Reader** is a tool designed specifically for online literature enthusiasts, aiming to provide a convenient, fast, and comfortable trial reading experience. With Reader, users can not only read novels through web pages but also synchronize reading progress in mobile browsers, and even use the voice auto-reading feature. For more functional details, please refer to:[Official Documentation Introduction](https://github.com/hectorqin/reader/blob/master/doc.md)

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/3bd0c7aff1804d1d9772250af86b429f.webp)

## Docker Compose Deployment

On the UGOS Pro system, it is recommended to use [**Docker Compose**](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAxIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImlkIjozMzIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiJwcm8wMDIsOWpvcDV3LGUyZVNueiJ9)to quickly deploy containers via the Projects section. This method is suitable for scenarios that require managing multiple containers at once and helps simplify container deployment and management. The following are the detailed steps for deploying containers using Docker Compose:

1. Open the **"Docker"** application and click [Project] > [Create] to start the project creation wizard.

2. In the project creation wizard, enter the Docker Compose configuration for the container. The provided configuration is for reference only — feel free to adjust it according to your needs.

```
services:
  read_own:
    image: hectorqin/reader:latest
    container_name: reader_own
    restart: always
    ports:
      - 4395:8080
    volumes:
     - ./reader/logs:/logs
     - ./reader/storage:/storage
    environment:
     - SPRING_PROFILES_ACTIVE=prod
     - READER_APP_CACHECHAPTERCONTENT=true
```

3. After completing the configuration file, click "Deploy". The system will automatically pull the image and start the container.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/5bb6555a022f4cdf8579d9e2a80371a6.webp)

4. After deployment is complete, access the container via a browser by entering`http://NAS_IP:8096`in the address bar. For example, if your NAS IP is`172.17.70.69`, enter`http://172.17.70.69:8096`in the browser to access it.

You can find the NAS device's IP address by going to [Control Panel] > [Network], then clicking "Network Connection".

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/fe69e372e9f94119a785e668af431a49.webp)

### Compose Configuration Parameter Description

| Parameter | Description |
| --- | --- |
| image | Specifies the Docker image. latest indicates the latest version. |
| restart | Sets the restart policy to always , so the container will automatically restart if it crashes or stops, ensuring continuous service availability. |
| environment | Sets environment variables to configure services inside the container. ● SPRING_PROFILES_ACTIVE=prod : Used to save log files. ● READER_APP_CACHECHAPTERCONTENT=true : Enables chapter content caching to improve loading speed. |
| ports | Port mapping: maps NAS port 4395 to container port 8080, allowing access to the web interface via http://NAS_IP:4395 . |
| volumes | Maps local NAS folders to mount paths inside the container. ./reader/logs:/logs : Used to store log files. ./reader/storage:/storage : Used to store persistent data. |
| Additional Notes | ./ refers to a path relative to the directory you selected when creating the project. ./:/ means mounting the local ./ directory on the NAS to the container's root / directory. The path before the colon is the storage path on the NAS, and the path after the colon is the corresponding mount path inside the container. |

## User Guide

1. Enter`http://<NAS_IP>:4395`in your browser to open the initial interface of Reader and start using it.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/dfa52975a4c044d3a176c4f32d7cb0a8.webp)

2. You can search for and import book sources on your own. Book sources come in two types: local files and online links. Ensure the file format is`txt`or`json`when importing book sources. The search and import of book sources need to be handled by yourself.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/7098f00e81e24e9390ee8840d79ea62b.webp)

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/080c15ece3fb4cecbaf09406c862c7e0.webp)

3. For local books, you can import various file formats, including`txt`,`epub`,`pdf`, etc. Imported books can be grouped and categorized for easy subsequent search and management.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/cb85f2d4d3ae4ee4aa41b51bc4dcecac.webp)

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/0b7f54dbf65349108b7bcd78ea2b4d51.webp)

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/7d2ddca362dd4d55aa7820cda471c38d.webp)

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/0240a8a2681e4fe3a09ad00e85875213.webp)

4. Reader is a web-based reading application, and as long as your device supports browser access, you can use Reader on your phone. For Android users, it is recommended to download the Legado reading application, which can be obtained from the Android app store. IOS users currently do not have a dedicated APP, but can access`http://<NAS_IP>:4395`through Safari or other iOS-supported browsers for reading.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-15/2eb4d4ac03e8499fa2f6d4fa1c0b602d.webp)

## FAQ

### Q: Get the real path of the NAS folder and mount it to the Docker container

When using Docker, you may need to mount a NAS folder to a container so the container can access data on the NAS. Refer to [Get the real path of the NAS folder and mount it to the Docker container](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6MTkzMCwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo2MTEsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ%3D%3D)for step-by-step instructions.

## Notes

● The images mentioned in this guide are developed and maintained by third parties. This guide is for reference only. UGREEN is not responsible for risks caused by improper operations, software vulnerabilities, or image updates—such as file corruption or data leakage. Please choose trusted images to ensure system and data security.

● Container file paths can be customized. When accessing via a browser, the container port must match the local port. Ensure that different containers do not conflict on local ports.

● Web access to containers is only available when using bridge network mode.

● This guide only provides setup instructions. For specific usage and features, please consult online resources. For configuration changes and bug fixes, follow official updates.

● It is recommended to store Docker configuration directories on SSD drives to avoid performance issues caused by mechanical hard disks.
