# APP Center

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTE2In0=

## Feature Overview

In the UGOS Pro system, the "**App Center**" provides a wide range of software applications to help you extend the functionality of your NAS. You can install and manage apps from the App Center at any time, including performing update, disable, or uninstall actions, as well as adjusting relevant settings of the App Center as needed.

**Main Features of App Center:**

● **Install Apps**: Browse, search, and install the desired apps in the App Center.

● **Manage Apps**: Perform run, disable, uninstall, or update operations on installed apps.

● **App Center Settings**: Configure the default storage location, enable auto ipdate settings, and other options.

## Install Apps

● **Install Directly from "App Center"**

1. Open the "**App Center"**, browse or search for the desired app, and click "**Install**".

2. After installation, the app icon will appear on the NAS home screen.

**Note**: Applications marked with "**Associated apps**" in their details are container-based applications. Their installation, uninstallation, and deactivation all depend on Docker. For more information about container applications, please refer to [About Container Application](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmNTM5In0=).

● **Manual Installation**

1. Visit the [UGREEN NAS Download Center](https://nas.ugreen.com/pages/downloads)and download the required app package (.UPK format).

2. Open the "**App Center**" and click "**Manual Install**" in the upper-right corner.

3. Select the downloaded .UPK file path and confirm to start installation.

![](https://file1-cn.ugnas.com/admin/article/2025-12-30/90fab06015444906af717d9bfecf326c.webp)

## Manage Apps

● **Update Apps**: The "**App Center**" will notify you when updates are available. You can either manually click to update, or enable "**Update app automatically**" in the "**Settings**".

● **Disable/Uninstall Apps**: Locate the target app in the "**App Center**", open its details page, and select disable or uninstall to free up NAS performance resources.

![](https://file1-cn.ugnas.com/admin/article/2025-12-30/d5c7864babaf44e4a598e627ecae97c5.webp)

● **Hide Installed Apps**: Click the "**Sort**" icon in the upper-right corner of the App Center and select "**Hide Installed Apps"** to temporarily hide installed apps and keep the interface clean.

![](https://file1-cn.ugnas.com/admin/article/2025-12-30/5d58cf624a8a4caa86b4806115ff75a9.webp)

## How to Add Apps to the Desktop

After installation, the system will automatically create a shortcut on the NAS desktop. If you accidentally delete the desktop shortcut, you can re-add it as follows:

1. On the NAS desktop, open the "**My apps"**.

![](https://file1-cn.ugnas.com/admin/article/2025-12-30/da20a0945fd2469e822c9b6e9e9175e3.webp)

2. Locate the desired app, right-click its icon, and select "**Create desktop shortcuts**".

![](https://file1-cn.ugnas.com/admin/article/2025-12-30/23ab754182ab4acc8bf638d0ff7a9da4.webp)

3. Return to the NAS desktop to see the shortcut.

**Note:**

● Adding a shortcut to the desktop only affects desktop display and does not impact the installation or use of the app.

● You can repeat the same steps to add the app again.

## App Center Settings

In the App Center settings page, you can adjust the default strategies for installation and updates to improve management efficiency.

**Configurable options include:**

1. **Default Storage Location**: You can specify the default location for new apps (e.g., SSD or a designated storage volume). It is recommended to install frequently used or performance-demanding apps on SSD storage for a better experience.

2. **Create Desktop Shortcut Automatically**: When enabled, a desktop shortcut will be automatically created on the NAS desktop each time a new app is successfully installed, making it easier to launch apps quickly.

3. **Auto Update Settings**: When enabled, the system will automatically detect and update installed apps. Multiple update strategies are supported and can be selected as needed.

![](https://file1-cn.ugnas.com/admin/article/2025-12-30/b13de33c2199427c9291c39a8e1461c8.webp)
