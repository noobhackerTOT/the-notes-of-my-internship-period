# Troubleshooting Guide for NAS Device Detection Failure

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTgxIn0=

## Issue Overview and Context

When using your NAS device, you may encounter a "Device Not Detected" prompt, preventing a proper connection to the device. This issue can arise due to various factors, including network, hardware, or software anomalies. Below, we analyze common causes and provide detailed troubleshooting steps to help you quickly restore the device to normal operation.

![](https://file1-cn.ugnas.com/admin/article/2025-08-26/1209832b24e04098ba7d729721b0bef1.webp)

## Network Troubleshooting and Resolution

**1. Check Physical Connections**

Verify whether the NAS is properly connected to the network. For wired connections, check if the LAN indicator is flashing white. If the LAN indicator is flashing orange, it indicates a network issue.

**Troubleshooting and Solutions**

● **Inspect the Ethernet Cable:** Carefully examine the cable for physical damage such as cracks, bends, or breaks. Even minor damage can cause unstable or interrupted signal transmission.

● **Secure the Cable Connections:** Gently tug both ends of the Ethernet cable to verify they are securely inserted into the ports. If loose, reinsert the cable firmly until you hear a "click", indicating it is properly locked in place.

● **Replace Damaged Cables:** If the cable shows signs of damage or fails to perform during testing, replace it with a high-quality new cable. Opt for cables that meet industry standards (e.g., Cat5e, Cat6, or higher) to ensure optimal network performance.

● **Recheck Connections:** Recheck the connection: Ensure that the Ethernet cable between the NAS device and the router or switch is properly connected. Make sure one end of the cable is plugged into the corresponding port on the router or switch, and the other end is plugged into the NAS device.

● **Test the Network Connection:** After completing the steps above, attempt to access the NAS device to check if the network connection has been restored.

**2. Test Network Connection**

To ensure your NAS device is functioning correctly within the network and accessible from Windows or macOS systems, follow these steps for verification and troubleshooting.

**Troubleshooting and Solutions**

● **Check the IP Address**

Ensure that the NAS device has obtained a valid IP address. You can log in to the router's management interface to check whether the NAS device and its assigned IP address appear in the device list, and verify that no firewall rules or port restrictions are blocking communication with the NAS device.

● **Verify the Network Connection**

**For Windows:**

○Press `Win + R` to open the Run dialog.

○ Type `cmd`and press `Enter` to open the Command Prompt.

○ In the Command Prompt, type: `ping <NAS IP Address>`(e.g., `ping 192.168.1.100`), and then press `Enter`.

**For macOS or Linux:**

○ Open the "Terminal" application.

○ In the "Terminal", type: `ping <NAS IP Address>` (e.g., `ping 192.168.1.100`), and then press `Enter`.

● **Analyze Ping Results**

Successful Response: If the Ping command returns a result similar to the following, the network connection is functioning properly:

```
Pinging 192.168.1.100 with 32 bytes of data:
Reply from 192.168.1.100: bytes=32 time<1ms TTL=64
Reply from 192.168.1.100: bytes=32 time<1ms TTL=64
Reply from 192.168.1.100: bytes=32 time<1ms TTL=64
Reply from 192.168.1.100: bytes=32 time<1ms TTL=64

Ping statistics for 192.168.1.100:
    Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),
Approximate round trip times in milli-seconds:
    Minimum = 0ms, Maximum = 0ms, Average = 0ms
```

If the Ping command returns results like the examples below, it indicates a problem with the network connection to the NAS device:

```
Pinging 192.168.1.100 with 32 bytes of data:
Request timed out.
Request timed out.
Request timed out.
Request timed out.

Ping statistics for 192.168.1.100:
    Packets: Sent = 4, Received = 0, Lost = 4 (100% loss),
```

● **Confirm Network Settings**

Identify IP Conflicts: If an IP address conflict is detected (another device is using the same IP address as the NAS), adjust the settings in the router's management interface to assign a fixed IP address to the NAS or change the IP address of the other device to avoid conflicts.

Restart Network Devices: Restarting the router, switch, and NAS device can resolve temporary network issues.

## Hardware Troubleshooting and Resolution

1. **Check the Device’s Operational Status**

Verify that the NAS device is powered on and properly connected to the power supply. Check whether the indicator lights are functioning as expected, and ensure their blinking patterns match the descriptions in the device's operational guidelines.
**Solution:** Ensure the power connection is stable and inspect the indicator light status.

2. **Inspect the Power Connection**

● **Verify the Power Adapter:**

Ensure you are using the original power adapter supplied with the device.

Inspect the adapter for visible damage, such as cracks or burn marks.

● **Check the Power Outlet:**

Confirm the outlet is supplying power by testing it with another electrical device.

If no power is detected, inspect your household circuit or contact your utility provider.

● **Examine the Power Cord:**

Ensure the cord is securely connected between the adapter and the device.

Look for damage, such as fraying or exposed wires.

● **Inspect the Device’s Power Port:**

Remove any dust or debris from the port.

Check for physical damage.

3. **Power On and Check Indicator Lights**

● **Refer to the User Manual:**

Consult the device’s manual or quick start guide for information about indicator light statuses.

If you do not have the manual, download an electronic version from the manufacturer’s website.

● **Visit the Knowledge Center:**

Visit the [knowledge center](https://support.ugnas.com/knowledgecenter/).

Search for relevant tutorials using keywords related to the indicator lights.

● **Observe Indicator Lights:**

Monitor the indicator lights carefully after powering on the device, .

Compare their behavior to the descriptions in the manual or tutorials.

4. **Power On and Check Indicator Lights**

● **Light Not On:**

Recheck the power connection to ensure all components are securely connected and undamaged.

Try replacing the power adapter or cable.

If the problem persists, restart the device.

● **Flashing or Abnormal Light Color:**

Refer to the manual or tutorials to identify the specific error.

For hardware issues, contact customer support for repairs or part replacement.

For software issues, try resetting the device to factory settings.

5. **Restart the Device**

● **Perform a Normal Shutdown:**

Press and hold the power button for 5 seconds to shut down the device.

● **Disconnect Power:**

After shutting down, unplug the power cable and wait a few minutes before reconnecting it.

● **Power On the Device:**

Reconnect the power cable and press the power button to restart the device.

Observe the indicator lights to confirm normal operation.

By following these steps, you should be able to effectively diagnose and resolve power and indicator light issues. If the problem persists, contact technical support for further assistance.

## Software Troubleshooting and Resolution

1. **Troubleshooting and Resolving Software Issues**

Ensure the client software, such as the UGREEN Cloud app, is correctly installed and updated to the latest version.

**Resolution:** Follow these steps to verify and update the client software:

● **Launch the Application:** Open the client software on your device.

● **Update the Software:** If the current version is outdated, check for updates. In some app stores, you may need to manually click the "Update" button, while others may automatically prompt you to install updates.

● **Restart the Application:** Once the update is complete, restart the client software to ensure all features of the new version are functioning correctly.

Keeping the client software updated ensures optimal functionality and enhances the overall user experience.

**2. Remove Security Restrictions**

Firewalls or antivirus software may block NAS scanning requests, causing access issues. Verify that the device is not subject to excessive access restrictions, such as IP whitelisting.

**Resolution:**Ensure the firewall settings on your computer or router do not block NAS scanning requests. If any restrictions are detected, modify the settings to allow the requests to pass through. Additionally, verify the settings of the scanning software to remove any potential firewall blocks.

Follow these steps to check and adjust firewall settings to ensure NAS scanning requests are successfully processed.

3. **Adjust Computer Firewall Settings**

● **Access Firewall Settings:**

**Windows**: Open the "Control Panel", navigate to "System and Security", and select "Windows Defender Firewall".

**macOS**: Go to "System Preferences", select "Security & Privacy", and click the "Firewall" tab.

● **Check the Firewall Status:**

Confirm the firewall is enabled. If not, activate it.

● **Permit the UGREEN App:**

**Windows**: Select "Allow an app or feature through Windows Defender Firewall". Click "Change settings", locate the UGREEN NAS app, and enable both private and public network options. If the app is not listed, click Allow another app, browse for the app, and add it.

**macOS**: **macOS:** Click "Firewall Options", then use the "+" button to locate and add the UGREEN NAS app, ensuring it is allowed through the firewall.

● **Save Changes:** Click "OK" or "Apply" to save the adjustments.

4. **Adjust Antivirus Firewall Settings**

● **Access the Antivirus Software:**

Launch the antivirus software.

● **Access Settings Menu**

Navigate to its "Settings" or "Options" menu.

● **Locate Firewall Options:** Search for sections related to firewall or network configurations.

● **Allow Scanning Requests:** Ensure that the firewall settings within the antivirus program do not block the NAS. Adjust settings to permit these requests or disable the relevant restrictions.

● **Save and Restart:**

After completing the above steps, save the settings and restart the software to ensure the new settings take effect.

By following these steps, you can ensure that the firewall does not block client requests, allowing the scanning process to proceed smoothly.

## Additional Methods for Troubleshooting

**1. Reset Network Settings**

If your network configuration is abnormal, consider resetting the NAS network settings to factory defaults. This can help resolve connection issues caused by improper configurations. Refer to the relevant [**Reset Network & Password**](https://support.ugnas.com/knowledgecenter/)guide for detailed instructions.

**2. Inspect the Router or Switch**

Network issues may result from an overloaded router or switch that has been running for an extended period. Restarting these devices often alleviates the problem. Simply power off the equipment, wait a few minutes, and then power it back on to clear caches and free up resources, restoring normal network operation.

**3. Switch Network Mode**

If your computer is using a wireless connection and frequently encounters unstable signals, try switching to a wired connection. A wired connection provides more stable data transmission speeds and significantly reduces the impact of external interference on network performance.

## Technical Support

If the above methods do not resolve the issue, contact UGREEN NAS's official technical support team for professional assistance.

● **China Support:** 0755-21044617 (Monday to Sunday, 08:00-24:00)

● **US Support:** +1 (888) 820-8830 (Monday to Friday, 09:00-17:00 PST)

● **Germany Support:** +49 800 989 8988 (Monday to Friday, 09:00-17:00)

![](https://file1-cn.ugnas.com/admin/article/2025-08-26/1d54afb8254d4a79b9de7914712f38ad.webp)
