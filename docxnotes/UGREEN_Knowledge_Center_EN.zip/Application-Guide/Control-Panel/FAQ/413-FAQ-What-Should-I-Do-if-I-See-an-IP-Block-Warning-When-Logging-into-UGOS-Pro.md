# [FAQ] What Should I Do if I See an IP Block Warning When Logging into UGOS Pro?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDEzIn0=

## Problem Description

When logging into UGOS Pro, the following message appears:

"The current account blocked due to too many failed logins,please try again 5 min later."

This issue occurs because the number of failed login attempts has reached the system’s allowed limit.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-05/55d2b657ab174be98d7f1b243c05aa0c.webp)

## Solution

You can still log in to UGOS Pro from a different IP address. Follow the steps below to remove the blocked IP:

1. From a computer or mobile device that is **not blocked**, log in to UGOS Pro using an administrator account. If you already know the blocked IP address, skip to step 5.

2. Disable the **"Auto Block"** feature:

● Web Interface: Go to **[Control Panel] > [Security] > [General] > [Auto Block]**, and uncheck the "Auto Block" option.

● Mobile App: Go to **[Control Panel] > [Security] > [IP Auto Block]**, and turn off the "IP Auto Block" toggle.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-05/8f1b3b85fb36446dbcfd0aeb08da5862.webp)

3. On a device that is **not blocked**, log in to UGOS Pro again using an administrator account.

4. Go to **[Control Panel] > [Security] > [General] > [Auto Block]**, and re-enable the "Auto Block" option by checking the box.

5. Click "**Block Management**" to open the list of blocked IP addresses. Locate the blocked IP in the list and click "**Remove**" to unblock it.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-05/dddbc4941ef641afabcb9865145b827d.webp)

If you have forgotten your username or password, or do not have access to another available IP address, you can press and hold the device's reset button for 5 seconds to clear the IP block list.
