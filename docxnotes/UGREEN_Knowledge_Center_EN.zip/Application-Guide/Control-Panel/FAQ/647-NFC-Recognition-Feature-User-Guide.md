# NFC Recognition Feature User Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjQ3In0=

## **What is NFC?**

NFC (Near Field Communication) is a short-range wireless communication technology that allows devices to communicate without physical contact, typically within a range of 2 centimeters. With NFC technology, UGREEN NAS devices can quickly connect with smartphones by simply tapping them together.

## **Compatible UGREEN NAS Models**

The following UGREEN NAS models support NFC functionality:DH4300 Plus

## **Smartphone Operating System and Brand Compatibility**

**Operating System Compatibility**

- **iOS**：Version 15 and above
- **Android**：Version 7 and above

**Brand Compatibility**

Major Android brands that are supported include, but are not limited to:

- Huawei, Honor, OPPO, Xiaomi, Vivo, Google, Samsung phones.

## **User Guide**

**Step 1: Enable NFC on Your Mobile Device**

Using a Huawei phone as an example (the interface may vary depending on the model, so please refer to the manufacturer's instructions):

1. Open your phone's [Settings].
2. Go to the [More Connections] menu.
3. Find the [NFC] option and tap it.
4. Enable the NFC switch in the NFC settings.

**Step 2: NFC Recognition and Quick Connection to NAS**

1. Place your NFC-enabled phone close to the NFC tag on the NAS device (**ensure both devices are on the same local network and within communication range**).
2. Tap the system notification that appears on your phone, which will either redirect you to the download page or directly open the UGREEN NAS app.

1. Quickly complete device registration and login based on the current client’s connection and usage status.

## **Notes**

- When using the NFC feature, please ensure your phone has sufficient battery, as NFC functionality may consume more power.
- Keep the phone within a close range of the NAS device, typically within 2 centimeters.

## **Additional Notes**

- **Location of NFC on the Phone**:The NFC chip on most phones is located in the middle of the back of the phone, usually near the rear camera or fingerprint recognition module. You can identify the specific location of the NFC chip by looking for the NFC symbol on the back of the phone or by referring to the phone manufacturer's manual.
- **Differences in System Notifications Across Different Phones**:

| Scenario | Android System Response | iOS System Response |
| --- | --- | --- |
| UGREEN NAS app not installed | When close to the NFC tag, the response varies depending on the phone manufacturer: Directly opens the app store; Pops up a download option for the user to choose; A system notification appears, prompting the user to click and choose the download method, then redirects to the corresponding page. | Close to the NFC tag, a system notification appears first, and clicking the notification directly leads to the app download page, prompting the user to download the app. |
| UGREEN NAS app installed but not opened | When close to the NFC tag (specific behavior depends on the phone manufacturer): Directly opens the app and shows the NFC pop-up; First shows a system notification, and after clicking, it opens the app and displays the NFC pop-up. | Close to the NFC tag, a system notification appears first, clicking the notification redirects to the download page, prompting the user to open the app. Once clicked, it opens the app and displays the NFC pop-up. |
| UGREEN NAS app installed and opened | When close to the NFC tag (specific behavior depends on the phone manufacturer): Directly shows the NFC pop-up; First pops up a system notification, and after clicking, the NFC pop-up appears. | Close to the NFC tag, a system notification appears first, clicking the notification redirects to the download page, prompting the user to open the app. Once clicked, it opens the app and displays the NFC pop-up. |

- **Android Phone NFC Interaction Differences:**

| Phone Brand | UGREEN NAS App Installed | UGREEN NAS App Not Installed |
| --- | --- | --- |
| Huawei | Directly opens the app, no pop-up at the top | NFC recognition pop-up appears at the top |
| Samsung | Directly opens the app, no pop-up at the top | A bottom pop-up prompts the user to choose an installation method |
| vivo | Directly opens the app, no pop-up at the top | Directly opens the app's built-in app store for installation |
| Xiaomi | Directly opens the app, no pop-up at the top | Directly opens the app's built-in app store for installation |

Different phone brands have varying implementations and interaction logic for the NFC feature. The specific process may differ by brand. It is recommended to familiarize yourself with the NFC settings and usage methods on your phone to ensure a smooth experience.
