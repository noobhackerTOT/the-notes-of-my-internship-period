# Why is the transfer speed slow within the local area network (LAN), only a few MB/s?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjU5In0=

Slow or unstable transfer speeds within a local area network (LAN), typically only a few MB/s, can usually be caused by the following reasons:

## **Network devices not meeting gigabit standards**

To achieve fast and stable LAN transfers, all devices in the network path between the NAS and the client must support gigabit (or higher) speeds. This includes:

- **Router/Switch:** Ensure the router and switch support gigabit or higher speeds.
- **Computer Network Card:** The computer’s network card should support at least gigabit speeds.
- **NAS Network Card:** The NAS device’s network card should also meet the corresponding speed requirements.

## **Network Hardware Issues**

- **Router Performance Bottleneck:** If the router’s processing capability is insufficient, data handling can lag when multiple devices access the NAS simultaneously, causing reduced transfer speeds. For example, some low-end routers with limited CPU and memory resources cannot quickly forward large amounts of data.
- **Network Interface Faults:** Faulty network interfaces on the router, NAS, or other devices—such as loose connections or oxidation—can cause abnormal data transmission and lower transfer rates.

## **Insufficient Cable Specifications**

- The Ethernet cables connecting the NAS and client should be upgraded to Category 6 (CAT6) or higher to avoid bandwidth limitations caused by older Category 5 (CAT5) cables.
- Using poor-quality or aging cables can lead to signal attenuation and increased interference, affecting the stability and speed of data transfer. For instance, damaged wire cores or poor twisting in the cables can prevent them from reaching their expected performance.

## **Unstable Wireless Connection**

- When a computer or mobile device is connected via Wi-Fi, the transfer speed may fluctuate due to environmental factors. It is recommended to test the network using a wired connection to determine whether the issue lies with the wireless network.

## **NAS Device Factors**

- **Disk Performance Limitations:** If the NAS is using lower-performance hard drives, such as shingled magnetic recording (SMR) drives, the read/write speed may be relatively slow. Performance may degrade further when handling multiple concurrent data requests. Additionally, if the drive has bad sectors or other faults, read/write speeds can be significantly affected.
- **Low NAS Specifications:** A NAS with a low-performance processor or insufficient memory may struggle to handle large data transfer tasks, leading to issues like slow processing or limited data caching—both of which can bottleneck transfer speeds.

## **Impact of File Transfer Characteristics**

Transfer speed may vary when copying a large number of files, as file transfers are a sequential process. For example, if there are three files—A (10MB), B (100MB), and C (1000MB)—the copy speed may fluctuate based on file size:

- Copying file A might show a speed of 10MB/s.
- Copying file B might reach 100MB/s.
- Copying file C may sustain 100MB/s for a longer period.

## **Network Congestion**

- In high-traffic environments, network congestion can also lead to slower transfer speeds. You can try optimizing network usage—for example, by configuring QoS (Quality of Service) settings on the router to prioritize LAN device traffic.

## **Recommendations**

- Upgrade network hardware to ensure that all network devices support at least gigabit transfer speeds.
- Use high-quality Ethernet cables, preferably CAT6 or higher, to connect your devices.
- Prefer wired connections whenever possible, as they offer more stable and faster speeds than wireless.
- When transferring large files in bulk, consider splitting the task into smaller batches to reduce strain on the network.
