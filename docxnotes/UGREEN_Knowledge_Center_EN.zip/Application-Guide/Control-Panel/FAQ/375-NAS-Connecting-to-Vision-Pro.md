# NAS Connecting to Vision Pro

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzc1In0=

Vision Pro is a high-performance smart device that supports a variety of multimedia functions, including video playback, image browsing, and more. Using its built-in file manager with the SMB protocol, Vision Pro can easily access and play media files stored on your UGREEN NAS.

### **Steps for connecting to UGREEN NAS**

1. Before connecting to UGREEN NAS, make sure both Vision Pro and the NAS are on the same local network. Then, use the Files app on Vision Pro to establish the connection.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250620/20ce98fe-d800-4577-b70a-5fbe2729bb11.png)

1. Obtain the IP address of your UGREEN NAS. You can find it in the NAS management interface under [Control Panel] > [Network] > [Network Connection] or by checking the device list on your router.
2. Enable the SMB service on your UGREEN NAS. Go to [Control Panel] > [File Service] > [SMB] and enable “SMB Service.”

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250620/21153230-ef0c-4c8f-b51c-3e64bcabe1d7.gif)

1. Once in the Files app, click the [...] icon in the top left corner, then select the second option, “Connect to Server,” and tap Connect.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250620/605b0865-9c85-48e9-926c-e59828334c38.png)

1. Enter the IP address of your UGREEN NAS here, then input your username and password to connect.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250620/4c89da18-e0a5-47e0-b4b2-3ead09ac8c99.png)

1. Once the connection is successfully authenticated, you can access the files on your UGREEN NAS.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250620/719c17c2-33a8-49e8-af6a-1327d3996003.png)

1. Once connected, you can play videos from your UGREEN NAS directly on your Vision Pro.
