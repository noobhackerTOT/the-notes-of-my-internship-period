# How to Perform a Factory Reset？

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzI1In0=

If you need to restore your UGREEN NAS to its initial state, you can use either of the following two methods. A factory reset will clear all system settings and installed applications (such as Docker and virtual machines), but the data stored on the hard drives will not be deleted. To avoid unexpected issues, it is recommended to back up important data before proceeding.

## Method One: Restore via the RESET Button on the Device

![](https://file1-cn.ugnas.com/admin/article/2026-02-28/bbf35145ed964b23945109f921913860.webp)

1. Keep the device powered on and running. Using a SIM ejector tool or another sharp object, press and hold the RESET button on the back of the device for 5 seconds, and you will hear a short beep.

2. Keep pressing for about 8 seconds until you hear three consecutive beeps, then release the button.

The system will automatically reboot and perform the factory reset operation. When the network indicator light stays solid white, the reset is complete, and you can rebind and initialize the device.

## Method Two: Restore via Control Panel

1. Log in to the device using the administrator account, then go to "**Control Panel**">"**Update & Restore**">"**Restore & Reset**".

2. Click the "**Factory reset**" button to open the pop-up window;

3. In the pop-up, check "**I accept**", then click the "**Reset**" button;

![](https://file1-cn.ugnas.com/admin/article/2026-02-28/e4b19bef830a4a27bbed0cb83dc1663b.webp)

4. Enter the password and click "**Submit**" to verify your identity. After successful verification, the system will begin the restoration process.

![](https://file1-cn.ugnas.com/admin/article/2026-02-28/d12523446e634ba698cc2e7ec4ca9eb6.webp)

## Notes

● Factory reset will erase all system settings;

● Factory reset will remove installed applications (including Docker containers, virtual machines, etc.);

● Factory reset will not delete personal data and files stored on the hard drive.

● To avoid data loss, it is recommended to manually back up important data to another safe location (such as an external hard drive or another NAS device) before proceeding.
