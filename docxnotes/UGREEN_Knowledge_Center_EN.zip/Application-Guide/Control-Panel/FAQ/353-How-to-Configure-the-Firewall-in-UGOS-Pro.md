# How to Configure the Firewall in UGOS Pro?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzUzIn0=

## **Use Case**

You can configure firewall rules in UGOS Pro to allow or deny access to specific network ports from specific IP addresses, helping prevent unauthorized logins and control access. This article introduces how the firewall works, as well as basic information on managing firewall rules, along with configuration examples.

## **How It Works**

### **Firewall Working Principle**

The firewall operates using a rule table for each network interface. These rule tables contain specific rules that either allow or deny network traffic.

The firewall evaluates traffic based on the priority of the rules. Once a rule is matched, it is immediately enforced, and no further rules will be evaluated. If no rules are matched, the firewall will follow the default action configured for that interface.

### **Firewall Rules**

Firewall rules control whether network traffic is allowed or blocked through an interface based on the service (port number), source IP address (or range), and protocol. By rearranging the order of these rules, you can allow the connections you need and block the unwanted ones.

### **Order of Firewall Rules**

The order of firewall rules is very important. In UGOS Pro, each network interface has its own rule table, as well as a shared table called "All Interfaces" for general firewall rules. The rule priority is as follows:

1. Rules defined in the "All Interfaces" table.
2. Rules defined in the respective interface to which the connection belongs.
3. Default rules of the interfaces to which the connection belongs.

### **Default Action**

At the bottom of each interface’s rule list, you can select a default action to handle access requests that do not match any existing firewall rule. By default, this action is set to "Allow Access".

If you want to only allow the most necessary traffic and block everything else, you need to change the default action to "Deny Access" after configuring your firewall rules.

### **Defining Service Access Permissions**

Before configuring the firewall, make sure you clearly know which services and IP addresses you want to configure on UGOS Pro, so that only necessary IP addresses are allowed and unwanted IP access is blocked.

When configuring the firewall, it is important to understand who (which IP addresses) need access and which services (port numbers) should be open. You can then adjust the firewall rules accordingly.

## **Configuration Example**

As shown in the diagram, we demonstrate how to manage firewall rules by setting four rules based on IP address (individual hosts and subnet IPs), built-in services, and location.

Firewall rules are matched sequentially from top to bottom. Once a rule is matched, it is immediately enforced, and no further rules are evaluated. Therefore, it is recommended to place rules with a smaller scope (more specific) at the top.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/fcc6360e-5614-4913-a882-bb819ec9ecd0.png)

The table below provides configuration tips for the basic settings:

| Rule List | IP Address | Service (Port) Access |
| --- | --- | --- |
| 1 | Local Subnet (LAN 192.168.1.0/24) | Access to all services |
| 2 | Remote Office (1.2.3.4) | Access to all services |
| 3 | Internet (all IP addresses) | Allow SMB server |
| 4 | Specific Locations (Afghanistan, Albania, and 4 other countries) | Block all services |

**Start Configuring Firewall Rules. Please follow the steps below:**

1. Go to [Control Panel] > [Security] > [Firewall].
2. Under the [Select Firewall Configuration] section, click the [Add] > [+ New Rules] button.
3. Enter the Add Firewall Configuration wizard. For more information about setting firewall rules, please refer to the configuration examples in this article.

#### **Managing by IP Address**

In the following example, we will set up two firewall rules: one for the local network (LAN) and another for the remote office.

In the Source IP option, select Specific IP and click "Select". Then specify the IP address or IP range to which this firewall rule will apply.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/ef9a902d-11bd-413c-a3bb-419cdf6a452c.png)

| Rule List | Rule Name | Network Connection | Service/Port | Source IP | Permission |
| --- | --- | --- | --- | --- | --- |
| 1 | Allow All Services for LAN IPs | LAN | All | 192.168.1.0/24（LAN） | Allow |

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/b5786f12-d516-4bae-b87d-2d180d3cd8de.png)

| Rule List | Rule Name | Network Connection | Service/Port | Source IP | Permission |
| --- | --- | --- | --- | --- | --- |
| 2 | Allow Remote Office to Access All Services via External IP | LAN | All | 1.2.3.4 (Remote Office) | Allow |

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/925cd60d-73c3-4dc7-a7ab-55abc09fba44.png)

#### Managing by Built-in Services

In the following example, we set up a rule using built-in services to allow access to the SMB service.

In the Port section, select the port from the list of built-in services, then click "Select," and choose the built-in application to which you want to apply this firewall rule. In this example, we selected the SMB option.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/85925e03-04fd-44a8-aac1-1c3c98428baf.png)

| Rule List | Rule Name | Network Connection | Service/Port | Source IP | Permission |
| --- | --- | --- | --- | --- | --- |
| 3 | Allow SMB Access for All IPs | LAN | SMB（137-139,445） | All | Allow |

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/248444dd-58cc-4f03-8f9c-ac5652cb9d0b.png)

#### **Managing by Location**

In the following example, we set connection rules based on location.

In the Source IP section, select Location, then specify the locations to which this firewall rule will apply (multiple selections allowed).

In this example, we selected the system-reserved location options.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/eb1c0d85-1e54-493a-8420-d4ef725e8779.png)

| Rule List | Rule Name | Network Connection | Service/Port | Source IP | Permission |
| --- | --- | --- | --- | --- | --- |
| 4 | Deny IPs from Specific Location Range | LAN | All | Location | Deny |

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/a4edb0d8-a29b-4f79-a54b-d152a8b2abbb.png)

#### **Check Rule Priority**

1. Make sure the IP address of your host computer has the highest priority in the firewall rule table to avoid any unintended access being denied.
2. Verify the order of your rules. For example, if you do not want to block SMB access for IP addresses from a specific location, Rule 3 should be placed above Rule 4.

#### **Update Default Action**

After verifying the firewall rule table, you can change the default action from "Allow Access" to "Deny Access" to block any access requests that do not match existing firewall rules for the corresponding interface.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250619/625a0266-9b4e-4d69-9a47-c7a4de241cb1.png)

Please Note:

1. You must check "Enable" for the firewall rules on the Add Firewall Configuration page for the firewall configuration to be applied and take effect.
2. You can create up to 10 custom firewall configuration profiles.
3. On the firewall rules list page, you can adjust the order of rules by dragging and dropping; rules placed higher have higher priority.
4. Firewall rules are executed according to their priority order in the firewall rules list.
5. If multiple network ports are connected to the same subnet, firewall rules may not function properly.
6. If you use multiple LAN ports combined with link aggregation, the firewall will only apply the rules of the first network interface.
