# How to Set Up Link Aggregation on UGREEN NAS to Improve Transfer Speed？

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzI0In0=

Applicability Statement: This article applies to UGOS Pro firmware version 1.6.1.2846. The screenshots provided are for reference only; the actual interface may vary slightly depending on the system or application version. Some options and features may differ between versions—please refer to the actual interface or consult the latest help documentation.

UGOS Pro supports Link Aggregation, which allows multiple physical network ports to be combined into a single logical interface. This enables increased bandwidth and network redundancy, enhancing both transfer performance and connection reliability.

## **What is Link Aggregation?**

Link Aggregation is a technology that combines multiple physical network interfaces into one logical interface. Its main advantages include:

- **Increased Bandwidth**: Multiple network cables transmit data simultaneously, boosting overall throughput.
- **Fault Tolerance and Redundancy**: If one link fails, the remaining links automatically take over to ensure uninterrupted service.

## **Supported Link Aggregation Modes**

| Mode Name | Mode Type | Description | Switch Required |
| --- | --- | --- | --- |
| Adaptive Load Balancing | Bond6 | Automatically distributes traffic, balancing load while providing fault recovery | No |
| Active/Backup Mode | Bond1 | Only one interface is active at a time; others act as backups for redundancy | No |
| Round-Robin Mode | Bond0 | Sends data in rotation for basic load balancing; requires manual configuration | Yes |
| Balance XOR | Bond2 | Distributes traffic based on MAC address hash values, ensuring that communication between the same pair of devices consistently uses the same link. | Yes |
| Dynamic Link Aggregation (LACP) | Bond4 | Supports IEEE 802.3ad; automatically negotiates and intelligently aggregates links | Yes |

## **Preparation Before Configuration**

Before setting up Link Aggregation, please ensure the following conditions are met:

- Verify that your switch supports Link Aggregation, such as IEEE 802.3ad (LACP - Link Aggregation Control Protocol).
- Prepare a sufficient number of network cables to connect the NAS to the switch.

Before enabling Link Aggregation, it is crucial to confirm whether your switch supports this feature and to understand the supported modes and configuration methods. Support and setup procedures for Link Aggregation may vary depending on the brand and model of the switch. Therefore, we recommend referring to the switch’s official documentation or contacting the manufacturer's technical support for accurate guidance.

## **Steps to Configure Link Aggregation**

1. Open the "Control Panel" app and go to [Network] > [Network Connection].
2. Click the [+ Link Aggregation] button to launch the setup wizard, then click “Start”.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250710/21f12bd0-319b-49b8-9747-d5081aab8b0c.png)

1. Select a Link Aggregation mode, such as Adaptive Load Balancing - Bond6. After selecting the mode, click “Next”.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250710/2d879c0f-31ba-43dd-af22-abf2909ee71b.png)

1. Select the LAN interfaces to be aggregated by checking the corresponding boxes, then click “Next”.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250710/6be5ee00-21b7-4453-a0b8-3e0cb64b448e.png)

1. Configure the IP address (you can choose to obtain it automatically or set it manually), then click “Apply” to complete the setup.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250710/b8fc27d1-d619-40fa-bf05-95edf1ea85ec.png)

1. Once completed, the newly created Bond virtual interface will appear in the network connections list. You can edit or remove the bonded interfaces at any time from this page.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250710/092a3186-606e-40a5-9ab0-8dfeebe39b1a.png)

## **Notes**

- A brief network interruption may occur during the creation or deletion of a link aggregation group; this is normal.
- After enabling link aggregation, existing network rules (such as firewall settings or traffic control) on the original interfaces will be cleared and need to be reconfigured.
- The selected LAN interfaces must be within the same subnet; otherwise, communication may fail.
- After enabling aggregation, do not bind the NAS IP/MAC address in your router, as this may result in connection failure.
- If you plan to change the router or subnet, please switch the network settings back to DHCP (automatic) beforehand.
- If configuration errors occur or the device becomes inaccessible, you can restore the network to DHCP by using[How to Perform a Factory Reset？](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJpZCI6OTg4LCJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVJbmZvSWQiOjMyNSwiYXJ0aWNsZVZlcnNpb24iOiIxLjAifQ%3D%3D)

## **Frequently Asked Questions**

1. **Unable to access NAS after enabling link aggregation?**

Check whether the switch configuration matches the NAS aggregation mode and ensure the subnet settings are correct.

1. **Connection becomes unstable after enabling?**

Make sure the selected physical interfaces are connected to the same switch that supports aggregation and are on the same LAN.

1. **No noticeable improvement in bandwidth?**

Aggregated bandwidth is limited by the client device and protocol distribution mechanisms. Not all individual tasks can utilize full speed simultaneously.
