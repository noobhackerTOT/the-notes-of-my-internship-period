# How to Connect to UGOS Pro via SSH with Root Privileges?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDgxIn0=

This guide will walk you through how to log in to the UGOS Pro system on your UGREEN NAS via SSH using root privileges. Enabling the SSH service may introduce security risks, so it is recommended to enable it only when necessary and to avoid making unnecessary changes to system configurations.

**Note:** Once SSH is enabled, make sure that only administrators use root privileges for SSH login to prevent unauthorized access. It is strongly advised to disable SSH when it's not needed.

## Enable SSH Service

1. Log in to the UGOS Pro system and go to [Control Panel] > [Terminal].

2. Check the option **Enable SSH Service**.

3. Specify the SSH port number (default is 22) and click “Apply” to activate the settings. You can also customize the port and configure additional advanced settings.

**Note:** **To enhance SSH connection security, it's recommended to change the default port number and avoid exposing it directly to the public network, reducing the risk of attacks.**

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/d483bf6d553b4161bbc92b505bb6aa88.webp)

## Connect to UGOS Pro from Windows 10 or macOS

### Connect to UGOS Pro via SSH on Windows

1. Ensure the NAS and your Windows PC are on the same local network.

2. Launch the terminal application on Windows: Press`win+R`to open the Run dialog. Type`PowerShell`and click OK to open the Windows PowerShell interface.

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/dd3d90700a264cf7ba4c1ac9f7ba5a30.webp)

3. Enter the following command, replacing username with your administrator account, NAS_IP with your NAS IP address, and port with your SSH port number. Then press Enter.You can find your UGREEN NAS IP address by navigating to [Control Panel] > [Network] > [Network Connection] (e.g., LAN1, LAN2).

```
ssh username@NAS_IP -p port
For example
ssh ugreen@192.168.22.153 -p 22
```

4. Enter the password for your UGOS Pro administrator account and press Enter to complete the login verification.

5. After successfully logging in, enter the command`sudo -i`and press Enter to obtain root privileges:

6. The system will prompt you to enter the administrator password again. After pressing Enter, you will be logged in to the UGOS Pro system with root privileges.

![](https://file-cn-test.ugnas.com/admin/article/2025-08-29/7e334710b32f4731a27dc5ad7915f9d7.webp)

### Connect to UGOS Pro via SSH on macOS

1. Make sure the NAS and your macOS device are on the same local network.

2. Open the **Terminal** application (located in "Applications" > "Utilities").

3. In the terminal, enter the following command and press Enter. Replace`username`with your administrator account,`NAS_IP`with your NAS IP address, and`port`with your SSH port number:

```
ssh username@NAS_IP -p port
For example
ssh ugreen@192.168.31.34 -p 22
```

4. Enter the administrator account password and press Enter to complete the login.

5. After logging in, enter the command`sudo -i`and press Enter to gain root privileges.

6. Enter the administrator password again and press Enter. Once done, you will be logged in to the UGOS Pro system with root privileges.

## Notes

Performing SSH operations may affect your system. To ensure the security and stability of your system, please refer to the following important tips:

1. SSH operations involve modifications to the system’s underlying layers and may impact system stability and security. Please make sure you fully understand the commands you execute.

2. Technical support cannot provide solutions for any issues caused by individual SSH operations.

3. Always back up important data before performing any SSH operations to prevent accidental data loss.

4. If abnormal issues occur due to SSH operations (such as system crashes or device failures) that require factory reflashing or repairs, any related costs will be your responsibility.

5. If you encounter problems after SSH operations, you may try the following steps:

● Restart the system: Sometimes a reboot can resolve temporary issues.

● Restore from backup: If available, try restoring to a previous state (such as service configuration files, system settings, or related data files).

● Factory reset: If issues persist but you can still access the system, try performing a factory reset. This will restore the device to its default factory state, clearing user accounts, system configurations, and installed applications, while retaining data on the hard drives.
