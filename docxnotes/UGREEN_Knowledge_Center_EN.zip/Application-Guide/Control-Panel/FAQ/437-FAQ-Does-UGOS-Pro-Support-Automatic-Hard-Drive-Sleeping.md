# [FAQ] Does UGOS Pro Support Automatic Hard Drive Sleeping?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDM3In0=

UGOS Pro system supports hard drives automatically entering sleep mode when idle, including all system hard drives and externally connected USB hard drives that support sleeping. This feature is enabled by default, and you can adjust settings according to your personal needs.

## To Set up Automatic Hard Drive Sleeping:

1. Log in to the UGREEN Cloud web interface with an administrator account.

2. Go to **[Control Panel] > [Hardware & Power] > [Power]**.

3. Find the **Hard drive sleep**option where you can set the idle time before the hard drive and USB hard drive enter sleeping. Choose an appropriate time interval based on your usage needs. (Note: Only USB hard drives that support sleeping can be set for automatic sleeping)

4. You can also check the box to record hard drive sleeping logs for future review of sleeping status.

![](https://file1-cn.ugnas.com/admin/article/2025-09-02/f280271158ed4cba94f82701a188b03f.webp)

## Possible reasons why a hard drive may not sleep:

1. There are file transfer tasks on the volume where the hard drive is located, which prevents the hard drive from entering sleeping, whether uploading or downloading.

2. Tasks managers on PC, web, or TV ends may have processes reading or writing to the hard drive. If other users on the device access the device through a web interface, mobile app, or TV end, the hard drive will not enter sleeping.

3. If certain applications or Docker containers are installed on the volume where the hard drive is located and are running or generating data transfers, the hard drive will not enter sleeping.

4. If there are download tasks or shared torrent files in the Downloads, XUNLEI, or Docker containers, the hard drive will remain active and not enter sleeping.

5. M.2 hard drives do not support sleeping.

6. If an M.2 drive is used for read/write caching, the system periodically writes data back to the volume, preventing mechanical hard drives from hibernating.

7. WebDAV mounts use volume as cache.

8. volume has been configured with RAID 1, 5, 6, or 10 arrays. To ensure RAID data integrity and consistency, there will be light I/O read/write operations during idle times.

9. Samba, FTP, and WebDAV have mounted volumes and files are read/written using Samba, FTP, and WebDAV at irregular intervals.

10. External volumes are not supported for sleeping by the system.
