# [FAQ] Why is the transfer speed of NAS within the local area network so slow, dropping to just a few MB/s?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDUxIn0=

## **Problem Description**

Within a local area network (LAN), NAS transmission speeds may be slow and unstable, potentially affected by the following factors:

1. **Substandard Network Equipment Performance**:
  If any network device in the local area network (LAN), such as routers, switches, Ethernet cables, computer network interface cards (NICs), and NAS NICs, supports only a hundred-megabit (100Mbps) speedonone link, themaximum theoretical transfer rate can only reach 12.5MB/s (100Mbps ÷ 8 = 12.5MB/s), rather than the common 100MB/s seen in gigabit networks. Therefore, it is necessary to ensure that all devices in the entire link support gigabit (1000Mbps) networks.
2. **Unstable WiFi Connections**:

WiFi connections are **half-duplex**, meaning they can only transmit data in one direction at a time. When multiple devices use WiFi simultaneously, they must take turns transmitting data, resulting in shared bandwidth allocation and affecting overall network speed. Additionally, WiFi performance is susceptible to various environmental factors, such as signal strength, distance between devices and routers, and obstructions (like walls and appliances). These factors contribute to unstable WiFi connections and significant fluctuations in network transmission rates. Therefore, when transferring large files, it is recommended to prioritize wired networks for stability and speed. For example, if your WiFi connection rate is 866 Mbps, due to its half-duplex nature, upload and download speeds cannot reach full capacity simultaneously. If bandwidth is equally divided between uploads and downloads, the actual peak upload speed is 866 / 2 / 8 = **54 MB/s**. However, this is a theoretical value, and actual transmission rates may be affected by other factors such as protocol overhead, interference, and network congestion.

1. **Impact of File Transfer Quantity and Size**:
  The number and size of files being transferred significantly affect speed. Transferring a large number of small files at once can result in slower speeds due to file queuing during copying. For instance, in a Gigabit LAN, transferring small files may result in speeds as low as a few MB/s, while transferring large files can significantly increase speeds. Using three files of different sizes as examples:- File A (10 MB): Transfer rate may momentarily reach 10 MB/s.
  - File B (100 MB): Transfer rate may increase to 100 MB/s.
  - File C (1000 MB): Speed may stabilize around 100 MB/s.

Such speed fluctuations are normal, especially when transferring files of varying sizes.

## **Solutions**

1. **Ensure Gigabit or Higher Network Support Across the Entire Network Link:**
  Upgrade routers, switches, Ethernet cables, computer network adapters, and NAS network adapters to the same network conditions, such as full Gigabit, full 2.5G, or full 10G networks, to ensure maximum LAN transmission bandwidth exceeding 1000 Mbps (i.e., theoretically 125 MB/s).
2. **Use Wired Connections for Transfers**:
  Prioritize wired network transfers to avoid unstable speeds in WiFi environments. Wired connections significantly improve speed and stability, especially when transferring large files.
3. **Optimize File Transfer Strategies**:
  Avoid transferring too many small files at once. Consider packaging multiple small files into a single large file (e.g., compressing into a zip file) before transfer to reduce the impact of queuing during copying.
4. **Upgrade Storage Hardware**:
  If transmission speeds remain unsatisfactory, consider upgrading the NAS storage devices (e.g., replacing with SSDs or using RAID 0/1) to enhance data read/write performance and overall transmission speed.

#### If the problem persists, please contact UGREEN official technical support for assistance.
