# Reset Network & Password

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjk0In0=

**To reset the network settings and password, please follow these steps:**

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250709/25d18cf0-6376-4535-b7d4-3303fe480c0c.png)

1.While the device is powered on, use a pin to press and hold the "RESET" button on the device for 5 seconds. Release the button after you hear a short beep.

2.The device will not restart during the reset process. Once the reset is complete, the network indicator light will remain solid white, indicating that the device is ready for use.

**Note:** This reset operation will not affect any data stored on your hard disk. After a successful reset, you can log in using the “admin” account with a blank password (this account is only for password reset purposes). After logging in, follow the setup wizard to create a new administrator password.
