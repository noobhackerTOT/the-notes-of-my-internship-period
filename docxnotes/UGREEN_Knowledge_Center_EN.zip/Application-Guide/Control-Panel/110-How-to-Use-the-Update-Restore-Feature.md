# How to Use the Update & Restore Feature

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTEwIn0=

## Overview

During routine system maintenance or device migration, you can use the "**Update & Restore**" feature in the Control Panel to perform firmware upgrades, network resets, factory resets, and cloud/local backups of system configurations.

**Access Path**: Log in to the NAS desktop, open "**Control Panel**" app, and click "**Update & Restore**".

## System Update

On this page, you can check the current system version, upgrade to the latest firmware, and customize update strategies.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/b0e65731e411470eb9295fe9d344e9d2.webp)

### Manual Firmware Installation

If you need to install a specific or beta firmware version:

1. Go to the [UGREEN NAS Official Download Center](https://nas.ugreen.com/pages/downloads), find your device model, and download the corresponding firmware file (`.img`).

2. Return to the**"Update**" page on your NAS and click "**Manual installation**".

3. In the pop-up window, click "**Browse**", select the downloaded file (`.img`), and click "**Confirm**" to start installation.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/c1c076567c5a427fbe07b6c884a10656.webp)

### Update Settings & Policies

Click "**More settings**">"**Update settings**" to configure the following:

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/ab34d3fa9bd74ebb804e64a763af44b0.webp)

**System Update Strategy:**

● **Download important updates automatically (recommended)**: Only installs critical security and feature patches.

● **Download the latest updates automatically**: Keeps the system on the newest firmware version at all times.

● **Notify me and let me decide whether to install it**: Suitable if you prefer manual control over installation and system restarts.

**Check for Updates**: Enable "**Custom inspection interval**" to define how often the system checks for new versions (e.g., every 22 hours).

### Import Root Public Key

This feature is intended for users who need to manually install firmware from specific sources:

1. Click "**More settings**">"**Import root public key**".

2. In the pop-up window, click "**Browse**", select the corresponding root public key file (`.pub` ), and confirm to import.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/496573e2a3a949e1918c030eee00c140.webp)

### Reset Network Settings

If the device encounters severe network issues and becomes unreachable, you can restore the network configuration to its default state using the reset feature. Two methods are available:

### Method A: Reset via App (when the device is accessible)

On the "**Restore & Reset**" tab, click "**Reset network**". In the confirmation window, check "**I accept**" and click "**Reset**".

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/d86c042bd6a94d20b828f16cd9e1026b.webp)

### Method B: Reset via Physical Button (when login is not possible)

If you cannot access the NAS through the network, use the physical `Reset` button on the device:

1. Locate the `Reset` pinhole on the back of the NAS device.

2. Use a pin or similar tool to press and hold the button for **5 seconds**.

3. Release the button after hearing a "**beep**". The network reset will be completed.

**Temporary Login Account (admin) After Reset:**

● After resetting the network, the system will automatically enable a temporary account named `admin` with **no password** (used only for emergency administrator password reset).

● Once you successfully reset an administrator password using `admin` account, or log in with any valid administrator account, the temporary account will be immediately disabled to ensure device security.

### Factory Reset

This operation fully initializes the system configuration of the UGREEN NAS, restoring all settings to factory defaults.

**Steps**: On the "**Restore & Reset**" tab, click "**Factory reset**", check "**I accept**" in the pop-up window, and click the red "**Reset**" button.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/c2c3efd373e9409a9dbaefb435e9b9d7.webp)

**Notes:**

● A factory reset only clears system-level configurations (including network settings, user accounts, and system preferences). Files stored on the hard drives will not be deleted.

● This operation only resets the local device. If you need to completely unlink the device from your UGREEN Account (e.g., before transferring ownership), make sure to unbind it on the [UGREEN Account Website](https://web.ugnas.com/#/login).

## Configuration Backup & Restore

To prevent accidental loss of system settings or quickly restore your environment on a new device, it is recommended to back up system configurations regularly.

### Back Up System Configuration

You can choose to back up configurations to the cloud or download them locally:

**Cloud Backup (Automatic/Manual):**

1. Click "**Cloud backup**", check "**Scheduled backup of system configuration to UGREEN Account**". A login window will appear—complete verification as prompted.

2. After verification, the feature will be enabled. If system configurations change within 24 hours, they will be automatically backed up to your cloud account.

3. To create an immediate backup, click "**Back up**". Click "**Save**" after completion.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/61c288f1d9c6456c8e989dd3188a3911.webp)

**Local Backup**:

Click "**Local backup**". The system will package the current configuration into a `.ugb` file and download it to your computer.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/c480fa4bc8af45d8b7f2e26ee8d42ffb.webp)

### Restore System Configuration

Click "**Restore configuration**" and choose a method based on your backup type:

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/f572b523a07d4ccb8867361afecedaf7.webp)

**Method A: Restore from UGREEN Account**

1. Select "**Restore from UGREEN Account**" and click "**Next**". Log in and verify your account.

2. In the cloud list, select the configuration items you want to restore and click "**Confirm**".

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/0cbe33da92ab466f907ac97e7ea0e2d7.webp)

3. Check "**I accept**" and click"**Restore**". Wait for the process to complete.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/6306b79f52194fcd8454ebe4f32a08a2.webp)

**Method B: Restore from Local File**

1. Select "**Restore from the local configuration file on computer**", click "**Browse**", and upload the `.ugb` file. Wait for validation.

2. After validation, click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/46f988d59f30469881b4a38eb3636663.webp)

3. Select the configuration items to restore and click "**Confirm**".

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/66403830443b44619d58b25ad3604e31.webp)

4. Check "**I accept**" and click**"Restore**". Wait for completion.

![](https://file1-cn.ugnas.com/admin/article/2026-04-24/9e1a086661ca402fb13197ecfde6aec1.webp)

**Note**: Once the restoration is complete, the system environment will change. All current sessions will be logged out automatically. You will need to log in again using the restored account credentials.
