# How to Create User Accounts and Assign Permissions

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODUyIn0=

# Applicability

**Supported Platforms**: UGREEN NAS PC Client, Web Browser

**Supported Version**: UGOS Pro firmware 1.15.0.0114 and later

This document is for reference only. Actual interface and operation paths may vary slightly depending on system or application version. Please refer to the interface displayed on your device.

## Overview

If you want to share your UGREEN NAS device with family or team members, you can create dedicated user accounts via the Control Panel. New users can log in using these accounts on the UGREEN NAS client and access NAS resources based on the permissions you assign.

## Creating a New User Account

1. Open the Control Panel app and click "**User Management**" in the left sidebar. Ensure the page is on the "**User**" tab at the top.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/a77fb523de5d4d67ba023ba29ba176df.webp)

2. Click the "**Add**" button at the top of the page to open the dropdown menu. The system provides three creation methods:

● Create: Manually enter username, password, and other information—suitable for creating new local users.

● Invite: Register via invitation link or QR code.

● Import: Bulk import user accounts—useful if you already have a list of users.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/e1bcc2be41e0432187c55844c8b942dd.webp)

3. Using "**Create**" as an example, click "**Create**" to enter the information configuration page.

4. Set the user's username and password, and select the **role** (Administrator or Standard User).

Administrators have the highest level of system management privileges—assign with caution.

5. Check "**Enable 'Personal Folder'**" to automatically create a dedicated personal folder for this user in the Files app.

6. After filling in the basic information, click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/370c7e076880401fa3ae4958ff17b586.webp)

## Assigning Shared Folder Permissions

In the second step of the creation process, you need to assign access permissions to existing shared folders for the new account. The system provides three levels of permission:

● **Access Denied:** The user cannot see or access this folder.

● **Read Only:** The user can view and download files but cannot modify, rename, or upload new files.

● **Read/Write:** The user has full permissions to view, modify, upload, and delete files.

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/8579da6d0a334efcab38d0b0132b6237.webp)

**Default Permission Rules:**

● **Standard Users**: If no permissions are selected, default is"**Access denied**" for all shared folders.

● **Administrators**: If no permissions are selected, default is "**Read/Write**" for all shared folders.

After selecting the target shared folders and assigning the corresponding permissions, click "**Done**". The new account will appear in the user list. A "**Normal**" status indicates the account is active and ready for login.

## Using User Groups for Bulk Permission Assignment

If your NAS has many shared folders and you need to create multiple users, configuring permissions individually can be inefficient. It is recommended to create a "**User Group**" with standardized permissions and then add users to the group.

1. In the User Management page, switch to the "**User Group**" tab and click "**Add**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/62ea81bf509e441b97fc58795e8f0f18.webp)

2. Enter a name for the user group in the popup page and click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/70dfbdcc5210448cb1ebb9863c892795.webp)

3. On the "**Select member**" page, check the users you want to add to this group. If users are not yet created, you can leave this blank for now. Click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/3962b3c765c54db9a7756ddae630300a.webp)

4. Assign shared folder permissions for the group. Once configuration is complete, click "**Done**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/93e554f2e87448878d39c5f34b429b10.webp)

### Adding New Members Later

If new members need to be added to an existing user group, double-click the target group name in the "**User Group**" tab to enter edit mode. Switch to the "**Select member**" page, check the new members, and click "**Save**".

### Verifying Permission Activation

After saving, return to the "**User**" tab. Double-click the user who was just added to the group and switch to the "**Permissions & Settings**" page to confirm that the user has successfully inherited the shared folder permissions from the group.

## Permission Conflicts and Priority Rules

If different permissions are set for the same shared folder at both the "**User Group**" and "**User**" levels, the system resolves conflicts according to the following priority:

● **Highest>Lowest**

● **Access Denied>Read Only>Read/Write>Empty (not set)**

![](https://file1-cn.ugnas.com/admin/article/2026-05-11/7f8899824aa040fbab6e1f98b9d9b337.webp)
