# Security

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjI1In0=

**Applicable Version:** UGOS Pro 1.10.0.0092 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## General

In the general settings on the [Security] page, you can manage the system's login behavior and network security policies in a centralized manner.

![](https://file1-cn.ugnas.com/admin/article/2025-10-21/b275c734a48347d0b337a8a1f36e53a5.webp)

### Without maintaining login, app will automatically log out after XX minutes of inactivity

Here you can set the time after which the NAS system will automatically log out a browser session if there is no activity. Once the system detects that the specified duration has been reached, the current logged-in user will be automatically logged out.

**Note:**

● The unit is in minutes and can be adjusted according to actual needs.

● After setting, if the user does not perform any operation (e.g., clicking, typing, etc.) within the specified time, the system will automatically log out.

### Clear login sessions when the system restarts

When enabled, all user login sessions will be cleared after the system restarts. Users must log in again to access the system, effectively preventing security risks from old sessions.

**Note:**

● After enabling, all users (including administrators) must log in again.

● If the "Stay logged in" option was selected when logging in from a TV, this setting will not affect the TV session; it will remain logged in.

### Enable DoS protection

When enabled, the system can defend against network attacks over TCP, ICMP, UDP, and other protocols, improving NAS security and stability. It is recommended to keep this feature enabled.

### Automatic Blocking of Failed Login IPs

The system can automatically block IP addresses that fail to log in multiple times within a specified period, helping prevent brute-force attacks and malicious login attempts.

When enabled, if the same IP fails to log in consecutively for a specified number of times (e.g., 5 times) within a set time frame (e.g., 5 minutes), the system will automatically block that IP.

### Block Management

Click **"Block Management"** to view and manage all blocked IP addresses.

● Add Blocked IP: Click **"New"** in the blocked IP list to manually add an IP address to block. You can also set the block duration.

![](https://file1-cn.ugnas.com/admin/article/2025-10-21/3d60feb8e5a4447faf86d8299e3252f6.webp)

● Automatic Unblock Settings: In the settings, you can specify the number of days after which a blocked IP will be automatically unblocked.

![](https://file1-cn.ugnas.com/admin/article/2025-10-21/acf8a61f68604f1bb20d85943946da41.webp)

● Whitelist Settings: In the settings, click **"New whitelist"** to add IP addresses or subnets that are exempt from block rules.

Supported entries include a single host (e.g., 192.168.1.10), a subnet (e.g., 192.168.1.0/24), or an IP range (e.g., 192.168.1.10 to 192.168.1.249). Whitelisted IPs are not affected by block rules.

![](https://file1-cn.ugnas.com/admin/article/2025-10-21/ac0bb33ffc7e4efaa8ec39c35b6304f4.webp)

## Advanced

In the advanced settings on the [Security] page, you can further enhance the system's network access security.

● **Improve protection against cross-site request forgery attacks (CSRF):** Prevent malicious websites from performing unauthorized operations on the NAS.

● **Improve security with HTTP Content Security Policy (CSP) header:** Enhance web access security by restricting the sources from which web resources can be loaded.

● **Enable TLS security protocol:** Strengthen encryption for data transmission, improving connection security.

**Note:** The first two settings are only visible when accessing the NAS via a web browser and will not appear in the UGREEN Cloud client.

![](https://file1-cn.ugnas.com/admin/article/2025-10-21/f4ab4bb4f7914e72a3c36cae0ae0a3eb.webp)

## Terminology

To help you better understand network and security-related settings, the following are brief explanations of common terms:

1. **Subnet IP address**

A subnet IP address identifies the network segment to which devices on the same local area network (LAN) belong.
When configuring access control or setting an IP whitelist, you can use the subnet IP address to allow or restrict devices within a specific network range from accessing the NAS.

2. **Network prefix length**

The network prefix length indicates the number of bits in an IP address that represent the "network portion," usually expressed in the form "/number", e.g., `192.168.1.0/24`
Here, "/24" means the first 24 bits are the network address, and the remaining 8 bits are for host addresses. A larger prefix length indicates a smaller network range and fewer assignable hosts.

3. **TLS (Transport Layer Security)**

TLS is a security protocol used to encrypt network communications, ensuring that data cannot be intercepted, forged, or tampered with during transmission.

Enabling TLS in the system improves the security of web access and remote connections.
