# Control Panel

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjMifQ==

The “**Control Panel”** is a comprehensive and user-friendly management tool designed for administrator users to efficiently manage and configure the system. With a clear interface and a wide range of options, it meets various management needs, making operations more efficient.

## **Connections & Access**

- [User Management](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6NDksInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksMTgzbDkxIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Add, edit, and delete users, configure user permissions and access controls flexibly to ensure system security and ease of use.
- [File Service](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6NjMsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksbmFmaHYwIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Provides comprehensive file-sharing management, supporting multiple protocols, including SMB, NFS, FTP, WebDAV, and Rsync, to meet various file transfer needs.
- [Device Connection](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6NzAsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksZmFsM3ZsIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Easily configure local network and remote access methods (including UGREENlink and DDNS), as well as web access restrictions for efficient device connectivity and management.
- [Domain & LDAP](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6NzEsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmkscTlnZWR3IiwibGFuZ3VhZ2UiOiJlbi1VUyIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Manage domain or LDAP user access permissions to system files, ensuring secure enterprise-level access.
- [Terminal](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6NzMsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksZDl4M203IiwibGFuZ3VhZ2UiOiJlbi1VUyIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Provides Telnet/SSH access, available only for administrator accounts, enabling advanced system operations and maintenance.

## **General Settings**

- [Hardware and Power](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6ODMsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksZjhmNjR4IiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Customize hardware settings such as buzzer, cooling fan, and LED indicators. Supports power management features like scheduled power on/off and hard drive hibernation to optimize system performance.
- [Time and Language](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6ODQsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmkscWhudWt6IiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Easily configure system time and language settings to meet localization needs.
- [Network Settings](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6ODUsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksOTc4YnBxIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Configure network interfaces, default gateway, and DNS servers. Supports multiple gateways and bridge mode for flexible network management.
- [Indexing Service](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6ODgsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksN3dmYjM5IiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Automatically creates indexes for files and folders, significantly improving search efficiency and enabling quick content retrieval.
- [Security](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6ODYsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksaHp3YmxwIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Enables firewall settings, manages IP blocking and whitelists, and configures certificates to enhance system security.

## **System Services**

- [About](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6OTAsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksZnl6c3E5IiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): View system information and hardware status, including storage space and hard drive health, to monitor device performance.
- [Update & Restore](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6OTEsInR5cGUiOiJ0YWcwMDEiLCJwYXRoQ29kZSI6InBybzAwMSx1cmNhYmksZ2liaHUzIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=): Check system version details, perform updates, and restore the system to keep it up to date while ensuring quick recovery options.

**Notes**

- "Control Panel" access is restricted to administrator users; regular users cannot view it.
- The search bar at the top of the Control Panel allows you to quickly find configuration options.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250514/0f64b2db-c24a-4b7b-a471-032791bc5f90.png)

### **Follow the tips**

The control panel features available on UGREEN NAS devices may vary across different product series. Please check your device model and its supported features before proceeding to ensure an optimal user experience.

#### **[DH Plus Series]**

- The control panel functions are limited, with the following restrictions:1. The “Power Management” feature is not supported in the “Hardware & Power” module；
  2. LED indicators are not configurable；
  3. Network settings are limited — link aggregation is only supported via a USB **network interface card**.

### **Usage Recommendations**

- If you need features such as power management, multiple network interface card aggregation, or customizable LED indicators, it is recommended to choose a NAS from the DXP Series；
- When using DH / DH Plus Series devices, network link aggregation requires a supported USB network interface card accessory — it is recommended to confirm compatibility in advance
