# File Service

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzcifQ==

The "**File Service**" module in the "**Control Panel**" is one of the core features for data sharing and management. It supports multiple protocols, including SMB, FTP, NFS, rsync, and WebDAV. Below is an overview of the File Service feature:

![](https://file1-cn.ugnas.com/admin/article/2025-12-23/eb27bdfef49642b989cb529bfbaf74a6.webp)

## File Services Overview

● [**SMB**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmNzgifQ==): Allows users to mount shared folders on the NAS to local computers within a local network, enabling centralized file storage and unified management. Supports SMB1, SMB2, SMB2.1, and SMB3, ensuring secure and stable file transfers.

● [**FTP**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmNzkifQ==):Provides a simple and convenient method for file transfer, with support for FTPS encrypted connections. It is well suited for scenarios such as automatically backing up camera photos and other data to the NAS.

● [**NFS**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODAifQ==): Primarily used in Unix/Linux environments, enabling file sharing between different machines. It is ideal for using the NAS as a network storage device accessed by other systems.

● [**rsync**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODEifQ==):Supports efficient data synchronization and backups, making it suitable for users who require regular and incremental data backups.

● [**WebDAV**](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODIifQ==): Allows users to manage files directly over the internet. It is commonly used for integration with Web-based applications (such as Alist), enabling file access and management through file managers connected to these services.

## How to Use the File Service Module

● **Enable and Configure Services**: Log in to the UGOS Pro system, open the "**Control Panel**", click "**File Service**", enable the required services (such as SMB, WebDAV, or FTP), and configure their settings as needed.

● **Mount Shared Folders**: On Windows, you can mount NAS shared folders as local drives using "**Map Network Drive**". On macOS, you can mount them using the" **Connect to Server**" feature.

● **Permission Management**: Configure user and group permissions in "**User Management**" to control access to shared folders, ensuring proper data security and access control.

## Advanced Settings

![](https://file1-cn.ugnas.com/admin/article/2025-12-23/23c6761a2698437cad2077c174121e32.webp)

### Enable the wsdd2 Service

After enabling this service, your device can be discovered and accessed by Windows Network Neighborhood via wsdd2, improving its visibility and accessibility within Windows networks.

**Q: Where can I use or see the device after enabling the wsdd2 service?**

**A:** Once wsdd2 is enabled, you can find and access the device in the following locations:

1. **Windows File Explorer**: On a Windows system, open "**File Explorer**" and navigate to the "**Network**" section. Devices with wsdd2 enabled will appear in the list of network devices, allowing you to directly access their shared folders and resources.

2. **Network Neighborhood**: The device will also be visible in Windows "**Network Neighborhood**", where it automatically appears in the network device list.

3. **Other WS-Discovery–enabled applications**: Some third-party applications or tools that support the WS-Discovery protocol can also detect and display devices with the wsdd2 service enabled.

### Enable Bonjour Service

After enabling the Bonjour service, Mac devices on the same local network can discover your UGREEN NAS and use Time Machine for backups. For instructions on how to enable and use Time Machine for backups, please refer to [Back Up Mac Files to a UGREEN NAS Using Time Machine.](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmMzUwIn0=)

**Q: Where can I access or see the service after enabling Bonjour?**

A: Once the Bonjour service is enabled, you can find the related devices and services in the following places:

1. **macOS and iOS devices:** On macOS and iOS, Bonjour automatically discovers and displays shared devices and services on the network. For example, you can see Bonjour-enabled devices under "**Network**" in "**Finder**".

2. **Windows devices:** If Bonjour is installed on a Windows device (typically via iTunes or the Bonjour Print Services), Bonjour-enabled devices and services will appear in the "**Network**" section.

3. **Media players and smart home devices:** Some media players (such as Apple TV) and smart home devices (such as HomePod) also use Bonjour for device discovery and connectivity.

### Enable UPnP Discovery Service

After enabling this service, other UPnP devices on the local network can discover and connect to your UGREEN NAS. This is especially useful for devices and applications that rely on the UPnP protocol, improving interoperability between devices.

**Q: Where can I access or see the service after enabling UPnP discovery?**

A: Once UPnP discovery is enabled, you can find the related devices in the following places:

1. **Network Neighborhood:** On Windows, open "**Network**" or "**Network Neighborhood**" to view the list of UPnP-enabled devices.

2. **Media players:** In UPnP-compatible media players (such as Windows Media Player or VLC), you can browse and play media content from UPnP devices.

3. **Router management interface:** Some routers display connected UPnP devices in their management interface, where you can view them in the device list or UPnP settings page.
