# NFS

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODAifQ==

The NFS protocol is one of the core functions of UGREEN NAS for file sharing and is widely used in Unix/Linux environments. It features easy configuration, high performance, security, compatibility, and flexibility, meeting the needs of various users. With proper configuration and use of NFS services, users can enhance file transfer and management efficiency, ensuring data security and reliability.

## **Applicable Scenarios**

NFS services are widely used in both home and business environments. A common use case is storing video files such as movies and TV shows on UGREEN NAS and sharing them with devices like smart TVs or projectors via the NFS protocol. Family members can easily access and stream these files using NFS-compatible clients or devices, enjoying a convenient multimedia experience.

## **Enable NFS Service**

1. Open the"Control Panel"application, then click on [File Service] > [NFS].
2. Check “Enable NFS Service”, then click “Apply” to save and apply the changes.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/c10e5cec-f799-46de-b3ce-b62f9fc835de.png)

1. After enabling, open the “Files” application, select the folder to be shared, right-click, and select “Properties”.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/95fb34fd-67f7-49c1-b7d4-dc0adb8e4f6e.png)

1. Switch to the [NFS Permissions] tab, then click “Add” to configure the NFS rules.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/cbb4e25e-d0d9-4f27-b24b-b042daceb8d6.png)

1. In the Add NFS Rules settings, enter the IP address of the device to mount the NFS in the Server Address field, ensuring that only authorized devices can access it. The permissions can be set to read-only or read-write.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/8cbd93b4-39a1-45f4-b26f-53933d285f96.png)

1. After confirming the information is correct, click “OK” to save and apply the changes. You can modify the NFS permissions rules for the shared folder at any time.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/1366c499-9832-4cfa-b8f1-62a157a827bf.png)

## **Connecting to NAS via NFS on Windows**

### **Prerequisites**

Before you begin, please ensure the following conditions are met:

- Ensure that the Windows version supports the NFS client feature (Windows 10 Pro and above support this).
- Ensure that NFS service is enabled on the NAS and the NFS permissions for the shared folder are configured.

### **Enable NFS Client**

1. Open the "Control Panel", then click on [Programs] > [Programs and Features].

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/4929cf0d-6cb9-4ad9-ab9a-d36efacff146.png)

1. Click on "Turn Windows features on or off" on the left side.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/c76059d2-3ce9-40ff-817f-c4270e05e97e.png)

1. In the [Windows Features] window, locate the services for NFS , check all the sub-options, and click "OK" to save.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/9b491834-b28a-4d9e-8673-6e8c0fc1b7cb.png)

### **Mount the NFS share**

1. Press`Win + R`and open the command prompt, and type`cmd`, then press Enter.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/c0de12b7-e7d3-4243-a88a-01de61ac5ff0.png)

1. In the Command Prompt, enter the mount command and press Enter to mount. The command format is as follows:

```
mount -o anon \\NAS_IP/path/to/share 挂载盘符:
```

- **NAS_IP:** Enter the IP address of the NAS device.
- **/path/to/share:** Enter the path to the NFS shared folder set up on the NAS.
- **Drive letter:** Enter the drive letter you want to display, such as`N`.

**Example:**

Assuming the shared folder on the NAS is`/volume1/bak`, the NAS IP address is`172.17.70.242`, and the desired drive letter for mounting is`N`, the command is as follows:

```
mount -o anon \\172.17.70.242/volume1/bak N:
```

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/abf0de0c-5366-4f1d-a927-0a215787ead3.png)

1. After a successful mount, you can access the NFS shared directory in File Explorer via the mounted drive letter (e.g.,`N:`）.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250407/329ddc63-8bad-4412-aff4-a3ee969c7d90.png)

## **NFS Advanced Settings**

When configuring NFS, advanced settings can help optimize performance and compatibility. These settings include selecting the maximum NFS protocol version and configuring specific ports, such as the`statd`and`nlockmgr`ports. Fixed port settings help simplify firewall configuration and maintenance.

### **Maximum NFS Protocol**

Selecting the “Maximum NFS Protocol” version in the advanced settings of the NFS server determines the highest protocol version that NFS clients can use. Currently, the protocol version supports NFSv3 connections.

**NFSv3**

- Advantages: Widely supported, good performance, supports large files, and features improved file locking mechanisms and asynchronous writes.
- Disadvantages: Does not support enhanced security (such as Kerberos authentication) and state recovery features.

**statd Port**

- Function: Responsible for NFS lock management, tracking the status of NFS clients, and recovering file locks after a server or client crash.
- Default Port: Dynamic port. Specifying a fixed port can simplify firewall configuration.

**nlockmgr Port**

- Function: Manages NFS file locks to ensure that concurrent access to the same file by multiple clients does not result in data conflicts.
- Default Port: Dynamic port. Specifying a fixed port can simplify firewall configuration.

## **Function Explanation**

**Server Address**

- The IP address or hostname of the NFS client allowed to access the shared folder.
- You can set a single IP address, IP range, or subnet (e.g.,`192.168.1.0/24`) to control which clients can access the shared folder.

**Permission Settings**

- Access Denied: The client cannot access the shared folder.
- Read-Only: The client can read the files but cannot modify or delete them.
- Read-Write: The client can read, modify, and delete the files.

**Squash:**Set the permission mapping to control the access of client users and groups to the shared directory.

- **root mapped to guest:** When enabled, the NFS client will be mapped as a regular user, and its operations on the server will be performed with regular user privileges, thereby enhancing system security.
- **All users mapped to admin:** When enabled, all remote access users and their associated groups will be mapped as anonymous users, and their operations on the server will be performed with the same anonymous user identity, further restricting user privileges and enhancing security.

**Security**

- **AUTH_SYS:**Using UID and GID-based authentication is the common default security mode in NFSv3.

**Asynchronous**

- Enabling asynchronous write operations can improve the performance of the NFS server. Data is first stored in the cache before being written to the disk in batches.
- If enabled, a system crash before the data is written to disk may result in data loss.

**Allow connections from non-privileged ports (ports greater than 1024)**

- By default, the NFS server only accepts connections from privileged ports (ports less than 1024), as these ports are typically used only by the root user.
- Enabling this increases security risks, as non-privileged ports can be used by regular users, and potential malicious users may find it easier to launch attacks.

## **FAQ**

[Access denied when attempting to access](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImlkIjoxMjk0LCJhcnRpY2xlSW5mb0lkIjo0MjcsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=)

[Folder names in Chinese display garbled characters after mounting NFS using Windows File Explorer](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImlkIjoxMjk1LCJhcnRpY2xlSW5mb0lkIjo0MjgsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIn0=)

[When mounting NFS, the error message "'mount' is not recognized as an internal or external command, nor is it a runnable program or batch file" appears.](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImlkIjoxMjkzLCJhcnRpY2xlSW5mb0lkIjo0MjYsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==)
