# Uliya AI Assistant User Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODUwIn0=

**Supported Series**: iDX Series**Supported Platforms**: UGREEN NAS PC Client, Web Browser**Supported Version**: UGOS Pro firmware 1.15.12.0051and laterThis app feature is currently supported only on iDX series devices.Screenshots in this document are for reference only. Actual interfaces may vary slightly depending on system or application versions. Please refer to the actual interface displayed on your device.

## Overview

**Uliya** is more than just an AI assistant—it serves as the intelligent core of the entire system, transforming your device from simple data storage into a content-aware platform. Its key capabilities include four main modules: **Knowledge Base, Summary, Translation,**and**Smart Commands**.

## Installation and Access

1. Open the "**App Center**" and locate the "**Uliya**" application.

2. Click "**Install**" and follow the on-screen instructions to complete setup.

3. After installation, you can quickly access the chat interface by clicking the Uliya icon on the desktop, in the top-right corner of the desktop, or within the "**My apps**" section.

## Model Download & Authorization

When using Uliya for the first time, follow the on-screen prompts to download and authorize the required models. Click "**Download**" to proceed to the UGREEN AI authorization page, where you can install and enable models such as multilingual models, multimodal models, embedding models, person recognition, and text recognition.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/62ce74c18914472f99200039be1c1c1f.webp)

## New Chat

The "**New Chat**" page is the main interface for interacting with the AI assistant. It integrates chat input, model configuration, quick access to AI features, and file uploads.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/48b8053ad3374dec864b7169939d7cc3.webp)

**Key components include:**

● **Chat Input Box**: Enter questions or commands.

● **AI Feature Shortcuts**: Quick access to the four core AI capabilities, allowing fast mode switching (also available below the input box).

● **Knowledge Base**: Enables Q&A based on your personal local knowledge base.

● **Smart Summary**: Upload files or input text to extract key points and automatically generate a mind map.

● **Translation**: Upload files or input text for quick translation into your desired language.

● **Smart Commands**: Select preset commands or use natural language to control device actions (e.g., create albums, play music).

● **Model Switcher**: Displays the current AI model (e.g., Qwen3). Use the dropdown to switch between local or cloud models.

● **Online Search**: When enabled, both local and cloud models can incorporate online search results into responses.

● **File Upload**: Click the "**+**" icon to upload files from local storage or NAS (supports docx, txt, pdf, png, jpg, jpeg) for analysis.

## Knowledge Base

By building a personal knowledge base, Uliya can analyze and retrieve information from your uploaded local files, turning your NAS into a private knowledge hub.

**Note**: Before using this feature, ensure the embedding model is enabled in UGREEN AI.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/46c17a62ab6843a98b991217942a5cc0.webp)

### Create a Knowledge Base

1. Go to the "**Knowledge Base**" page and click "**Create knowledge base**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/ebcccc744db545e7a72ccc6fe648ca01.webp)

2. Set a name and optionally customize a cover, then click "**Create**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/c41487b4b40e4f198daccff3ac943794.webp)

3. After creation, click the "**+**" icon to upload files or folders from local or NAS.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/128adfef9fa44364a86ab8694b1a649f.webp)

4. Hold `Ctrl` or `Shift` to select multiple files, then click "**Confirm**" to add them.

**Notes:**

● You can create multiple knowledge bases by returning to the main page.

● The maximum file size is 100 MB. Files exceeding this limit cannot be added.

### View & Manage Knowledge Bases

On the "**Knowledge Base**" page, you can see the number of files and total storage used for each knowledge base. Hover over a knowledge base and click the "**...**" icon to manage it, clear files, or delete it.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/95ed0cc1d1d348e5b92e8df641327cb7.webp)

Double-click a knowledge base to open its management page and view detailed information.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/3195ea98b3414087bcf716d7adc587f4.webp)

### Use the Knowledge Base

Uliya can analyze and retrieve information from your knowledge base to provide accurate answers.

**Steps:**

1. On the "**Knowledge Base**" page, select the target knowledge base and choose a local or cloud large language model (ensure it is enabled in UGREEN AI).

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/8cde964669e44ba68170169d015922bd.webp)

2. Enter your question in the chat box and click send. Uliya will search the selected knowledge base and return summarized key insights.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/83b0823d4c1f480bb023a2e50089283d.webp)

**Note**: Web search is not supported in Knowledge Base Q&A mode.

## Smart Summary

With smart "**Summary**", you can quickly grasp the key points of long documents without reading them in full.

**Steps:**

1. On the "**New Chat**" page, click "**Summary**", then upload a file (local or NAS) or input text.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/a9fe465991d74030ad86ba6522a87c1c.webp)

2. After uploading, send directly or enter additional instructions (e.g., Summarize this document).

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/7cd157c4da8947bdafa5f8e89684c897.webp)

3. The system generates a summary, with options to copy, preview a mind map, or regenerate.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/f775e0dd28c342648add355061ef7686.webp)

## Smart Commands

Using natural language or preset commands, Uliya can understand your intent and automatically perform tasks (e.g., creating albums or playing music).

**Enable setup**: When using this feature for the first time, go to the "**Smart Commands**" chat page, tap "**More**" commands, then navigate to "**Commands**">"**Settings**" (gear icon) and enable the desired commands.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/e59c4d15c19a4e459abbc670bd764164.webp)

**Steps:**

1. Enter a command directly or select a suggested task (e.g., Create an album).

2. The system generates a command template; customize parameters if needed.
(e.g., Create an album named XXX)

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/8c2645ca7af34e819bc7df3d4087de05.webp)

3. Click "**Send**" button, and Uliya will execute the task and return the result.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/1ec6c2c1e4404a618a1497cd11b1cf51.webp)

## Smart Translation

Powered by large language models, Uliya provides semantic-level translation that preserves the original format, tone, and structure.

**Supported languages**: **Chinese, English, German, and Japanese** (subject to change based on system version).

**Steps:**

1. On the "**New Chat**" page, click "**Translation**" and choose the target language (e.g., English).

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/2b0dac53b32c4d2c959e974e52f8cec5.webp)

2. Upload a file (docx, txt, pdf) from local storage or NAS.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/b2d08c2f845e4b91945103860914591f.webp)

3. Click "**Send**" button to generate a complete translation, with options to copy or regenerate.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/ae00932cf96447c79dbf8f770412aee5.webp)

## General Settings

The "**General**" settingspage allows fine-tuned configuration of Uliya's performance:

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/284c87595bfd4a22a7780623b3a5657b.webp)

● **Cloud models**: Enable to use third-party cloud models. Uploaded documents and knowledge base data will be processed in the cloud.

● **Online search**: When enabled, responses are based solely on online results. Default providers include Google, Baidu and Bing. You can also set result limits and processing methods.

![](https://file1-cn.ugnas.com/admin/article/2026-05-09/f194d74b064547fdb8e8cef49222abad.webp)

● **GPU acceleration**: Uses a dedicated GPU to significantly improve model inference speed.

● **Upload location**: Displays where uploaded files are stored; click to open the folder.

● **Clear history**: Click "**Empty**", youcan instantly delete all chat records to free space and protect privacy.
