# Comics

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzY4In0=

**Applicable Version:** UGOS Pro 1.11.0.0002 and above.

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## Feature Overview

The "**Comics**" app lets you centrally manage and read local comic files stored on your NAS. It offers a polished comic-wall display and a smooth reading experience, helping you build your own digital comic library with ease.

**Key Features:**

● **Local comic management:** Automatically scans and detects comic files in the folders linked to your comic libraries.

● **Enhanced reading experience:** Supports "**Single page**", "**Double pages**", and "**Split to two pages**" modes. You can adjust brightness, set reading direction, change zoom modes, enable page-turn animations, and keep reading progress.

● **Metadata recognition:** Automatically identifies titles and chapter information based on file names or folder structures, and displays cover images.

● **Permissions and sharing:** Allows sharing comic libraries with other NAS users and setting access permissions per user.

**Instructions:**

● The PC and web versions provide library creation and management only.

● For the full reading experience (including reading modes, progress memory, gesture controls, etc.), please use the **UGREEN NAS app** on mobile devices.

**Supported file formats:**

`cbz`, `cbr`, `cb7`, `zip`, `rar`, `tar`, `pdf`, `epub`, `mobi`, `png`, `jpg`, `jpeg`, `webp`.

## Installation and Access

1. Open**"App Center"** and locate the "**Comics**" app.

2. Click "**Install**" and follow the setup wizard.

3. After installation, you can access the app in the following ways:

● **Mobile:** Tap the "**Comics**" icon on the UGREEN NAS app homepage or in "**All**".

● **PC / Web:** Log in to your NAS via the UGREEN NAS desktop client or the web interface, then click the "**Comics**" icon on the desktop or in "**My apps**".

## Prerequisites

Before using the Comics app, make sure that:

● You have created a comic folder in the"**Files**" app.

● Your local comic files have been placed in that folder.

● The folder has full read permissions so the Comics app can scan and detect files properly.

Note: UGREEN NAS does not provide any comic content. Users must prepare and upload their own legally obtained comic files.

## Quick Start

### Create a Comics Library

Before your first use, you need to create a comics library.

1. Open the "**Comics**" app and click "**Create library**".

2. Enter a library name and select the folder that stores your comic files (personal or shared folders are both supported).

3. For the library type, it is recommended to choose "**Chapter comics**" (suitable for comics organized by volumes or chapters).

4. Click "**OK**" to finish.

![](https://file1-cn.ugnas.com/admin/article/2026-01-20/071ebf6f33b04492abfccc6982554c67.webp)

After creating a library, you can view its card on the Comics app homepage:

1. **Sorting:** Drag to reorder. Hover over a library card and click the drag icon that appears in the upper-right corner to adjust its position.

2. **Management:** Click the"**···**"menu in the upper-right corner of the card to perform the following actions:

● **Scan library:** Rescan the folder linked to the library. The system will automatically detect and sync newly added or modified comic files.

If comics have been deleted or moved from the folder, the scan will also update the displayed results accordingly.

● **Edit:** Modify the library name, linked folder, or library type.

● **Delete:** Removes the selected library only. The comic files in the linked folder will not be deleted.

![](https://file1-cn.ugnas.com/admin/article/2026-01-20/dd8bed9b7d7a4c0c875f659e60e741c1.webp)

### User Permission Management

Administrator users can finely control how common users access different comic libraries on the NAS.

![](https://file1-cn.ugnas.com/admin/article/2026-01-20/e65987a1a82044e7a0208f5e735b65c4.webp)

**Steps**:

On the user permission management page, click "**Manage**" to enter the configuration screen. From there, you can select or deselect which comic libraries each user is allowed to view.

![](https://file1-cn.ugnas.com/admin/article/2026-01-20/fe8e1e7f6372440cacd68b11670196db.webp)

**Permission Rules**:

● **Common users**: Have restricted permissions and can access only the comic libraries explicitly assigned to them by an administrator.

● **Admins**: Have the highest level of permissions. By default, they can access all comic libraries on the device, and this access level cannot be modified.
