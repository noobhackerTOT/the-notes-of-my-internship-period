# Reading Settings

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODIwIn0=

You can adjust the comic display and controls according to your reading preferences.

## How to Access the Reading Settings Page

**Method 1: Via "Personal"**

1. Open the "**Comics**" app and tap "**Personal**" in the bottom navigation bar.

2. In the menu list, tap "**Reading settings**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/d674a799e49c4f9088a6cab94028b89a.webp)

**Method 2: From the Reader**

1. While reading a comic, tap the center of the screen to bring up the menu.

2. Tap "**Settings**" button at the bottom, then select "**More**" to enter **"Reading settings**" page.

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/d6a2b6f6de194cd99695219f6b935899.webp)

## Settings Overview

![](https://file1-cn.ugnas.com/admin/article/2026-03-31/a86ec5072d0e4733adcd62e489b3b9c3.webp)

● **Default direction**

Tap to set the page-turn direction. You can choose **Left to Right (L to R)**, **Right to Left (R to L)**, or **Top to Bottom (Top-down)**.

**Note**: This setting only applies to newly opened comics.

● **Background color**

Tap to change the background color of the reading interface. You can choose "**Black**" or "**White**" based on your preference.

● **Crop white color**

Enable this option to automatically crop extra white margins from comic pages, allowing the main content to appear larger.

● **Display contents in notch area**

Enable this option to extend the comic display into the device's notch area for a more immersive full-screen experience.

● **Volume Buttons for Page Turning**

Enable this option to use the physical volume buttons to turn pages, making one-handed reading more convenient.

● **Page Turn Animation**

When enabled, pages will transition with a smooth animation. When disabled, pages will switch instantly. If you notice ghosting effects or slower page turns on your device, you may consider turning this option off.
