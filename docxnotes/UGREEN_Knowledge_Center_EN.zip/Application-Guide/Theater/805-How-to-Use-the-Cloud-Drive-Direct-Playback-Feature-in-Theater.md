# How to Use the Cloud Drive Direct Playback Feature in Theater?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODA1In0=

## Feature Overview

After connecting your cloud drive via the Network Folder function in the "**Files**" app, you can add cloud drive resources to "**Theater**".
The system will automatically scrape media information (such as posters and descriptions) and supports direct playback from the cloud drive.

● **Key Features**: Media files are accessed directly from the cloud drive as a data stream, without occupying local NAS volume.

● **Remote Access**: Cloud drive resources can be accessed directly through the NAS from outside the local network (public network / relay environments), balancing playback performance and data usage.

● **Automatic Failover**: If direct playback encounters an issue, the system will automatically switch to an alternative method (such as NAS proxy playback) to ensure uninterrupted viewing.

## Support Scope

Before using this feature, please review the following compatibility limitations:

### Supported Cloud Drive Services

Currently supports 115 Drive and Quark Drive, with support for more mainstream cloud drives to be added in future updates.

### Supported Client Platforms

● **UGREEN NAS Client****(PC/Mobile)**: Cloud drive direct playback is supported.

● **UGREEN NAS Web**: Cloud drive direct playback is not supported.

**Note**: When playing cloud drive videos via the web interface, the system will automatically use "**Transcode via NAS**" mode.

## Cloud Drive Direct Playback vs Transcode via NAS

To help you choose the most suitable playback method, the differences between the two modes are outlined below:

**Cloud Drive Direct Playback (Recommended)**

● **How it works**: The playback device connects directly to the cloud drive server to retrieve the video stream.

● **Advantages**: Faster playback speed, no consumption of NAS uplink bandwidth, and no use of NAS local storage.

**NAS Proxy Playback**

● **How it works**: The NAS downloads the video from the cloud drive to local storage (download while playing) and then streams it to the playback device via the home network.

● **Limitations**: Playback quality is highly dependent on the NAS’s uplink bandwidth. Insufficient uplink bandwidth may result in buffering or stuttering.

## Setup Instructions

Please ensure that the cloud drive has been successfully connected via "**Network Folder**" in the "**Files**" app before proceeding.

![](https://file1-cn.ugnas.com/admin/article/2026-03-30/91abab8be7a945ca8da29e17c00fb44f.webp)

### Step 1: Add a Media Library

1. Go to Theater Settings, then select "**Library**"＞**"New library**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-30/b4ea19392ee140aaa96433b0a34e5148.webp)

2. In folder path, locate and select the mounted cloud drive network folder.

It is recommended to add only resource paths from the same cloud drive to a single media library. Avoid mixing local storage paths with cloud drive paths, as this may cause unexpected issues.

![](https://file1-cn.ugnas.com/admin/article/2026-03-30/9eb7966924384b068a1b4e00ac896bd3.webp)

### Step 2: Enable Direct Playback

1. In Theater settings, click "**Cloud drive playback mode**" and enable "**Cloud drive direct playback**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-30/32722ee221044d558e7444f350f7afde.webp)

2. Click "**Users authorized for direct playback**", select the users authorized to use this feature, and click "**Confirm"** to save.

To reduce the risk of cloud drive account restrictions caused by multiple IP addresses accessing simultaneously, it is recommended to grant access only to core users.

![](https://file1-cn.ugnas.com/admin/article/2026-03-30/6144b00f9b68420184694f955c3b6abb.webp)

## Playing Cloud Drive Videos

Once media scraping is complete, click the video cover to start playback.

● **Identifying the Playback Mode**: When playing a cloud drive video, a cloud drive icon will appear in the bottom control bar. Click this icon to select the playback method.

![](https://file1-cn.ugnas.com/admin/article/2026-03-30/722d11bcae934c06834b65a174de6c36.webp)

● If "**Cloud drive direct playback**" is not enabled, the system will default to "**Transcode via NAS**". To use direct link playback, be sure to enable it in the settings as described above.

![](https://file1-cn.ugnas.com/admin/article/2026-03-30/cc2cf59412a04e719d7747ea2bc43a88.webp)

## Related Link

[How to Connect to 115 Drive via a Network Folder?](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODAyIn0=)

[FAQs for Cloud Drive Direct Playback](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODExIiwiY2xpZW50VHlwZSI6IiJ9)
