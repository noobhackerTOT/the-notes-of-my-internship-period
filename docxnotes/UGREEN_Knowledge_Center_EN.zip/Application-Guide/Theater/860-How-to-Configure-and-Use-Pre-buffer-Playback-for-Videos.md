# How to Configure and Use Pre-buffer Playback for Videos?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODYwIn0=

# Applicability

**Applicable client**:UGREEN NAS desktop client (Windows/macOS)

**Applicable version**:

● UGOS Pro firmware version 1.16.0.0042 or later.

● UGREEN NAS client version 1.16.0.77862 or later.

This document is for reference only. The actual interface and operation paths may vary slightly due to system or app version updates. Please refer to the actual interface.

## Feature Overview

To handle network fluctuations, the video player in the UGREEN NAS client provides an intelligent "**Pre-buffer playback**"mechanism. This feature automatically downloads a segment of video data ahead of the current playback position to create a "**buffer reserve**". When the network signal suddenly weakens, the player can continue playback using the content that has already been downloaded, significantly reducing stuttering and loading delays.

## Supported Devices

"**Pre-buffer playback**" is currently supported on the following platforms:

UGREEN NAS PC client for Windows and macOS, mobile app for iOS and Android, Apple TV, and Android TV.

**Note**: This feature relies on the client's dedicated built-in player engine. The web browser version uses the browser's native playback capability, so this feature is not supported or displayed there.

## When It Takes Effect and How It Works

Please note that Pre-buffer playback does not apply to all playback scenarios. The following conditions must be met:

● **Only available in**"**Original**"quality: Whether you are playing a local video or a video from a direct cloud drive link, Pre-buffer playback only takes effect when "**Original**" is selected. If any transcoded quality is selected, such as 1080P or 720P, this feature will not start.

● **Visual buffer indicator**: When this feature is enabled and the video is played in "**Original**"quality,**a semi-transparent indicator bar**appears on the player progress bar. It shows the current pre-buffer level in real time, giving you a clear view of the playback**buffer reserve**. If the feature is not enabled or the required conditions are not met, this indicator will not appear.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/d32911315f7e44d6822fa7f1d9a8e2b3.webp)

● **Dynamic network adaptation**: The buffer window automatically adjusts its strategy based on the current network environment, such as Wi-Fi or mobile data. It runs quietly in the background throughout playback and requires no manual intervention.

## Enable and Configure Pre-buffer Playback

1. Open the "**Theater**" app and click the "**Settings**" button (gear icon) in the upper-right corner of the top bar.

2. In the left sidebar of the settings page, click "**Pre-buffer playback**".

3. On the right side of the page, turn on the "**Pre-buffer playback**" switch.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/2b13254a6677477687d59d515aeeca27.webp)

## Manage Pre-buffer Data Cache

Pre-buffer playback is designed to minimize storage impact by automatically managing temporary cache data, preventing excessive files from taking up disk space.

1. **Customize the cache size limit**

After enabling this feature, you can set the cache size limit based on the available storage space on the device you are currently signed in to.

![](https://file1-cn.ugnas.com/admin/article/2026-05-26/9e21aa3198e744c8a346ccb352a863ad.webp)

2. **Automatic rolling cleanup**

When the cached data reaches the specified maximum limit, the system automatically triggers a cleanup process. It removes the least recently used cached content to keep storage usage under control.

3. **Leave no temporary data behind**

If you skip to another point in the video, switch to another video source, or exit the player during playback, the current temporary pre-buffer data will be cleared and will not leave extra files on the device.

4. **Manually free up space with one click**

To free up this storage space immediately, go to the "**Pre-buffer playback**" settings page and click "**Clear pre-buffer data**".

## Cache Size Limit Range by Device

Because storage capacity and performance vary across hardware devices, the system provides different cache size limit ranges for PC, mobile, and TV devices.

| Device Type | Minimum Cache Size | Maximum Cache Size |
| --- | --- | --- |
| PC (Windows/macOS) | 500 MB | 5 GB |
| Mobile (iOS/Android) | 300 MB | 1 GB |
| TV (Apple/Android TV) | 300 MB | 1 GB |

## Notes

When configuring this feature, keep the following behavior in mind to avoid common misunderstandings:

● Pre-buffer playback settings, including the enabled status and cache size limit, are stored locally on the current device. For example, if you enable this feature on your computer and set the cache size limit to 5 GB, it will not be automatically enabled or synced on your phone or TV.

● If you switch to a new phone or computer, or reinstall the UGREEN NAS client, the system will restore the default settings. You will need to go to "**Theater**"**>**"**Settings**"**>**"**Pre-buffer playback**" to enable the feature again and manually set the desired cache size limit.
