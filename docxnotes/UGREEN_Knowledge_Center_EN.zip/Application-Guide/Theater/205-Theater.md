# Theater

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjA1In0=

The "**Theater**" is a full-featured and easy-to-use media application designed to deliver a high-quality audio-visual experience. It allows you to build a personal media library and supports playback across multiple devices. You can stream your media in high definition anytime and anywhere via a browser or client, and share enjoyable viewing moments with family and friends.

With Theater, you can easily:

● **Centralize and organize media files**: Conveniently manage and enjoy your movie and TV content stored on your UGREEN NAS.

● **Build a personal media library**: Retrieve metadata from multiple data sources and organize content by category, such as TV series, movies, and TV programs. Simply enter keywords or apply filters in the search bar to quickly find the content you want.

● **Seamlessly switch between devices**: Supports playback on multiple devices, providing a consistent viewing experience for you, your family, and friends. Whether you use Windows/macOS, Android/iPhone, iPad/Android tablets, or Apple TV/Android TV, Theater synchronizes your playback progress so you can continue watching seamlessly when switching devices.

## Installation and Access

1. **First-time use**: Go to the "**App Center**" and install the Theater application.

2. **Access path**: In the UGREEN NAS app, tap "**All">"Theater"** to access the mobile version.

![](https://file1-cn.ugnas.com/admin/article/2026-01-04/db9c3fa686414a33a7fc8ae32e8639a6.webp)

## Home Page Features

The home page of Theater includes three main sections:

**Recently Watched:**

● Displays recently played videos in a card layout. Tap a card to continue playback from where you left off.

● Tap "**All**" to view the complete playback history, sorted by last played time. You can check viewing progress here; for TV series, the watched episodes are also shown.

● Tap "**Edit**" to delete unwanted playback records.

**Recently Added:**

● Shows posters of the most recently added media in the library, including movies and TV series. New episodes added to existing series are also marked as updates.

● Tap a title to enter its details page; long-press a media card to open the action bar.

● Tap "**All**" to view the full update history. You can switch between update records from different media libraries using the top menu.

**My Favorites:**

● Displays movies and TV series you have added to your favorites. To add a favorite, open the media details page and tap "**Favorites**".

● Tap "**All**" to view all favorited content. You can filter by All, Movie, or Series, and switch between categories as needed.

● Tap "**Edit**" icon to remove items from your favorites.

## Action Bar Functions

The action bar provides the following options:

1. **Favorite**: Tap "**Favorites**" to add a title to "**My Favorites**". For favorited items, the button changes to "**Undo favorites**", which you can tap to remove the item from the list.

2. **Download**: Tap "**Download**" to save videos to your mobile device. In the "**Film download**" window, select the items you want to download. For TV series, tap "**Select all**" to quickly choose all episodes. After selection, tap "**Confirm**" to add the download task. You can view download tasks under "**Task Center**">"**Save to mobile phone**".

3. **Delete**: Deletes the selected content and its media files. Deleted files can be recovered from the Recycle Bin of the corresponding folder in Files (administrator only).

4. **Add to collection**: Add the title to an existing collection, or create a new collection and add it to it (administrator only).

5. **Manual identification**: Correct media metadata by manually identifying the title. Enter the name to search, select the correct match, and confirm to update the media information (administrator only).

6. **Edit information**: Modify details such as poster image, title, and description. Tap "**Edit information**", make changes in the dialog, and tap "**Save**" when finished (administrator only).

**Note**: For information on where the action bar can be accessed within Theater, please refer to [Frequently Asked Questions about the Theater](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImlkIjoxMDI5LCJhcnRpY2xlSW5mb0lkIjozNDIsImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==).
