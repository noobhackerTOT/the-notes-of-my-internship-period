# Optimize Media Management Efficiency: A Comprehensive Guide to the Theater Collections Feature

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjAzIn0=

In the ”Theater“, the Collection feature helps you better organize and showcase content such as movie series, multi-season TV shows, anime, variety shows, and more. Collections support both manual addition and auto-identification.

## **Key Features of Collections**

- **Auto-Identification:** The Theater automatically detects collections, allowing quick organization and management.
- **Flexible Management:**Collections support renaming, manual tagging, metadata editing, and disbanding.
- **Data Safety:** Disbanding a collection will not delete user video files, scraped NFO files, or cover images.

By leveraging collections effectively, you can enhance media library management and improve your viewing experience.

Below are the detailed operating steps and feature introductions:

## **Add Content to a Collection**

To add movies, TV shows, or manually create a collection:

1. Select a video, hover over its poster thumbnail, and click the "..." button.

1. Choose "Add to Collection" from the pop-up menu.
2. To add to an existing collection: Select the target collection and click "Confirm".
3. To create a new collection: Click "New Collection", enter a name, and press Enter.
4. After creation, select the collection and click "Confirm" to finalize.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250728/40dd9cf2-0a74-4bf5-8c09-5ee12036efa0.png)

1. After creation is complete, you can view the collection in the media library interface or click the "Filter" button in the upper-right corner of the media library to filter and view it.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250728/613c3be7-aca6-406c-8852-d53260e90c8d.png)

## **Manage Collections**

After creating a collection, you can perform the following management operations:

- **Delete a Collection:** Hover over the collection's poster thumbnail, click the "..." button, and select "Disband Collection". Deleting a collection will not delete user video files, scraped NFO files, or cover images.
- **Rename a Collection:**Right-click the target collection and select "Rename".
- **Edit Information:** To modify the collection’s cover image or description, click "Edit Metadata".
- **Manually Identification:**Collections support scraping posters/descriptions and manual identification. Right-click the collection, select "Manual Identification", then enter a name to search for matching information.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250728/9030b63d-f956-4381-9036-9c777e4d9e45.png)
