# How to Manage Course Videos in Theater？

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzU4In0=

In "Theater", if you add self-produced course videos, original videos, or personal recordings, these videos are not included in the TMDB database and cannot be automatically identified by the system. You can manually manage such videos by creating a New Episodes, making it easier to organize and play them in one place.

## Manually Create Custom Episodes

1. In "Theater", locate the course video you need to manage.

2. Hover over the video poster, then click "···" > "Add to episodes".

![](https://file1-cn.ugnas.com/admin/article/2025-08-25/29a207f9b0dd424fb59b0f0d11ac494c.webp)

3. In the pop-up window, select "New Episodes", enter the episode name and season, then click "Confirm" to create the new episode. The system will automatically categorize the video under the newly created episode.

![](https://file1-cn.ugnas.com/admin/article/2025-08-25/277ae551c3b04bb2ad7d0905464ef4e6.webp)

**Note:** For additional videos, repeat the process and select the newly created episode in the Add to Episodes pop-up window, then click "Confirm". The system will add the video to that episode.

## Edit Episode Information

After creating a new episode, you can customize its cover, background, and description.

1. In "Theater", open the detail page of the target episode.

2. Click "···" > "Edit information".

![](https://file1-cn.ugnas.com/admin/article/2025-08-25/79ea485c2185409cb14d6596119089cb.webp)

3. Upload or modify the episode cover, background image, and description. After uploading, scroll to the bottom of the page and click "Save" to apply the changes.
