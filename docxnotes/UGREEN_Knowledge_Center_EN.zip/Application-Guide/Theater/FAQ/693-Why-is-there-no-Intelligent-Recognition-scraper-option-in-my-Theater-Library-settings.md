# Why is there no "Intelligent Recognition" scraper option in my Theater Library settings?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjkzIn0=

## **[Issue Description]**

When creating or modifying a library, you may notice that only “TMDB” appears in the metadata scraper options, and the “Intelligent Recognition” option is missing. As a result, the library cannot automatically retrieve and match movie information using the intelligent scraping feature.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250529/7bd8f1d8-d5ca-472d-ae97-d6ef22730d77.png)

## **[Cause Analysis]**

This issue is usually caused by the Intelligent Recognition feature being disabled in the Theater data sources. When this feature is turned off, the library cannot use Intelligent Recognition as a metadata scraping source and can only rely on the TMDB data source for scraping.

## **[Solution]**

1. Log in to the UGOS Pro system with an administrator account and go to the Theater [Settings] page.
2. Click on "Data Sources" in the left menu and check whether the "Intelligent Recognition" toggle is turned off.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250529/e54ce7dc-eb98-4a1a-b9f6-9f443a6fb2cf.png)

1. If the Intelligent Recognition feature is turned off, switch the toggle to the "On" position.
2. Return to the library management interface, and when creating or modifying a library, check whether the "Intelligent Recognition" option appears in the metadata scraper list.
