# Create a New Media Library

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjA2In0=

**Applicable Version**: UGOS Pro 1.10.0.0092 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

# Feature Overview

The "**Library**" is the core module of the Theater app, used to categorize and manage audio-visual resources on the NAS. The system supports creating, editing, and deleting media libraries, and automatically recognizes metadata of media files (such as posters, descriptions, cast information, etc.). With intelligent categorization, users can efficiently organize and search movies by type, year, and other criteria.

**Note:** Before use, ensure that media files are stored on the NAS, the media folder has been created via the "**Files**" app, and the folder has full read permissions.

## Creating a Library

1. Open the "**Theater**" app and click the "**Settings**" button at the top.

2. In the settings menu, go to "**Library**">"**New library**" to access the media library configuration page.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/2f430a680ebf494f9a4596cfea99519f.webp)

3. Enter a name for the library in the"**Name**" field (e.g., Variety Shows, Western TV Series).

4. In the "**Folder**" field, click "**Add**" and select the folder containing your media resources.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/9947c1cd18304af99889b467b99492fc.webp)

5. Optionally, set access permissions for users on this device as needed.

![](https://file1-cn.ugnas.com/admin/article/2026-01-14/0c2ef00b59394263be9d59aa63dd4123.webp)

6. Once all settings are correct, click "**Apply**" to save. The system will start scanning and synchronizing the media library resources.

## Supported File Formats

The Theater supports a variety of mainstream video formats. Users can directly play or manage the following types of media files and folders:

● **Video File Formats:** 3gp, asf, avi, m2ts, m4v, mkv, mov, mp4, mpeg, mpg, rm, rmvb, ts, vob, wmv, etc.

● **Disc Images and Folders:** ISO files and BDMV folders.

### FAQs

1. **Added files do not appear?**

Check whether the file format is supported, the path is accessible, and permissions are correctly set.

2. **How to remove a media library?**

In the "**Library**" list, select the target library, click "**···**"**>**"**Remove**", and confirm the operation.
