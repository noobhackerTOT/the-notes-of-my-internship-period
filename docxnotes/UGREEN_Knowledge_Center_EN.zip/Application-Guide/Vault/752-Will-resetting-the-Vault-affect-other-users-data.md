# Will resetting the Vault affect other users' data?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzUyIn0=

## Issue Description

I want to reset the Vault for the current account but am concerned it might affect Vault data belonging to other administrators or users.

## Cause Analysis

Vaults on UGREEN NAS are created and managed independently for each administrator account. Each account has its own separate data space and encryption settings. The system is designed to ensure isolation between multiple accounts.

## Solution

● Resetting the Vault only affects the currently logged-in administrator account.

● It will not impact Vault data belonging to other administrators or users.

● Other users' Vaults will remain unchanged, and their data will be unaffected.
