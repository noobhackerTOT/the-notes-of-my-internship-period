# Vault

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjczIn0=

Applicability Notes: This document applies to UGOS Pro firmware version 1.7.0.3056.Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface

## Feature Overview

Vault is a high-strength encryption application module designed to protect the privacy of your most critical data. It encrypts files using a dual-factor authentication mechanism consisting of an access password and a key file, ensuring that only you can access the data.

● **Eligible users**: Currently available to "**Administrator**" only.

● **Isolation mechanism**: Once enabled, each administrator on the device can create their own independent vault. Vault data is strictly isolated between administrators, and no administrator can view the contents of another administrator's vault.

## Application Installation

Log in to the NAS, go to "**App Center**", search for and install the "**Vault**" application.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/18bff3ea70c24ab2bea595058afdb4dc.webp)

## Initial Configuration

When you open the "**Vault**" application for the first time, please complete the following initial setup steps:

1. Set a dedicated access password.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/60cd919dd1da44c1a97f30b4ceb88a4a.webp)

2. Click "**Volume**" to choose where the encrypted data will be stored.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/77d7161f252e42e8b64e613c83836e8d.webp)

3. Click "**Open now**", and the system will automatically generate a dedicated `.key` files as your key file.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/fe35e005718f4c74a78ed5dd30708c23.webp)

4. Click "**Continue**" to finish the configuration. Make sure to keep the downloaded key file in a safe and secure place.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/406f5454ec65407685df63a831374c23.webp)

## Unlock and Access

After initialization is complete, identity verification is required each time you enter the Vault:

1. Enter the access password you set, or import the `.key` file.

2. Click "**Open**". Once verification is successful, you can access the Vault.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/e350111eb5404d519dcc9c0e1bc39ee6.webp)

## Features and Operations

After entering the "**Vault**", you can manage encrypted data using the top toolbar or the right-click context menu.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/0333f3db9ed04176a74bd9ecc28d4276.webp)

**Common Functions:**

● **Create**: Createnew itemsin the current directory by clicking the "**+**" button in the top toolbar. You can also right-click an empty area in the file list and select "**Create**" to quickly createfolders, documents, or text files.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/0a95b49264b24f1f81a2f095924d9870.webp)

● **Upload**: Upload files or folders from your local computer to the Vault. All uploaded content is automatically encrypted.

● **View**: Switch between different file display modes, including icon view and list view.

● **Sort**: Sort files by name, modification date, or size.

● **Settings**: Change the storage location, update the access password, or configure the automatic lock time.

● **Search**: Enter keywords to quickly locate files within the Vault.

## File Management

### Move Files from the NAS

You can move files from NAS folders into the Vault for encryption and protection. Available operations vary slightly depending on the folder type.

**Rules**:

● **Personal folders/User folders**: After entering the category, you can directly select and move any folder or file.

● **Shared folders**: You must first enter the root directory of a specific shared folder, then select its subfolders or files to move. The shared folder itself cannot be moved.

**Steps:**

1. Open the "**Files**" application.

2. Locate and select the target items:

● Under "**Personal Folder**" or "**User Folder**", directly select the desired folder or file.

● Under "**Shared Folder**", first enter the specific shared folder, then select its subfolders or files.

3. Right-click the selected item and choose "**Move to 'Vault'**".

4. In the pop-up window, confirm how duplicate file names should be handled. The system will then begin moving and encrypting the data.

### Remove Files from Vault

1. In the Vault, select the file, right-click it, and choose "**Remove from vault**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/bdf37d5388b4451486ed8fdc6062c10a.webp)

2. In the destination selection window, choose where you want the file to be moved, then click "**Confirm**" to complete the operation.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/290df05dedc1445885ca2c93a195813e.webp)

### Automatic Lock Mechanism

To prevent data exposure when you are away, the Vault supports automatic locking.

1. Open "**Settings**" within the Vault.

2. Set the waiting time under "**Auto-lock window when not in operation XXX minute**".

3. Click "**Confirm**" to apply the setting.

**Note:** After the Vault is locked, images that are already open or videos that are currently playing will not be forcibly closed and can continue to be viewed.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/e59e9626097643bd8649acb21bc18095.webp)

## Key and Password Management

### Key File (.key) Storage Location

● **PC** : When enabling the Vault for the first time or changing the access password, the browser will prompt you to manually choose a location to save the key file.

● **Android**: `Files > Download > ugreenPro > key`

● **iOS**: `File > My iPhone > UGREEN NAS > OfflineCache > key`

**Note:** You can quickly locate the key file by searching for "**key**" in the file manager on your mobile device.

### Forgot the Password or Key

● **Key file lost only**:If you still remember the access password, go to "**Settings**">"**Change access password**", enter a new password (it can be the same as the previous one), and the system will generate and download a new `.key` file.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/3e1b151b2ed94bbd95e366d2ccbe2c2e.webp)

● **Both password and key file lost**: If both the key file and the access password are lost, the data can no longer be decrypted. In this case, the only option is to "**Reset 'Vault'**" to use the feature again.

### Reset Vault

Resetting the Vault will permanently delete all data stored in the Vault for the current account, and the data cannot be recovered. You can use this option if you have forgotten the password and lost the key file, or if you need to clear all data and set up the Vault again. The reset operation applies only to the Vault of the current account.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/10400bf1d5c9429c9a5da855e286d534.webp)

## FAQs

### Will resetting the NAS to factory settings delete Vault data?

No, it won't. Factory reset does not delete Vault data. The data remains stored in the designated storage location.

### Will uninstalling the Vault application delete the Vault data?

No, after reinstalling the app, you can access your original Vault data by entering the original password.

### What should I do if I cannot delete a user?

If a user has enabled the Vault, the user cannot be deleted directly. Before deleting the account, you must log in to that user account, open the Vault application, and click "**Reset 'Vault'**" to clear all Vault data. For AD domain users, whether Vault data is retained depends on whether "**Keep data**" is selected when deleting the AD user.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/24139057332e4305b6bfca9a571f2a6a.webp)

### Why can't I see my data after replacing a hard drive?

The Vault is bound to a specific Volume. If the original hard drive that contains the Vault data is removed and the Vault is then enabled on a different Volume, the system cannot recognize the data stored on the original drive. To access the original data, you must reinsert the original hard drive.

Example:
If the Vault was originally created on "**Volume 1**", and the hard drive for that Volume is later removed, then enabling the Vault on "**Volume 2**" will create a new Vault. Data stored on "**Volume 1**" will not be visible until the original drive is reinserted.

### Can files stored in the Vault be backed up?

Currently, encrypted files stored in the Vault are not supported by the "**Sync & Backup**" feature.
