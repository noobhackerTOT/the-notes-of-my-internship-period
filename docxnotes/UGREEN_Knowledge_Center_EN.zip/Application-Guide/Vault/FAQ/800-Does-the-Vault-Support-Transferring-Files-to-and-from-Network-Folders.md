# Does the Vault Support Transferring Files to and from Network Folders?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODAwIn0=

## Problem Description

Does the Vault support moving files out of the Vault to network folders? Does it support moving files from network folders into the Vault?

## Cause Analysis

When using the Vault feature, some users regard network folders on the NAS—such as SMB/NFS shared directories or mounted third-party cloud drives—as "**external locations**". As a result, they are unsure whether these folders support direct file transfers in the same way as local storage, leading to questions about possible limitations.

## Solution

The Vault fully supports two-way file transfers between the Vault and "**Network Folder**", including both move-in and move-out operations.

**This applies to the following types of network folders:**

● Standard network shared folders (such as SMB shares and WebDAV mount points)

● Third-party cloud drives mounted as network folders (such as 115 Cloud, etc.)

**The specific operations are as follows:**

● Move files from a network folder into the Vault

Select the file in the network folder, right-click it, and choose "**Move to 'Vault'**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/80035c5917d7457c90abbf5a41d1378d.webp)

● **Move files from the Vault to a network folder**

Select the file in the Vault, right-click it, and choose "**Remove from vault**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/98774425d8464ca5911e797873a27bbf.webp)

In the pop-up path selection window, choose the network folder as the destination and click "**Confirm**" to move the file.

![](https://file1-cn.ugnas.com/admin/article/2026-01-27/bf7002eb34b747ee945eac365137e75b.webp)
