# How to Securely Manage Cloud Drive Files Using the Vault?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODAzIn0=

By integrating the Vault with the "**Network Folder**" feature, you can encrypt and archive data from your cloud drive, or decrypt and export it back to the cloud drive as needed. This article uses 115 Drive (115 Life) as an example to demonstrate the steps for moving files from a cloud drive into the Vault, as well as exporting files from the Vault back to the cloud drive.

## Applicability

● This operation applies only to cloud drives connected via the "**Network Folder**" feature in the "**Files**" application.

● It is effective only for Vault configured on the current NAS and cloud drive directories that have already been connected.

## Moving Cloud Drive Files into the Vault(Encryption)

This operation moves files from the cloud drive to the local NAS Vault and stores them in encrypted form.

**Steps:**

1. Open the "**Files**" application and click "**Network Folder**" in the left sidebar.

2. Navigate to the connected 115 Drive, locate the target file, right-click it, and select **"Move to 'Vault'**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/4b41e5ba04cd4490b35ddd95a0b83698.webp)

3. In the pop-up window, confirm how to handle files with duplicate names. The system will then move and encrypt the data.

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/1758fdba2680439497c533dfab579962.webp)

## Moving Files from the Vault to the Cloud Drive(Encryption)

This operation moves files from the cloud drive to the local NAS Vault and stores them in encrypted form.

1. Select the files in the Vault, right-click, and choose "**Remove from vault**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/bd5896ed7f09406a871639009e777408.webp)

2. In the path selection window, choose a directory under the 115 Drive in "**Network Folder**" as the destination and click "**Confirm**" to move the files.

![](https://file1-cn.ugnas.com/admin/article/2026-01-28/e7d146a2df8b45a48f1ab4190367c225.webp)

## Note

● Files are encrypted during the "**Move to 'Vault'**" process. Please maintain a stable network connection and do not close the page or disconnect the NAS during the operation.

● If files with the same name already exist at the destination, the system will process them according to your selected option (Skip, Overwrite, or Keep).

● Encrypting or decrypting large files or batches of files involves network transmission and data processing, which may take a considerable amount of time. Please be patient.

## FAQs

1. **After moving a file into the Vault, does it still remain in the cloud drive?**

No. When you select "**Move to 'Vault'**", the file is **removed from the cloud drive** and transferred into the Vault, where it is securely stored in encrypted form.

2. **Can files be copied instead of moved?**

Currently, copying files is not supported. For security reasons, the system only allows moving files into the Vault with encryption. This means the original file cannot be kept on the cloud drive at the same time.
