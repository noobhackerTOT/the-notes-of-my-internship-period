# Backup This UGREEN NAS

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDAyIn0=

Backing up data from your local UGREEN NAS to a remote rsync file server is an effective way to safeguard your data. In the "**Sync & Backup"** interface, you can easily complete this task. The detailed steps are as follows:

## Create Backup Task

In the "**Sync & Backup**" interface, click "**Add**" and select "**Backup This UGREEN NAS**".

## Connect Backup Destination Server

In the "**Connect backup destination server**" interface, select an rsync or WebDAV file server, and then enter the required information as prompted below:

**The rsync server backup configuration options are as follows:**

![](https://file1-cn.ugnas.com/admin/article/2026-04-10/77c1dc8735844f95af107e150b7e3ea2.webp)

● **Server Address**: Enter the IP address of the remote rsync file server.

● **Transmission Encryption**: Choose whether to enable encryption for the transfer to ensure the security of the data.

● **Port**: Enter the communication port used by the device (default: 873).

● **Username**: Enter the username used to connect to the rsync file server.

● **Password**: Enter the corresponding login password.

Once you've verified the information, click "**Confirm**"to proceed. If you have previously connected to this server, you can select it from the "**Existing connection**" dropdown menu to proceed directly to the next step.

**The WebDAV server backup configuration options are as follows:**

![](https://file1-cn.ugnas.com/admin/article/2026-04-10/f8b29638da21495c90e39a2e82df9ef2.webp)

● **Server Address**: Enter the IP address of the remote WebDAV file server.

● **Protocol**: Select either HTTPS (encrypted transmission) or HTTP as needed.

● **Port**: Enter the communication port used by the device (default HTTP port: 5005; default HTTPS port: 5006).

● **Root Folder**: Enter the shared folder path on the WebDAV file server.

● **Username**: Enter the username used to connect to the WebDAV file server.

● **Password**: Enter the corresponding login password.

Once you've verified the information, click "**Confirm**"to proceed. If you have previously connected to this server, you can select it from the "**Existing connection**" dropdown menu to proceed directly to the next step.

**Additional Information:**

**Root Folder Path Format:**

● If the WebDAV server is a UGREEN NAS, the root folder path should be the name of the shared folder.

| Shared Folder Name | Path to Enter |
| --- | --- |
| downloads | /downloads |
| documents | /documents |

**Path Entry Considerations:**

● **Case Sensitivity**: Ensure the folder name in the path matches exactly with the shared folder name (e.g.,`/Downloads` and `/downloads` is not the same).

![](https://file1-cn.ugnas.com/admin/article/2026-04-10/913d15587ae04983898ea3f8d28e5984.webp)

**Note:**If two devices are not on the same local network and need to set up a backup task, you can use a DDNS domain name or a public IP address to connect to the NAS and then create the backup. Please ensure that the other device supports and has enabled rsync/WebDAV services. For more information, please refer to[Rsync](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODEiLCJjbGllbnRUeXBlIjoiIn0=)and[WebDAV](https://support.ugnas.com/knowledgecenter/#/detail/eyJjb2RlIjoiMiYmODIiLCJjbGllbnRUeXBlIjoiIn0=).

### Select Backup Folders and Set Filtering Rules

On the "**Selection**"interface, select the local folders you want to back up and choose the backup destination. The destination refers to the backup storage location on the rsync or WebDAV file server.

You can choose whether to set filtering rules:

● **File name or extension filtering**: By selecting "**Filter by file name or file extension**" and configuring the rules, you can exclude files that do not need to be backed up. To add a new rule, click the "**Add**" button and enter the file name or extension (multiple entries should be separated by "**;**"). To delete a rule, hover over it and click the floating "**X**".

● **File size limit**: After enabling "**Limit file size**", you can set a maximum file size. Files exceeding this limit will not be backed up.

● **Default excluded formats**: The filtering rules exclude the following file types by default: *.link, *.swp, *.temp, *.tmp. You can adjust these according to your needs.

After confirming that all settings are correct, click "**Next**".

## Setting Backup Schedule and Version Retention Policy

In the "**Settings**" interface, you can configure the execution schedule for the backup task:

● **Backup Time**: Choose from daily, weekdays, weekends, or custom dates, and set the start time for the backup.

● **Version Retention Policy (only applies to backups to remote servers)**: By checking "**Backup Version Policy**," the system will, by default, only retain the latest version. You can also customize the number of versions to retain.

Once set, click "**Next**" to continue.

## Preview

In the "**Preview**" interface, you can customize the task name and review all the settings. If everything is correct, click "**Confirm**" to create the backup task. If you check **"Back up immediately after creation**" the system will execute the backup as soon as the task is created.

### Task Management

After the task is created, you can manage the connected devices and backup tasks in the "**Sync & Backup**" interface:

● Click the "**···**" button on the right side of the device to quickly create a new task, set device notes, or remove the connection.

● In the backup task list, click "**Back Up Now**" to manually initiate a backup. Clicking the "**More"** button allows you to view the backup log, or edit and delete tasks.

**Note:**

● **Version List Function Limitations**: The version list feature is only available for backup tasks that involve "**Backing Up UGREEN NAS to a Remote Server**". This feature is not available in other backup modes.

● **Backup File Encryption**: When you back up UGREEN NAS data to a remote server, the backup files will be encrypted by default. The true content of these files can only be viewed once they are restored from the remote server back to UGREEN NAS.
