# Sync this computer

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzk5In0=

## **Configuration Sync with Computers**

If you want to synchronize files between the computer you are currently using and the UGREEN NAS, you first need to install the UGREEN NAS Client on the computer and create and manage synchronization tasks through this device. Please note that the execution of the synchronization policy depends on the running of the client, if you exit the client, the synchronization operation will stop.

## **Installation and Logging**

Login to UGOS Pro system using UGREEN NAS. In the client, navigate to**[Sync & Backup]**>**[Sync]**interface, click the “**Add**” button and select “**Sync this computer**” to create a new synchronization task.

## **Set Sync Rules**

In the**[Sync Rules]**settings interface, you need to specify the synchronization path and method:

- **Computer Path**: Select the location on your current computer where the synchronization files are stored.
- **UGREEN NAS Path**: Choose the location on your UGREEN NAS device where the synchronization files are stored.

Next, choose the sync method:

- **Two-way Sync**: In this mode, file changes on both devices are automatically synchronized, ensuring consistency across all devices.

- **One-way Download**: Download data from the UGREEN NAS to the computer only.
- **One-way Upload**: Upload data from the computer to the UGREEN NAS only.

**Example**: If you wish to synchronize data from your current computer to the UGREEN NAS device and ensure that the data remains consistent for future use, you can create a synchronization task. Set the computer path to Folder B and the UGREEN NAS path to Shared Folder A, and select "**Two-way Sync**." This way, the files between your computer and the UGREEN NAS will always stay in sync.

If you wish to synchronize this data on another computer as well, simply install the UGREEN NAS client on that machine. Utilize the synchronization feature to set the computer path to the designated folder, while keeping the UGREEN NAS path as Shared Folder A. With this setup, the data across all three devices will remain synchronized, ensuring seamless consistency across your network.

![](https://ugreen-pro.oss-cn-shenzhen.aliyuncs.com/ugreen-pro/admin/article/20241212/4ae7c3f9-861d-4fbb-9c93-3d83837cb46d.png)

### **Advanced Settings**

In the**[Advanced Settings]**section, you can further configure the details of your synchronization tasks:

**File Filtering**

- In the "**File Filter**" option, you can choose whether to synchronize files and folders with a prefix of ".". By default, the system does not synchronize these hidden files and folders. If you need to synchronize them, manually check the corresponding option.
- You can also set filters for file names or file extensions that do not need to be synchronized:- Check the "**Filter the following file names or extension name**" option and adjust or add filtering rules as needed.
  - To remove a filtering rule, hover your mouse over the format bar and click the floating "**X**" to delete.
  - To add a new filtering rule, click the "**Add**" button and enter the file name or extension. If entering multiple, separate them with a "**;**".

**Examples:**

- Filter specific file names: e.g.`abc.doc`、`test*.doc`、`tmp.*`.
- Filter for specific file types: e.g.`*.jpg`.

**Default Filter Format**:

| *.tmp | *.temp |
| --- | --- |
| *.swp | *.link |
| *.pst | ~*.* |
| @eadir | .SynologyWorkingDirectory |
| #recycle | desktop.ini |
| .DS_STORE | lcon\r |
| thumbs.db | $Recycle.Bin |
| @sharebin | System Volume Information |
| Program Files | Program Files (x86) |
| ProgramData | #snapshot |

**File Conflict Handling**

In the [**File Conflict]**, you can specify how to handle file conflicts when they occur. By default, the system will rename conflicting files to avoid data loss.

### **Set Sync Policy**

After setting “Sync Rules”, click “**Next Step**” to enter the Sync Policy interface. In [**Sync Policy**], you can choose the proper sync method:

- **Real-time Sync**: The system will automatically synchronize when it detects file changes.
- **Manual Sync**: The system will synchronize only when you click “**Sync Now**” manually.

Once finished, click “**Next Step**” to enter the preview.

## Preview and Task Creation

In the**[Preview]**interface, you have the ability to customize the name of your sync task and review the previously set configuration options. If you find it necessary to make any changes, simply click on "**Previous**" to go back and modify the settings. Once you are satisfied that the configuration is correct, click "**Confirm**" to create the synchronization task.

## Task Management

After the creation, you can manage the connected sync devices and tasks in the [**Sync**]interface:

- **Pause Syncing**: Click “**Stop Syncing**” button.
- **More Actions**:Click the "**More**" button to view and edit logs, or delete the task.
- **Quick Task Creation**: Click the**"···"**button on the right side of the sync device listing to create a new sync task.

![](https://ugreen-pro.oss-cn-shenzhen.aliyuncs.com/ugreen-pro/admin/article/20241212/e771c570-9028-4c07-9567-294acb010c0f.png)

**PC Desktop Tray Program**: Click the icon in the taskbar to check file transfer status OR pause ongoing tasks.

![](https://ugreen-pro.oss-cn-shenzhen.aliyuncs.com/ugreen-pro/admin/article/20241212/52f1ea2b-a65a-477c-90a3-0823e326b6a9.png)
