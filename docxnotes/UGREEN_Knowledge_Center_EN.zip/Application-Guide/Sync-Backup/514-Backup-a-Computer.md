# Backup a Computer

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTE0In0=

Backing up a computer to UGREEN Cloud involves transferring files from the computer to the UGREEN NAS. This functionality requires the use of the UGREEN NAS Client.

## Create Backup Task

1. In the [Back up & Restore] interface, click on "Add", then select "Backup this computer."

2. In the [New backup task] interface, choose the Computer Path that you need to back up to the UGREEN Cloud NAS.

3. If you want to exclude unnecessary files from being backed up, you can set up filter rules:

● **File Name or Extension Filtering**: By selecting "Filter the following file (folder) names or file extensions" and adjusting the rules, you can exclude files that do not need to be backed up. To add a new rule, click the "Add" button and enter the file name or extension (use **";"** to separate multiple criteria). To delete a rule, hover over the target rule and click the floating "X" button.

● Below are the default filtering formats, which you can modify as needed.

| *.tmp | *.temp |
| --- | --- |
| *.swp | *.link |
| *.pst | ~*.* |
| @eadir | .SynologyWorkingDirectory |
| #recycle | desktop.ini |
| .DS_STORE | lcon\r |
| thumbs.db | $Recycle.Bin |
| @sharebin | System Volume Information |
| Program Files | Program Files (x86) |
| ProgramData | #snapshot |

4. After confirming that the settings are correct, click "Next Step" to continue.

## Configure Backup Task

In the [Selection] interface, select the Backup Destination, which is the storage location on the local UGREEN NAS. You can choose the backup strategy, which supports "Backup after file change" or "Manual Backup." Manual backup will only execute when you manually click "Back up now."

After completing the settings, click "Next Step" to continue.

## Preview and Create Task

In the [Preview] interface, you can customize the task name and review all settings. If everything is correct, click "Confirm" to create the backup task.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-16/54d7322ee726427abfa221a8f1fd7fe0.webp)

**Incremental Backup**: Only backs up changes made since the last backup. After the backup, files deleted from the source will still be retained at the backup destination.

## Task Management

After the task is created, you can manage the connected devices in the [Back up & Restore] interface:

● Click the "**···**" button on the right side of the device to select Pause, Edit, or Delete the task.
