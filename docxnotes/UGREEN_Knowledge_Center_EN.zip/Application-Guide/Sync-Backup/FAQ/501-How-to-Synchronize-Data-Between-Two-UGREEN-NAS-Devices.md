# How to Synchronize Data Between Two UGREEN NAS Devices?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTAxIn0=

# How to Synchronize Data Between Two UGREEN NAS Devices?

In home or office scenarios, you may need to synchronize data between two UGREEN NAS devices. Using the "**Sync & Backup**" application in the UGOS Pro system, you can easily achieve data synchronization between UGREEN NAS devices. Below is a simplified guide and key notes to follow:

## Preparation

● **Devices**: Prepare two UGREEN NAS devices running the **UGOS Pro system**. Ensure both devices are connected to the network and within the same local area network (LAN). If the devices are not in the same LAN, use a public IP or configure DDNS (Dynamic Domain Name System) to establish a connection.

● **Application**: Install the **"Sync & Backup"** application on both NAS devices.

● **System Settings**: Verify that the time and timezone settings on both devices are consistent to avoid issues with synchronization tasks caused by time discrepancies.

## Steps to Follow

1. Log in to the UGOS Pro system on the local NAS, navigate to the "**Sync & Backup**" application, select the **"Sync"** tab, and click **"Create sync task."**

![](https://file1-cn.ugnas.com/admin/article/2026-03-17/fdf7a5819aa141b5a0673f8993d41505.webp)

2. Select the synchronization target, choose "**Sync another UGREEN NAS**", and click "**Next**" to proceed.

![](https://file1-cn.ugnas.com/admin/article/2026-03-17/c0a28474eeb54e66a700ff9d3a5a450d.webp)

3. To set up a remote connection, you need to fill in the following information. Once completed, click "**Confirm**" to connect to the device.

● **IP Address or UGREENlink ID:** Enter the target NAS's local IP address (for example, 192.168.22.141). You can also enter the UGREENlink ID (for example, ugreen).

**Note**: If the two NAS devices are not on the same local network, you will need to use UGREENlink, a public IP address, or DDNS to establish the connection.

● **Transfer Encryption:** You can enable transfer encryption to help protect your data.

● **Port**: The default port for a standard connection is 9999, and in most cases, it does not need to be changed. If transfer encryption is enabled, you need to change the port to 9443 (the system's default encrypted port).

● **Username and Password**: You must enter the administrator account and password of the target NAS.

![](https://file1-cn.ugnas.com/admin/article/2026-03-17/929b1f6299374cc7aab870f07b988b46.webp)

4. Once the connection is successfully established, configure the following synchronization rules. After completing the configuration, click "**Next**".

● **Remote Path**: Select the folder on the target NAS that needs to be synchronized.

● **Local Path**: Select the folder on the local NAS that needs to be synchronized.

● **Synchronization Direction**: Three synchronization directions are supported, **One-way synchronization** (From local to remote or remote to local), and **Two-way synchronization** (Keeps both devices synchronized in real time).
Select the synchronization direction based on your needs.
Click the "**Advanced Settings**" option to configure features such as file filtering rules and conflict resolution rules.

![](https://file1-cn.ugnas.com/admin/article/2026-03-17/9043b8b3d81a4789b8034d4c80aae8b2.webp)

5. Configure the synchronization strategy as needed. The system supports real-time synchronization, manual synchronization, or sync as planned (e.g., executing daily at 2:00 AM). After completing the configuration, click "**Next**".

**Note**: The execution of synchronization tasks depends on the normal operation of both devices. If either device experiences an interruption, synchronization will be halted.

![](https://file1-cn.ugnas.com/admin/article/2026-03-17/f2c2cfb2dff84690a45b7f69f5391cd1.webp)

6. Preview and verify the synchronization task details. You can also rename the task if needed. Once confirmed, click "**Confirm**"

![](https://file1-cn.ugnas.com/admin/article/2026-03-17/71f4bbb5ae394be7acb35daca2273ffb.webp)

7. After the synchronization task is created, you can view the task's status and progress on the "**Sync**" interface. Options are available to pause, edit, or delete synchronization tasks. During task execution, you can use the log feature to view detailed operation records and troubleshoot issues efficiently.

![](https://file1-cn.ugnas.com/admin/article/2026-03-17/4432ed790f394d979cca394faff3f96f.webp)

## Notes

1. If the target NAS cannot be connected via IP address, please check the following:

● **Port Forwarding:** Ensure that your router is configured with the correct port forwarding rules. Map port 9999 on the router. If transfer encryption is enabled, you also need to map ports 9443 and 22000. Port 22000 is specifically used for encrypted data transmission.

● **Firewall Settings**: Check whether the NAS has a firewall enabled. If so, make sure it allows network access for the ports used by the Sync & Backup app. Also check firewall rules on your router or other gateway devices, and ensure they allow the required ports and NAS-related services.

● **Dynamic DNS (DDNS)**: If you are connecting via a public IP address, note that the IP may change frequently. It is recommended to configure a DDNS service to obtain a stable domain address.

2. If you need to transfer large files or a large amount of data within a local network, it is recommended to connect the devices to a Gigabit or 2.5GbE network to significantly improve transfer efficiency.

3. The sync feature is intended to maintain data consistency only. It is recommended to regularly back up important files to a separate storage device.

4. Avoid running too many sync tasks at the same time, as this may lead to insufficient network bandwidth or reduced device performance.
