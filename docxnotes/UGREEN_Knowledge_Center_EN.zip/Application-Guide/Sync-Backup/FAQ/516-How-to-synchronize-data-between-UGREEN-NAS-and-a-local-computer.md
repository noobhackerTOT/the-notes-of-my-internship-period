# How to synchronize data between UGREEN NAS and a local computer?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTE2In0=

In home or office environments, you may need to synchronize files across multiple devices. For example, you might want to keep data consistent between one or more computers and a UGREEN NAS device. In such cases, you can use UGREEN NAS’s synchronization feature to configure sync tasks and enable real-time data updates across devices.

## **Example Scenario**

Suppose you want to synchronize Folder B on your computer with Shared Folder A on the UGREEN NAS. You can set up a two-way synchronization mode. When files are modified on either device, the changes will automatically sync to the other. If you want additional devices (such as a second computer) to stay updated as well, simply configure the same type of sync task on those devices. This way, all three devices will maintain consistent data at all times.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250723/153be6f3-5361-450d-a87a-6d3efa80e482.png)

## **Preparation Before You Start**

- **Download the UGREEN NAS Client**: Make sure to download and install the latest version of the UGREEN NAS client from the official website. [(Click here to download)](https://www.ugnas.com/download/)
- **Update to the Latest Version**: After installation, check if the client is up to date.
- **Check the NAS Status**: Ensure your NAS device is running properly and connected to the network.

## **Steps to Follow**

1. Open the UGREEN NAS client on your local computer. Go to [Sync & Backup] > [Sync], then click “Create Sync Task.”

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250722/67d7e941-34f4-41ba-89d2-9dbf4a445c55.png)

1. Select the sync destination. Choose "Sync This Computer", then click "Next" to continue.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250722/19c3bfb9-7731-44c2-b4d1-f8b18ad84146.png)

1. **Configure Sync Rules**:

**Select Computer Path**: Choose the folder on your local computer that you want to sync.

**Select UGREEN NAS Path**: Choose the target folder on your UGREEN NAS device.

**Select Sync Direction**: In this example, select the **"Two-Way Sync"** option.

- **Two-Way Sync**: Synchronizes files between your computer and the NAS device to ensure data consistency on both ends.
- **Sync NAS to Computer Only**: Only syncs changes from the NAS to your computer. By default, deleted files on the NAS will not be deleted on the computer.

- **Sync Computer to NAS Only**: Only syncs changes from your computer to the NAS. By default, deleted files on the computer will not be deleted on the NAS.

In [Advanced Settings], you can further configure the sync task details, such as setting filters to exclude specific file names or extensions from synchronization, as well as defining how to handle file conflicts. For more information, please refer to the [Sync this computer](https://support.ugnas.com/knowledgecenter-h5/#/articleDetail?custom=eyJ0eXBlIjoidGFnMDAxIiwibGFuZ3VhZ2UiOiJ6aC1DTiIsImlkIjoxMTU0LCJhcnRpY2xlSW5mb0lkIjozOTksImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiMS4wIiwicGF0aENvZGUiOiJwcm8wMDIsazZybGJzLGczNWZvdywyU21tbnIifQ%3D%3D).

Once completed, click “Next” to continue.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250722/3bb93aa5-286f-4ab9-9a06-9a7ab5ae4c2a.png)

1. Select a sync strategy and choose one of the following options as needed:

- **Real-time Sync**: The system will automatically sync files whenever changes are detected.
- **Manual Sync**: Files will only sync when you manually click “Sync Now.”

After making your selection, click “Next Step” to proceed to the preview stage.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250722/8a7a4048-1730-4e0b-95b0-87684788ee7b.png)

1. In the [Preview] screen, you can customize the name of the sync task and review the previously configured settings. If any changes are needed, click “Previous” to modify them. Once everything is confirmed, click “Confirm” to create the sync task.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250722/f57ae205-0931-4234-8256-d564126b22e5.png)

1. After the task is created, you can view all connected sync devices and tasks in the [Sync] interface and manage them as needed. Click the “`···`” button next to a device to quickly create a new sync task for it. Click the “More” button to view the operation log, edit, or delete existing tasks.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250722/bc28d45e-07e7-42eb-aae7-e047bb9653a9.png)

1. Click the client icon in the computer’s taskbar to view the transfer status of files within the Sync & Backup application, and to pause any ongoing transfer tasks.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250722/3960add1-435c-4c62-b203-dd478dbaa329.png)

**Please note**

1. To synchronize files between your local computer and UGREEN NAS, you must first install the UGREEN NAS client on your computer and use it to create and manage sync tasks.
2. Sync tasks depend on the client running. If the client is not running or has been closed, data synchronization will pause and will resume only after restarting the client.
3. If data is accidentally deleted during the sync process between your computer and UGREEN NAS, you can recover deleted files by locating the #SyncVersion folder within the corresponding directory in the NAS’s files.
