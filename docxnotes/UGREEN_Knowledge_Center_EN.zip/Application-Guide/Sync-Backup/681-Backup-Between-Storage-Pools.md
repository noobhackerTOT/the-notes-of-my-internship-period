# Backup Between Storage Pools

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjgxIn0=

In UGOS Pro’s "Sync & Backup" app, you can use the "Backup Between Storage Pools" feature to perform regular backups of important data between different storage pools, achieving data protection and enhancing overall data security and flexibility.

**Use Case Example**

Suppose your NAS has two storage pools: storage pool 1 and storage pool 2. To ensure data security and access speed, you can use the “Backup Between Storage Pools” feature to schedule regular backups, backing up important files (such as Folder A) from storage pool 1 to storage pool 2 (such as Folder B). This way, you can maintain fast data access while reducing the risk of data loss caused by a failure in one storage pool.

## **Prerequisites**

Before using this feature, please ensure the following conditions are met:

- The system firmware and the [Sync & Backup] app are both updated to the latest versions;
- There are at least two storage pools on the NAS device. If there is currently only one storage pool, please add new hard disks and create additional storage pools before proceeding with the setup.

## **Create Backup Task**

Follow the steps below:

1. Go to [Sync & Backup] > [Backup & Restore] page, click “Create Backup Task,” select the backup type as “Backup Between Storage Pools,” then click Next.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250603/e7126480-e488-4985-a983-8d0492a08233.png)

1. Select the backup source, backup destination, and backup file filtering rules. After completing all settings, click “Next” to continue.

- **Select backup source directories:** You can select multiple folders as backup sources simultaneously.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250603/fe66916e-a9b6-4f28-8f6f-e54a9f4a7db4.png)

- **Select backup destination:** Only folder paths that belong to a different storage pool than the backup source can be selected, and only one destination path is supported. If the selection is invalid, please confirm whether the destination path is in a different storage pool.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250603/f35dc9fd-d490-43f8-983c-a74ea0ec6acc.png)

- **Filter rule (optional):**Set file filtering rules according to your needs to exclude files based on size, file (or folder) names, or file extensions from being backed up.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250603/16142964-5915-476e-b941-63af7b438b88.png)

1. Choose the appropriate backup mode based on your actual needs, and set the backup schedule. After completing the configuration, click “Next” to continue.

**Backup Modes**

- Incremental Backup: Only backs up files that are new or modified since the last operation. Deleted files remain in the backup destination. Suitable for scenarios requiring long-term retention of history.
- Mirror Backup: Ensures the backup destination is exactly the same as the source directory, including removing files deleted from the source. Suitable for scenarios needing precise synchronization.

**Backup Plan**

Set the time for automatic backups to run. The following plan types are supported:

- Daily, weekdays only, weekends only, custom time;
- Specify the execution time (e.g., 2:00 AM daily) to minimize impact on device usage during the day.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250603/43c1fedb-47bc-4059-a128-cad5b2ca87f4.png)

1. On the [Preview] page, review all settings. On this page, you can also perform the following actions:

• Modify the backup task name.

• Check “Back up immediately after creation” to automatically start the first backup once the task is created.

Click “Confirm” to complete the task creation.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250603/bf9fe248-886e-445b-93a1-e3fc3285aa1c.png)

## **Monitor and Manage Backup Tasks**

All created tasks can be centrally managed on the [Backup & Restore] page, where you can monitor and adjust the status of backup tasks at any time.

- **View backup task status:** Includes connection status, last backup time, execution result, next scheduled backup time, etc.
- **Run or pause tasks immediately:** You can start or pause backup tasks instantly.
- **Edit tasks:**Click the “More” button on the right and select “Edit Task” to modify the task name, backup source, filter rule, and backup plan.
- **Delete tasks:** Click the “More” button on the right and select “Delete Task” to remove completed or unnecessary tasks.
- **Create new task:**Click the “...” button on the right of a task to quickly create a new backup task.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250603/f0740f66-ce7e-432c-8897-db549cc6c1b4.png)

## **Notes**

1. When there is only one storage pool on the current device, the “Backup Between Storage Pools” feature is unavailable.
2. The backup process consumes system resources. It is recommended to schedule the task during idle hours (e.g., at night).
3. Do not insert or remove hard disks during the backup process. Ensure that the relevant storage pools are in a healthy state and the network connection is stable to avoid task interruption or failure. If an error occurs during backup, please go to the Log Center for detailed information or contact technical support for assistance.

## Related Link

[Backup to External Hard Drive/USB Drive](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDAyIiwibGFuZ3VhZ2UiOiJlbi1VUyIsImlkIjo0NjE5LCJhcnRpY2xlSW5mb0lkIjo2NzksImNsaWVudFR5cGUiOiJQQyIsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==)
