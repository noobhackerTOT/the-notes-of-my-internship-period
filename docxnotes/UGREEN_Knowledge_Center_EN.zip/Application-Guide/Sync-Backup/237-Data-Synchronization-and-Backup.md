# Data Synchronization and Backup

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjM3In0=

The UGOS Pro system offers powerful data synchronization and backup features, making it easy to manage and protect your important data. With these tools, you can seamlessly synchronize data between local and remote UGREEN NAS devices, ensuring that data across devices remains consistent and avoiding version conflicts. The backup feature adds an extra layer of security, protecting your data against potential loss due to unexpected events.

### Advantages of Data Synchronization and Backup

The synchronization feature in UGOS Pro enables seamless data syncing between local and remote UGREEN NAS devices. Updates made on one device are automatically reflected on all connected devices, ensuring consistent and conflict-free data across your network.

In addition, the system’s backup feature offers flexible options for selecting backup destinations, such as local UGREEN NAS, file servers, PCs, and mobile devices like smartphones. These versatile backup options provide secure storage for your data in various scenarios and ensure it can be restored whenever needed.

### The Overview Page

The [**Overview**] page in UGOS Pro gives you a clear snapshot of your sync and backup activities, along with detailed information about connected devices and their online status. Whether it’s local or remote UGREEN NAS devices or remote file servers, the page provides a centralized hub for monitoring and managing your setup. You can easily add or remove device connections as needed, making device management seamless and efficient.

If you are an administrator account user, you can enable**Administrator Mode**under**Sync & Backup**>**Administrator Settings**>**General**to view and manage device connections for other users.

It’s important to note that deleting a device connection will also remove all sync and backup tasks associated with that device. Before proceeding with the deletion, carefully review and confirm to ensure no critical data tasks are affected.

![](https://ugreen-pro.oss-cn-shenzhen.aliyuncs.com/ugreen-pro/admin/article/20241212/9310faf8-d977-4372-bb88-f0bc52d4eaed.png)

Regularly performing data synchronization and backup not only enhances data security and reliability but also improves efficiency and minimizes potential losses caused by data loss or version conflicts. By properly configuring sync and backup tasks, you can automate data management, reduce the complexity of manual operations, and ensure your data is always in optimal condition.
