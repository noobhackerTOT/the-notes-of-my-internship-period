# Task Manager

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjI3In0=

## Feature Overview

The "**Task Manager**" allows you to easily monitor system resource utilization rate and performance. You can view charts for CPU, GPU, Memory, Network, Hard Drive, and Volume. It provides real-time monitoring of resource usage for each service or process, as well as trend graphs of overall resource utilization, offering comprehensive tools to manage your system efficiently.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/db40caeb295445de851602d70355088d.webp)

## Runing Status

On the "**Overview**" page, charts for CPU, GPU, Memory, Network, Hard Drive, and Volume are displayed, showing current resource usage data.

Hover over any chart to see detailed information for the selected date, time, and metrics.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/383206bc967849b9b2e121990b5ade34.webp)

### CPU

Displays real-time CPU utilization rate and temperature. Hover over the chart to see the CPU utilization rate and temperature for specific time intervals.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/c6b7058139524f528703528815363789.webp)

### GPU

Displays real-time GPU utilization rate. Hover over the chart to see GPU utilization for specific time intervals.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/2a7a270e20fd4000885eae43131f4dcf.webp)

### Memory

Displays total physical memory and its usage structure. High memory usage may occur because the system stores frequently accessed data in cache for faster retrieval without accessing the drive.

When overall memory is insufficient, cached memory will be released. Excessive memory usage can impact system performance. Hover over the chart to see physical memory usage for specific time intervals.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/42d7128bcf5749019638f6627647abca.webp)

### Network

The network traffic chart displays data transfer and reception rates in bytes per second (B/s).

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/f495276dd5714d8d9897fca45d0ad4ef.webp)

### Hard Drive

Click the drop-down menu in the upper-right corner of the chart to select hard drive, transmission performance, or utilization rate. Selecting different hard drive will display information specific to each drive. Hover over the chart to see hard drive utilization for the selected time period.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/b2891ff87150448a947967301176861d.webp)

### Volume

Click the drop-down menu in the upper-right corner of the chart to select volume, transmission performance, or utilization rate. Selecting different volume will display information specific to each volume unit.

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/571e90241f1741c3a59b926b7b17f7b9.webp)

## Service/Process

● **Service**: On the "**Service**" page, you can view all currently running services. Click a service name to "**Restart**" or "**Disable**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/6697277b81fa47338bb517bc81a873e3.webp)

● **Process**: On the "**Process**" page, you can view all currently running processes. Click a process to "**End Process**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-05/aca94b0ce09543079738ec34701ec445.webp)
