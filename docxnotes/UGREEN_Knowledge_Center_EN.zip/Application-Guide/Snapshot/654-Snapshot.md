# Snapshot

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNjU0In0=

The Btrfs **snapshot function** on UGREEN NAS is an efficient, flexible, and resource-saving data management solution designed to protect your system from accidental changes, file deletions, virus attacks, and complex backup and recovery needs.

# What is a Snapshot?

Snapshots use incremental snapshot and copy-on-write (CoW) technology to record the complete state of data at a specific point in time (when the snapshot is taken) while minimizing storage usage.

Think of it as creating time-stamped backups for your data. You can take snapshots of shared folders on Btrfs storage and restore them to their previous state when needed.

This allows you to quickly recover data from any historical point, protecting against accidental deletion, software failures, data corruption, and virus attacks.

# Use Cases

Snapshots are like "instant photos" for your files, ideal for:Frequently accessed but rarely modified files (e.g., photo/video libraries)or shared folders containing important documents.

**Note:**Frequently modified files (e.g., ongoing downloads) will consume additional storage space.

## Daily Usage Scenarios

**If any of the following accidents occur**, you can enter the snapshot list, select the target folder, and restore it to the most recent snapshot:

● Accidentally deleted a baby’s growth photo album.

● Overwritten an important work document by mistake.

## Usage Tips

● Family Shared Albums: Create weekly snapshots + retain special versions at the end of each month.

● Storage Management: Set a 60-day auto-cleanup policy (keep snapshots from the last two quarters).

# Functional Limitations & Supported Objects

## Compatibility Restrictions

1. File System Requirement:Snapshots only work on storage pools formatted with **Btrfs**.You can check the file system in the Storage Management app.

![](https://file1-cn.ugnas.com/admin/article/2025-06-26/5faf6d64ee244f72aab7c512aef32a45.webp)

2. **Incremental Snapshots:** Each snapshot only records changes from the previous one.

3. **Copy-on-Write (CoW)**: Data is copied only when modifications occur.。

## Supported Snapshot Targets

The following are specific objects for which snapshots can be created:

1. **Shared folders under Btrfs storage (including the Recycle Bin).**

2. **Personal user folders under Btrfs storage (including the Recycle Bin).**

3. **Domain user folders under Btrfs storage (including the Recycle Bin).**

## Snapshot Quantity Limits

| Condition | Max Snapshots per Device | Max Snapshots per Shared Folder |
| --- | --- | --- |
| RAM ≥ 2GB | 65536 | 1024 |
| RAM < 2GB | 4096 | 256 |

## Snapshot Storage Location

Snapshots are stored in: /volumeX/@snapshot/[folder_type]/[folder_name]/[snapshot_file] ， volumeX refers to the storage volume where the folder resides.

### Important Notes

● Ensure your UGOS Pro system has sufficient storage for snapshots.

● Regularly check snapshot schedules and execution status to maintain data security.

● Before restoring or cloning, understand the impact on data and permissions.

● Admin privileges are required; standard users cannot use this feature.

# Using the Snapshot Function

Manual Snapshots is ideal for pre-planned backups before critical updates or operations.

1. Open the "**Snapshot**", select the target folder, and click "Take Snapshot."

![](https://file1-cn.ugnas.com/admin/article/2025-06-26/ed48d00368154ff6a2171bd8aab4e749.webp)

2. Add a description and "confirm". The system will start creating the snapshot.

![](https://file1-cn.ugnas.com/admin/article/2025-06-26/271b31141e37401598aef8cd3e81e52e.webp)

3. Once completed, you can view all snapshots in the Snapshot List.

![](https://file1-cn.ugnas.com/admin/article/2025-06-26/d1c9037f4a844a598ae92e87549e54a8.webp)

## Configuring Snapshot Schedules & Retention Policies

Automatically create snapshots at fixed intervals (daily, weekly, monthly) for continuous data protection.

1. In the Snapshot app, select a folder and click [Settings].

2. Enable "Snapshot Schedule."

3. Set the snapshot schedule, date, and initial execution time. The system will automatically take snapshots at the set frequency based on the configured plan.

4. Enable retention policies to manage snapshot count and storage usage.

5. Confirm and apply changes.

![](https://file1-cn.ugnas.com/admin/article/2025-06-26/fdb53ea8cd2b4a50893a0efa40c7f951.webp)

### Recommended Policy Settings

| Setting | Description | Recommended Value |
| --- | --- | --- |
| Frequency | Supported Scheduling Options:Daily/Weekly/Monthly | Monthly (to save space) |
| First Run Time | Set Scheduled Start Time | Off-peak hours (e.g., 2–4 AM) |
| Retention Policy | Keep snapshots for X days/count | Last 7 days OR latest 5 snapshots |

### Snapshot Schedule Notes

● Ensure the NAS is **powered on** during scheduled snapshots.

● Adjust frequency based on storage capacity to avoid excessive usage.

# Snapshot Retention Policies

The snapshot feature allows users to automatically maintain snapshots by specifying either the quantity to retain or the retention time period, preventing storage waste caused by excessive snapshot numbers or overly long retention durations.

## Setting Retention Policies

Users can set two types of retention policies based on actual needs:

● **Retain by Snapshot Count:** Specify the maximum number of snapshots to keep. When the created snapshots exceed the set limit, the system will automatically delete the oldest snapshots.

● **Retain by Time Period:** Define the retention duration for snapshots. When a snapshot's creation time exceeds the set retention period, the system will automatically delete expired snapshots.

For example, users can configure the system to set maximum retention to 10 snapshots or configure 30-day retention period.This ensures optimal storage utilization while maintaining backup integrity.

## Auto-Cleanup Mechanism

To ensure efficient operation of the snapshot maintenance system, automatic cleanup of non-compliant snapshots occurs at two trigger points:

● **When the snapshot service starts**

When the device reboots or the snapshot service is enabled, the system automatically checks the current snapshot count and creation time.

If the snapshot count exceeds the set maximum limit or the creation time exceeds the retention period, the system will automatically delete the corresponding old or expired snapshots.

● **When manually creating snapshots/scheduled snapshots are triggered**

When users manually create snapshots or scheduled snapshot tasks are triggered, the system will also perform a snapshot cleanup operation to remove unnecessary snapshots and free up storage space.

**Note:** After snapshots are deleted, the space they occupied will be reclaimed after a waiting period.

### Retention Policy Types

The snapshot retention policy mainly includes the following types:

● **Retain by Snapshot Quantity**

Users can choose to retain a specific number of the most recent snapshots. For example, set to retain the latest 5 snapshots. In this mode, when new snapshots are created, the system will automatically delete the oldest snapshots in chronological order, ensuring only the latest 5 snapshots are retained.

● **Retain by Retention Period**

Users can also set to retain all snapshots taken within a specific number of days. For example, set to retain all snapshots from the past 30 days. When a snapshot's creation time exceeds 30 days, the system will automatically delete these expired snapshots.

**Note:**The policy only applies to **unlocked snapshots**. Snapshots manually locked by users will not be subject to the quantity restrictions specified in the retention policy.

## Restore and Clone

**Function Description**

● **Restore Function**: Allows users to revert folders to previous states, including data and permission settings. Suitable for recovering data lost due to accidental deletion or modification.

● **Clone Function**: Creates an exact copy of a folder, including all data and permission settings. Ideal for duplicating folder structures and contents to new locations.

### Supported Objects for Restore and Clone

| Function/Folder Type | Restore Function | Clone Function |
| --- | --- | --- |
| Shared Folders | - Fully restores data, permissions, shared directory quotas, and user access rights - Ensures complete restoration to the snapshot state | - Supports cloning - Cloned copies retain identical data, permissions, quotas, and user rights |
| Personal Folders | - Restores data, permissions, and user quotas - Maintains file security and integrity | - Cloning not supported |

### Differences Between Restore and Clone

| Feature | Supported Folder Types | Function | Overwrites Original Data | Usage Recommendation |
| --- | --- | --- | --- | --- |
| Restore | User folders, Shared folders | Restores data to the state at a specified point in time | Yes | For undoing mistakes or data recovery |
| Clone | Shared folders only | Creates an independent copy while retaining snapshot data | No | For backup or data comparison |

**Note:**Shared folders containing network-mounted folders cannot be restored. Unmount network folders before proceeding.

### Restoring Snapshot Data

In the **snapshot** list, select the target snapshot.Click [···] >"Restore" to revert to the snapshot state.

### Cloning Snapshot Data (Shared Folders Only)

In the **snapshot**list, select the target snapshot.Click [···] > "Clone" to create a new shared folder with the copied data in the same storage space.

## Deleting Snapshots

Select **snapshots** in the list, click [···] > "Delete".For batch deletion, hold Shift/Ctrl to multi-select.

**Note:**Locked snapshots require manual deletion confirmation.

![](https://file1-cn.ugnas.com/admin/article/2025-06-26/73c7ecf02daf4653ad0ed722b0f17307.webp)

# Snapshot Storage Principles

## ​How Snapshots Use Space?

● **Core Logic:**Snapshots act as "time machines" preserving pre-modification states.

● ​**When Files Are Modified:**​ System archives original data blocks (like saves),then new data overwrites original locations

● ​**When Files Are Unmodified:** Minimal space usage (only original data stored)

```
Original Data (Snapshot 1): [A][B][C][D]
Modified Data (Snapshot 2): [A][X][C][D] (B→X)  
Snapshot 1 saves [B]; Snapshot 2 uses no extra space (matches current data)
If [A][X][C][D] is deleted, both snapshots store [A][B][X][C][D]

If [A][X][C][D] is deleted, both snapshots store [A][B][X][C][D]
```

## When Does Snapshot Storage Spike?

| Factor | Impact | Analogy |
| --- | --- | --- |
| Frequent File Changes | Each edit/deletion stores old data, increasing snapshot size | Like repetitive game saves bloating save files |
| Excessive Snapshots | More snapshots = more unique data blocks stored | Keeping 100 saves vs. 3 recent ones |

## Why Btrfs Snapshots Save Space?

● **Traditional Backup**: Full copies (100% storage per backup).

● **Btrfs Snapshots**: Only stores modified/deleted data (incremental).

## ​Why Isn’t Space Usage Obvious?

Storage consumption **grows stealthily**—minor changes seem harmless until accumulated.​

## ​How to Optimize Snapshot Storage Space?​​

**Reduce Snapshot Quantity**.Regularly purge older snapshots (e.g., retain only the most recent 7 days' worth)

Snapshot Space Consumption = Modification Frequency × Number of Modified Files × Total Snapshot Count

Btrfs achieves significant space savings through incremental backup technology, but requires proactive management to prevent gradual disk saturation.
