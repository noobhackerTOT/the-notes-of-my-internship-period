# Surveillance Center User Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODY2In0=

**Applicable models**: DH series, DX series, and DXP series**Applicable clients**: UGREEN NAS PC client and web browser**Applicable version**: UGOS Pro firmware 1.15.12.0051 and laterThe screenshots in this article are for reference only. The actual interface may vary slightly depending on the system or app version. Please refer to the actual interface.

## App Overview

**Surveillance Center**is a professional security monitoring app that turns your NAS device into a powerful network video recorder (NVR). You can use this app to add IP cameras, record videos, play back historical recordings, and manage user access permissions.

## Installation and Access

1. Open "**App Center**" and find "**Surveillance Center**".

2. Click "**Install**" and follow the on-screen instructions to complete the setup.

3. Once installed, click the icon on the desktop or in "**All**" to open it.

## Add Cameras

Surveillance Center is compatible with the standard ONVIF protocol and supports most mainstream IP camera brands on the market.

After entering the app interface, you can add cameras in either of the following ways: "**Search camera**" or "**Add manually**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/6bf78da4f8cc47f48b6521c34751a1dc.webp)

### Method 1: Search Camera

1. Click the "**Search camera**" button. The system will automatically search for cameras on the LAN that support and have enabled the ONVIF protocol.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/381ee9330b4948829465bfd50727835d.webp)

2. Select the target camera, then enter the username and password for authentication.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/13c288a488e84da4a75d789ced3d71dc.webp)

3. Once verified, set the camera's "Video storage location", "Retention period", "Capacity limit", "Event type" (such as all events), and "Location" (such as bedroom). Then click "**OK**" to finish adding the camera.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/86d7955736ae451eb5e4b4a22e2486d2.webp)

### Method 2: Add Manually

If the camera is on a different network segment, it may not be found through automatic search. In this case, you can add it manually.

1. Click the "**Add manually**" button.

2. Select the protocol type (ONVIF, for example), enter the camera's "**IP address**", "**Username**", and "**Password**", then click "**Next**" to connect.

**Note:**ONVIF/RTSP protocols are communication methods used by cameras. Select the protocol supported by your device.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/7dcc8211e2b4448caf7939152485ab83.webp)

3. **Optional**: Once connected, if the camera has multiple channels, select the channel you want to add on the camera settings page, then click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/082a6660ddc943dbbaf57a63d6932d45.webp)

4. Set the camera's "Video storage location", "Retention period", "Capacity limit", "Event type" such as all events, and "Location" such as bedroom. Then click "**OK**".

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/c687448bff584507a7cdac2452ffbc2a.webp)

5. Click "**Done**". The camera is added successfully.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/62e5ae7083034c1cbc355f7b18908eb6.webp)

**Note**: To add more cameras, click the "**+**" button on the left side of Surveillance Center.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/f7258711bf894ba4b9bd6db9e171814a.webp)

## View Live Monitoring and Playback

### Live Monitoring

On the app homepage, you can view the live feeds from all cameras. Cameras will also start recording automatically.

● Supportsswitching between multiscreen view and single-camera view.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/3bdb1beea0ec48b98568b118421e01d8.webp)

● In multi-channel mode, you can view all channels or switch to a specific channel.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/ba9bb9ce9c1f4164a489d5cca7b779dc.webp)

● Hover over the video feed to mute or unmute audio, adjust the video resolution, take screenshots, and hide or show Pan-Tilt-Zoom controls, if available.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/85d3c024e2e54aa59206e50c245bc29f.webp)

● Supports remote control of the camera direction using Pan-Tilt-Zoom. The camera must support this feature.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/44e3c6e3c33d4e98b337e8671ae583a4.webp)

### Video Playback

Double-click the live feed of a specific camera. You can drag the progress bar at the bottom to view recordings, or click the "Replay" button above the timeline to switch between "**Live**" and "**Replay**". In replay mode, you can select a playback speed from 0.5X to 16X.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/8e56ea0019c141e492138b9a768c2902.webp)

● Click the**date**in the lower-left corner to open the calendar and jump to a specific time. Dates with recordings are marked, and you can drag the progress bar to view recordings.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/6acb5033c0e0487e96ddf21afce0ef19.webp)

## View Recent Events

● Click the "**Recent events**" button on the right side of the camera feed to view recordings for that camera across "All times", including the past 15, 7, or 3 days, or a "Specified date". You can view all recordings or event-only recordings, depending on the event storage type set when the camera was added. You can also filter recordings by identity, such as "Stranger" or "Familiar person".

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/6719aea9ca024f0d9b34d18f3f6455bb.webp)

## Video File Management

By default, the system generates a new recording file every 10 minutes. On the homepage, select the target camera and click "**View videos**" in the upper-right corner to display the list of recorded videos.

● Click the **time** to switch dates.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/e008f883999f43e58956fb66b58613f7.webp)

● Supports filtering the recording list by channel, if multiple channels are available.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/f7f28526baf547ea88f99b8b44ae7e24.webp)

● Click the "**Edit**" icon and select multiple recording files to archive them in batches by copying the files to a specified NAS folder, download them to your local device, or delete them.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/4a4e62e5c7ca4efcb18738819952a1c7.webp)

● Click the "**Filter**" icon to filter recordings by "**All videos**" or "**Events only**". Event-only recordings can also be filtered by event type.

**Additional note**:**Event recordings**are video clips that are specially marked as "**Events**" when the camera detects an abnormal situation. The 9 supported event types are: "Fire detection", "Detection zone entry", "Detection zone exit", "Face detection", "Scene change", "People detection", "Vehicle detection", "Package detection", and "Pet detection".

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/26a333a788b648ea849be5be3876b781.webp)

● Supports viewing the recording list between "**Grid**" view and "**List**" view.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/8a6d03aa470546d3acc46efa869e78da.webp)

### Sort Multiscreen Layout

On the app homepage, select the "**Multiscreen**" display area. For a multi-channel camera, click the "**Sort**" icon in the upper-right corner, then drag the channels to adjust their order.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/32bda563481f404a9f4eb0e844236bf2.webp)

### Camera Settings

On the app homepage, select the target camera and click "**Camera settings**" in the upper-right corner.

**General**:You can modify the "Video storage location", "Retention period" (for example, automatically overwrite recordings after 7 days), "Capacity limit" (for example, automatically delete the earliest recordings when 500 GB is reached), "Event type" (all recordings or events only), and "Location".

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/8bf11e9edaab423eb070a81b6ca172f0.webp)

**Camera management：**For multi-channel cameras, you can remove a single channel or remove the entire camera.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/1001d06ed80244eba66165c420a07c4d.webp)

**Note**: Removing a device does not delete its historical recording files by default. To view them, go to "**Video files of removed camera**" at the bottom of the left sidebar on the homepage.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/142842f4647c4f1b934ecfdedb6db66f.webp)

## General Settings

Administrators can set access permissions and notifications for Surveillance Center on the General settings page. Access permissions let you assign permissions to regular users, while notifications alert users when an event is detected.

**Access Permission Settings**

1. Click the "**Settings**" icon in the lower-left corner.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/84c72566bb59446d91c78ca776866834.webp)

2. Select "**Surveillance Center access permissions**", choose the target regular user, and select the required permission:

● **View only**: The user can view live monitoring and playback, but cannot change any settings.

● **Access denied**: The user cannot open Surveillance Center.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/315f0961693a4d03b56c22a4e6099a5c.webp)

**Notification Settings**

On the **General settings** page, select "**Surveillance Center notification**" and choose which notification types to enable. When an event is detected, the system will automatically send a notification.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/42e790bda09d4127bcad7cc583536364.webp)

## Additional Notes

### Playback Compatibility

If you are using Edge or Firefox, you may see the message "**H265 encoded files are not supported**".

● **Cause**: The HEVC extension is not installed on your Windows system.

● **Solution**: Install the HEVC extension from Microsoft Store on Windows, or use the UGREEN NAS client to view the videos directly.

![](https://file1-cn.ugnas.com/admin/article/2026-06-17/d6f5f3bb3db14ce386764fbf6032f651.webp)
