# [FAQ] How to Solve the Issue When Hard Drive Status Shows as "Locked"

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjk2In0=

### **Problem Description**

In the Storage's Hard Drive page, the hard drive is shown as "**Locked**", and it cannot be formatted and used on the NAS.

### **Problem Diagnosis**

**Why is the hard drive status indicated as "Locked"?**

If the hard drive has been locked by another device before being placed into the UGREEN NAS, for example, a hard drive that was partially erased on another brand NAS, or if the device was shut down and restarted during the erasing process, it will display a "**Locked**" status when placed into the UGREEN NAS.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250730/58a87b38-5ca9-46d0-9498-60b0fa49865f.png)

### **Solution:**

**How to Unlock a "Locked" Hard Drive**

If your hard drive was locked due to a restart during the erasing process on the UGREEN NAS, you can follow these steps to unlock it:

1. Click on the "**···**" for thehard drive.
2. Select "**Data erasing**".
3. Wait for the erase to complete, after which thehard drivewill be unlocked and ready for use.
4. You can also contact UGREEN NAS technical support to obtain a tool for unlocking.

If your hard drive was locked by another device before being placed into the UGREEN NAS, it can only be unlocked on the original device before it can be used on the UGREEN NAS.
