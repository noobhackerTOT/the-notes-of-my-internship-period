# UGREEN NAS Storage Pool Expansion Guide (Replacing Drives One by One)

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODEwIn0=

Expanding a storage pool by "**replacing the existing drives with larger-capacity drives one at a time** "allows you to increase storage capacity while keeping your existing data intact. However, this process involves multiple RAID rebuilds and is considered a high-risk operation.

**Notes**:

● During the replacement of each drive, the storage pool will enter a "**Degraded**" state. At this time, data redundancy is temporarily lost. If another old drive develops bad sectors or fails during this period, all data may be permanently lost.

● The NAS must be powered off before removing a drive. Never remove multiple drives at once. Always follow the cycle "**Remove one drive>Insert a new drive>Complete the repair**" before proceeding to the next drive.

● It is strongly recommended to connect the NAS to a UPS (Uninterruptible Power Supply) to prevent power outages during the rebuild process, which could otherwise damage the file system.

## Applicable Scenarios and Prerequisites

Before starting, make sure your storage pool meets the following requirements:

1. **Supported RAID types**: This expansion method is supported only by RAID 1, RAID 5, RAID 6, and RAID 10. Basic, JBOD, and RAID 0 do not support this method. Replacing drives in those modes may result in data loss.

2. The storage pool must currently be in a "**Normal**" state. If it is already degraded or damaged, resolve the issue before proceeding.

3. The new drive must be equal to or larger than the old drive it replaces. For consistent performance, it is recommended to use NAS-grade drives with the same brand and rotational speed.

## Procedure

## Step 1: Perform a Full Data Backup

To protect against unpredictable hardware issues (such as URE – Unrecoverable Read Errors), it is strongly recommended to back up your data before starting.

● **Option A: Local Cold Backup (Recommended)**

Connect a USB external drive enclosure to the NAS as external storage and copy your important data to the external drive.

**Advantages**:Fast backup speed, easy recovery, and not affected by network conditions.

**Disadvantages**:Requires physical storage devices and may have storage capacity limitations.

● **Option B: Cloud or Off-site Backup**

Use apps such as "**Sync & Backup"** or**"Cloud Drives**" to upload data to a cloud storage service or another NAS.

**Advantages:**

● High flexibility — backup data can be accessed anytime and anywhere.

● Cloud services provide a certain level of data redundancy and security protection.

**Disadvantages:**

● Requires a stable network connection, and backup speed depends on network bandwidth.

● May incur additional cloud storage costs.

● Relies on third-party services, which may involve certain privacy and security risks.

## Step 2: Replace and Repair drives One by One (Repeat Cycle)

Please follow the sequence below strictly and perform the "**Disable**>**Replace**>**Repair**" cycle for each old drive in the storage pool.

### Phase 1: Locate and Replace the drive

1. Open the "**Storage**" app. In the left sidebar, click "**Hard Drive**", then identify the drive numbers included in the target storage pool (for example, drive 1, drive 4).

2. Select the old drive you want to replace. Click the "**···**" icon on the right side, choose "**Disable**"twice, then enter your account password and click "**Confirm**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-16/88bf600ce9844a1bad94938f27b2d1f8.webp)

**Note**: Once the drive is disabled, the storage pool will enter a "**Degraded**" state. The system may emit a warning beep, which can be disabled in the Control Panel.

![](https://file1-cn.ugnas.com/admin/article/2026-03-16/2eab7cb890a24a7188bc3f6ff7e2d060.webp)

3. Power off the NAS. Remove the disabled drive and insert the new larger-capacity drive. After ensuring the drive is properly installed, power the NAS back on.

### Phase 2: Repair the Storage Pool

1. After the NAS starts, open the "**Storage**" app. The system will notify you that the storage pool is degraded.

![](https://file1-cn.ugnas.com/admin/article/2026-03-16/6c9b33734d584a6f809992c6b7b1a497.webp)

2. Click the affected storage pool to enter its details page, then click "**Repair**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-16/c4cfe29b9edf46b883d4c373ddb46313.webp)

3. In the wizard that appears, select the newly inserted drive as the replacement drive and click "**Apply**".

![](https://file1-cn.ugnas.com/admin/article/2026-03-16/4fa4913ce8cc42eab72938acf8b6c702.webp)

4. Click "**Format**", enter your account password for verification, and click "**Confirm**". The system will then start the data rebuild process.

![](https://file1-cn.ugnas.com/admin/article/2026-03-16/766de52f8ff24d9487da698a57eed99b.webp)

**Notes**:

● Wait for the rebuild process to complete. This may take several hours to several days, depending on drive capacity and the amount of data.

● Do not remove the next drive until the progress reaches **100%** and the storage pool returns to the "**Normal**" state.

![](https://file1-cn.ugnas.com/admin/article/2026-03-16/95de074547ee41f59759691714f2f32d.webp)

### Phase 3: Repeat the Process

After the first drive replacement and repair is completed, repeat the "**Disable**>**Replace**>**Repair**"process for the next old drive in the storage pool. Continue until all old drives have been replaced.

### Phase 4: Expand the Storage Capacity

Once all drives in the storage pool have been replaced with larger-capacity drives and the final repair has completed:

1. Go to "**Storage**" app, and select "**Storage**" and check whether the storage pool capacity has been automatically updated.

2. If the storage pool has expanded but the storage volume capacity remains unchanged, locate the storage volume and click the "**···**" icon on the right side, then select "**Expand**". Extend the file system to the maximum available capacity, and click "**Apply**".

## Risk Notice

To help you fully evaluate whether this operation is appropriate for your environment, the following outlines the potential risks and underlying technical principles involved.

● **Secondary Failure Risk**

○ **Principle**: During RAID rebuilding, the system must perform intensive, full-drive reads on all remaining old drives to reconstruct the data. This process effectively acts as a stress test for the existing drives.

○ **Risk**: If one of the remaining drives contains latent bad sectors (which may not have been detected during normal usage), encountering such a sector during the rebuild may trigger an "**Unrecoverable Read Error (URE)**". This can cause the RAID rebuild to fail and may even lead to complete storage pool failure.

● **File System Failure Due to Power Loss**

● **Principle**: The rebuild process involves extensive metadata updates and parity calculations.

● **Risk**: If an unexpected power outage occurs during this process, it may cause logical sector corruption, potentially preventing the file system from mounting properly. It is strongly recommended to equip your NAS with a UPS (Uninterruptible Power Supply).

○ **Sector Format Compatibility Issues**

● **Principle**: Some large-capacity enterprise-grade drives use the 4Kn sector format, while older drives may use 512e.

● **Risk:** Mixing drives with different sector formats within the same RAID array may result in RAID creation failure or significant performance degradation. Please confirm compatibility with customer support before purchasing new drives.

○ **Time Cost**

● **Explanation:** Rebuilding more than 10 TB of data may typically take 10–20 hours or longer. If your storage pool contains four drives, the entire expansion process may take 3–4 days. During this period, NAS performance may be significantly reduced, which could affect normal usage.

## FAQs

**Q1: Why didn't the capacity increase after I replaced a drive?**

A: The capacity of a RAID array is limited by the **smallest** drive in the array. For example, in a RAID 5 array with three drives, replacing only one drive with a larger one will not increase the total capacity. The total capacity will increase only after **all drives** have been replaced with larger ones.

**Q2: If I remove one drive during RAID 5 expansion, will my data still be available?**

A: Yes. RAID 5 allows one drive to be missing. When a drive is removed, the system reconstructs the missing data in real time using the parity information stored on the remaining drives, so the data remains accessible. However, the array will no longer have fault tolerance during this time—if another drive fails, all data may be lost.

**Q3: Can I access files during the expansion process?**

A: Yes, files can still be accessed. However, because the system is performing intensive background data rebuilding, read and write speeds may become noticeably slower, and temporary lag may occur. This is normal behavior. To avoid extending the rebuild time, it is recommended to minimize large file read/write operations during the process.
