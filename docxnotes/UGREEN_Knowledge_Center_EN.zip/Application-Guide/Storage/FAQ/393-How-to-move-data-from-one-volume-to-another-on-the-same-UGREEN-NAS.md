# How to move data from one volume to another on the same UGREEN NAS?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzkzIn0=

In the "Storage" app of the UGOS Pro system, if you need to move data from one volume (e.g., Volume 3) to another volume (e.g., Volume 1), you can follow these steps.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250506/03985f0a-9634-42bb-b5a1-c6f3accdf765.png)

## **Steps**

Depending on the scenario, there are two methods for migrating data between volumes:

### **Scenario 1: Migrate volume data via [Personal Folder Management]**

1. Open the "Files" app, click the [Tools] icon, and select "Personal Folder Management."

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250423/152a522b-7aca-4485-9d48-04251c9054ec.png)

1. In the [Personal Folder Management] window, select the target volume from the "Location of Personal Folders" dropdown menu, then click "Ok."

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250423/b9cbfdfb-f43a-4b3a-8e63-b90b36973331.png)

1. Carefully read the operation risk warning, check the box "I understand the risks for this operation and agree to continue," then click "Continue" to start processing and moving the files.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250423/18535f27-3e7f-4bda-b977-d7d400572755.png)

Note: All services using this folder will be paused during the file migration.

### **Scenario 2: Migrate volume data via [Shared Folder Management]**

1. Open the "Files" app, click the [Tools] icon, and select "Shared Folder Management."

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250423/caad0419-1421-4a2f-99ea-e0545d23c244.png)

1. In the [Shared Folder Management] window, select the target shared folder for the volume you want to move and click "Edit."

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250423/95b02dfd-90d2-486f-850c-063e4ed4c401.png)

1. In the [General] settings, select the target storage space from the "Storage Location" dropdown menu, then click "OK."

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250423/13d0cc78-2ab6-40cb-9e72-e5f3dd5cfd35.png)

1. Carefully read the operational risk prompt, check the box "I understand the risks for this operation and agree to continue," and click "Continue" to start processing and moving the files.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250423/58962b8d-739b-4419-abd6-59b902860e13.png)

Notes:

1. Before data migration, make sure the remaining capacity of the target volume is sufficient.
2. Copying or moving operations within the same file directory are faster because the data is processed in the same physical location, reducing disk addressing and transfer time.
3. Copying or moving operations across volumes are slower because the data needs to be transferred between different physical locations, increasing disk addressing and transfer time. Additionally, operations across volumes may involve different file systems, further increasing the complexity and time of data processing. To improve efficiency, it is recommended to transfer large files in batches.
