# [Tutorial] How to Create Storage Pool and Volume?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDkzIn0=

A **Storage Pool** is a collection of hard drives managed through RAID technology, providing data protection and centralized storage resource management. A **Volume** is a logical storage unit created from a Storage Pool and can be directly used to store data. Multiple Volumes can be created within a single Storage Pool, and each Volume can have its own file system (e.g., Btrfs, EXT4).

**Note:**To create a storage pool, you must have at least one unused and healthy hard drive.

## Steps

1. Open the Storage and navigate to [Storage] > [Storage pool & volume].

2. Click [Create] > [Storage pool] to enter the storage pool creation wizard.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-10/ce9b512815894e6ebb9128e7690c0557.webp)

3. Select the hard drives and RAID type, then click "Next." Different RAID types offer varying levels of data protection and functionality; refer to "[How to Choose RAID](https://support.ugnas.com/knowledgecenter/#/detail/eyJ0eXBlIjoidGFnMDA0IiwibGFuZ3VhZ2UiOiJlbi1VUyIsImlkIjo5MDksImFydGljbGVJbmZvSWQiOjMwMiwiY2xpZW50VHlwZSI6IlBDIiwiYXJ0aWNsZVZlcnNpb24iOiIiLCJwYXRoQ29kZSI6IiJ9)" for guidance.

4. Optionally, choose whether to perform a disk check and click "Next".

![](https://file-cn-test.ugnas.com/admin/article/2025-09-10/3cf03fbb39b542a3aa444cf892efd2c5.webp)

5. After creating the storage pool, the system will automatically create a volume. You need to set the volume capacity (default is the maximum available capacity, but you can adjust as needed) and select a file system. Then, click "Next" to proceed.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-10/9ba400204d32484cbb2dc8301a0d0577.webp)

6. Click "Create" to begin initialization.

**Note:**Initialization will format the hard drives, so make sure to back up important data before proceeding.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-10/0198d34b51ec453f8c2764af7b173556.webp)

7. After confirming the risk warning, click "Format", enter your password to verify, and click" Confirm" to complete the creation process.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-10/786066775402474db96dbbd4319deb47.webp)

![](https://file-cn-test.ugnas.com/admin/article/2025-09-10/a4ab303f3e9a41d99d53eab86383f20a.webp)

8. You can continue creating volume based on the remaining capacity of the storage pool. Click **"···"** on the right side of the storage pool and select [Create Volume] to repeat the above steps.

**Note:**Ensure the remaining capacity of the storage pool is greater than 10GB to create a new volume.

![](https://file-cn-test.ugnas.com/admin/article/2025-09-10/6f05237d1807412ea7cad51f73e7993f.webp)

## Related Links:

[[FAQ] The relationship between physical disks, storage pool, and storage space](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6MTI1NywidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiZW4tVVMiLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo0MTgsImFydGljbGVWZXJzaW9uIjoiIiwicGF0aENvZGUiOiIifQ==)
