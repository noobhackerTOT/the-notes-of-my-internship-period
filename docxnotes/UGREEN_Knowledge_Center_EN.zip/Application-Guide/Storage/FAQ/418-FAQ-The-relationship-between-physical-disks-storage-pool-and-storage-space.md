# [FAQ] The relationship between physical disks, storage pool, and storage space

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDE4In0=

In the UGOS Pro system of UGREEN NAS,**physical disks, storage pool, and storage space**are the three core concepts for building and managing data storage. They are closely related, and understanding their relationships is crucial for optimizing NAS configuration, enhancing data security, and improving system performance.

![](https://ugreen-pro.oss-cn-shenzhen.aliyuncs.com/ugreen-pro/admin/article/20241017/3ba9657f-cc05-4033-af25-3f6ed9516d91.png)

**Physical Disks**

Physical disks are the physical devices that actually store data. The UGOS Pro system supports both Hard Disk Drives (HDD) and Solid State Drives (SSD). The primary role of physical disks is to provide basic storage capacity. To flexibly expand storage space and enhance data security, the system allows multiple physical disks to work simultaneously.

Common physical disk configurations include:

- **HDD (Hard Disk Drive):**Large capacity, cost-effective, suitable for massive data storage.
- **SSD (Solid State Drive):**Fast speed, ideal for scenarios requiring high-performance reading and writing, such as running virtual machines or Docker.

**Storage Pool**

A storage pool is a virtual storage pool created by combining one or more physical physical disks through**RAID**(Redundant Array of Independent Disks) technology. The core function of a storage pool is to integrate the storage resources of physical disks to ensure data redundancy protection and improve storage efficiency.

Different RAID modes provide the following functions through storage pools:

- **Performance Optimization:**For example, RAID 0 stores data blocks across multiple physical disks, enhancing read and write speeds.
- **Data Redundancy:**For example, RAID 1 ensures that even if one physical disk fails, data is not lost through data mirroring.
- **Storage Space Utilization:**RAID 5, RAID 6, and other modes improve data security without losing a significant amount of capacity by storing data slices and parity information.

**Storage Space**

Storage spaces are the logical areas where users operate and manage data. After creating a storage pool, users can divide one or more storage spaces on the storage pool, similar to partitioning a physical disk in a Windows system. For example, a user can split a storage pool into storage spaces for different purposes, such as storing personal files, shared files, or application data.

Each storage space is equivalent to an independent "virtual physical disk," allowing users to flexibly allocate and manage storage resources as needed. The advantages of storage spaces in the UGOS Pro system include:

- **Flexible Data Management:**Users can divide different storage spaces according to application needs, facilitating the independent management of different data.
- **Access Control:**Enhance data security by assigning access permissions to different users and applications.
- **Quota Management:**Administrators can set capacity quotas for each storage space to prevent resource waste.

### **The relationship among the three is summarized as follows**

1. **Physical disks to Storage Pools:**Physical physical disks are added to storage pools, and the system combines them into a whole according to RAID configurations for performance enhancement or data redundancy. Different RAID modes determine the capacity utilization and data security level of the storage pool.
2. **Storage Pools to Storage Spaces:**After the storage pool is created, the system allows dividing it into multiple storage spaces for actual use by users, equivalent to virtualized physical disk areas. Different storage spaces can be used for different tasks or users, achieving independent data management.
3. **Storage Spaces to User Data:**Storage spaces are the logical areas where users store data. Users can create folders, upload files, and set access permissions and capacity limits within the storage spaces. Data is managed through the file system, ensuring the optimized use of storage resources.

### **Additional Notes**

- **Data Security and Redundancy:**The RAID redundancy mechanism ensures that even if some physical disks fail, data can be recovered, thus guaranteeing business continuity. For critical data, it is recommended to choose RAID 5 or higher RAID levels.
- **Performance Optimization:**In high-performance application scenarios, such as running Docker or virtual machines, an SSD storage pool can significantly improve system response speed and further enhance read-write efficiency.

### **Storage Space and Folder Management**

In the UGOS Pro system, a**storage space**is equivalent to a virtualized physical disk partition or logical volume. Users can create multiple folders within each storage space according to their needs for file classification and management. Different folders can provide dedicated storage areas for different applications, users, or tasks.

#### **1. Creation and Purpose of Folders**

- **Flexible Data Organization:**Users can create any number of folders within each storage space to store different types of data. For example, you can create folders for personal files, company project files, video or multimedia materials, etc.
- **Data Classification Management:**Dividing folders within a storage space can effectively classify and manage data, improving the efficiency of finding files and providing a better organizational structure for different types of data.
- **Access Control:**You can set individual access permissions for each folder, ensuring that different users or user groups only access folders related to their work. For example, you can set up dedicated folders for different departments within a company, controlling the data access permissions among employees.

#### **2. The Role of Folders in Conjunction with Storage Spaces**

- **Storage Quotas:**Within a storage space, administrators can set quotas for each folder or group of folders, limiting their storage capacity and preventing one folder from occupying too many resources and causing insufficient space in other folders.
- **Backup and Sync:**The UGOS Pro system supports automatic backup and synchronization of folders within storage spaces. Regular backup schedules ensure data safety, and folders can be synchronized with remote servers or other devices, enhancing data availability.
- **Cross-Platform Access:**Folders within storage spaces can be accessed in various ways, such as through SMB/CIFS, FTP, and other protocols, allowing users to flexibly access data in folders on different devices and providing a convenient cross-platform file management experience.

#### **3. The Relationship Between Folders and Storage Spaces**

- **Storage space**provide a logical "container" where users can create and manage folders.
- **Folders**, as the basic units of storage spaces, are the direct objects for user operations and data storage. Each folder is equivalent to a directory in a daily operating system, and users create folders to divide data.
- **Data Sharing:**Multiple users can share a storage space, but manage their data independently through folders, ensuring that different users' data does not mix or conflict.
