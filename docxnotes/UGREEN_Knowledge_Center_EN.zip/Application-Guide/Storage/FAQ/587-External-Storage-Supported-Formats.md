# External Storage Supported Formats

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTg3In0=

### **Supported File System Formats:**

- **Linux File Systems:**btrfs, ext2, ext3, ext4
- **Windows File Systems:** vfat, exfat, FAT16, FAT32, NTFS
- **Other File Systems:**XFS

### **Unsupported File System Formats:**

- HFS+, APFS (primarily macOS exclusive file systems)
