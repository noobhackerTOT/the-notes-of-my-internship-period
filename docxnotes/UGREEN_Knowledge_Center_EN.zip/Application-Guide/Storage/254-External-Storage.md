# External Storage

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMjU0In0=

**Applicable Version:** UGOS Pro 1.10.0.0092 and above.

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## Feature Overview

In the [External Storage] interface, you can view detailed information about the mounted external storage devices, including:

● Hard drive manufacturer and product name

● Total capacity and used capacity

● Partition file system format (e.g., ext4, NTFS, etc.)

## Manage Mounted External Storage Devices

Through the [External Storage] page, you can perform the following actions:

● Open files

● Format external storage

● Remove external storage

### Access External Storage Files

Click the "**···**" button on the right side of the device, select "**Open**," and you will be redirected to the [Files] app to view the storage contents.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/0364af53fdcc4e779f8fa9f75446aa1b.webp)

### Format External Storage Device

1. Click the "**···**" button on the right side of the device, then select "**Format**."

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/51c706cf417d4e4f8722b74d5829ac82.webp)

2. In the [Format] window, select the object to format (supporting formatting of either the entire hard drive or a single partition) and the file system. After setting, click "Confirm."

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/747c53a850a7452eb23f22848402e238.webp)

UGREEN NAS supports formatting external hard drives to NTFS, FAT32, exFAT, and ext4 formats. Below are the recommendations for selecting a file system:

● **NTFS**：Suitable for Windows systems, supports large capacity hard drives and large files, with file encryption and permission management features.

● **FAT32**：Compatible with both Windows and Mac systems, but limited in drive capacity and individual file size (maximum 4GB).

● **exFAT**：Suitable for both Windows and Mac systems, supports large capacity hard drives and large files, with good compatibility.

● **ext4**：Suitable for Linux systems, supports large capacity hard drives and large files, with stable performance.

3. Read the risk prompt and click "**Confirm**."

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/ef8c71f2e71043acb6525e3a7be53b96.webp)

**Note:**Before formatting the external hard drive, make sure to back up important data. Formatting will delete all data and it cannot be recovered.

### Remove External Storage Device

1. Click the "···" button on the right, select "Remove," and then remove the storage device. After removal, the device will no longer appear in the External Storage.

2. To remount a removed device, you can either re-plug the storage device or restart the NAS system. The system will automatically attempt to remount it.

## Advanced Settings Options

In the advanced settings of [External Storage], you can further optimize the performance or permission configuration of the storage device.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/7d8e6d3d978b4a6398df160bb7de0a3a.webp)

● **ext4 latency configuration**: Once enabled, write performance can be improved. However, please ensure that the external device is properly removed, otherwise data may be lost.

● **Disable USB storage devices**: After disabling, the access of USB storage devices will be blocked, such as USB flash drives, external hard drives, SD cards, TF cards, etc.

● **External storage access permissions**: Set general users' default access permission to files in the external storage (including USB storage devices and external storage arrays).

## Supported External Storage Formats

Supported file system formats: btrfs, ext2, ext3, ext4, vfat, exfat, FAT16, FAT32, NTFS, XFS.

Unsupported file system formats: HFS+, APFS (primarily macOS exclusive file systems).

**Notes**

● For devices that require manual mounting, please follow the correct steps to mount them to avoid data loss or device recognition issues.

● Before removing a hard drive, be sure to use the system's "**Remove**" function to ensure the integrity of the stored data.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/ab8e84331a734737834a9d1ce3c4823e.webp)

## Unable to Format External Drives

If you attempt to format an external drive and the system displays "Unable to Format" or the button is grayed out, the issue may be caused by one of the following reasons:

**Possible Causes:**

● **The external drive or partition is currently being formatted.**

Please wait for the ongoing format task to complete before starting a new one.

● **Array devices do not support formatting external drives.**

If the drive is part of an array device (e.g., hardware RAID), the system cannot format it directly.

● **The external drive is locked.**

Some drives with encryption or write-protection features cannot be formatted until unlocked. Disable encryption or remove write protection first.

● **Drive is not detected or improperly connected.**

If the system does not recognize the drive or the connection is unstable, formatting will fail. Check the drive connection or reconnect the device.

**Note:**

If none of the above issues apply but formatting still fails, it is recommended to:

1. Reconnect the external drive and try formatting again.

2. Connect the drive to a computer for checking and repair.

3. Ensure the drive has no physical damage or partition issues.

## Related Links

● [Migrating Hard Drives to a New UGREEN NAS Device.](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6ODcxMSwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo3NjcsImFydGljbGVWZXJzaW9uIjoiMS4wIn0=)

● [Migrate Internal Storage Drives to a New UGREEN NAS Device](https://support.ugnas.com/knowledgecenter/#/detail/eyJpZCI6ODcxMSwidHlwZSI6InRhZzAwMiIsImxhbmd1YWdlIjoiemgtQ04iLCJjbGllbnRUeXBlIjoiUEMiLCJhcnRpY2xlSW5mb0lkIjo3NjcsImFydGljbGVWZXJzaW9uIjoiMS4wIn0=)

● [UGREEN NAS Products Compatibility List](https://nas.ugreen.com/pages/compatibility)
