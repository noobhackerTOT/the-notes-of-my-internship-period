# Change the RAID Type

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMzkyIn0=

**Applicable Version:** UGOS Pro 1.10.0.0092 and above.

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## Feature Overview

UGREEN NAS supports changing the RAID mode of a storage pool **without losing existing data**. For example, after adding enough drives, you can upgrade a RAID 1 storage pool to RAID 5 to achieve higher performance and better storage utilization.

Currently, UGREEN NAS supports **upgrading from Basic mode to RAID 5**. The supported upgrade path is as follows: **Basic → RAID 1 → RAID 5.**

## RAID Conversion Limitations

Not all RAID types can be converted between each other. The supported RAID upgrade paths on UGREEN NAS are as follows:

| Current RAID Type | Upgradable To | Additional Drives Required |
| --- | --- | --- |
| Basic | RAID 1 | 1 |
| Basic | RAID 5 | 2 |
| RAID 1 | RAID 5 | 1 |

**Notes:**

● JBOD and RAID 0 **do not support online conversion**. To change these RAID types, you must back up your data and recreate the storage pool.

● RAID types only support upgrading to higher levels; downgrading is not supported.

## Preparation Before Changing RAID Type

Before performing a RAID type change, please make sure the following conditions are met:

● The storage pool status is **“Normal.”**

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/40165beb68ba41ed9d088bd991228739.webp)

● At least one**unused and healthy**hard drive is available.

● The capacity of the new hard drive is **not smaller than** the smallest drive in the current storage pool.

● It is recommended that all hard drives be of the same brand, model, and capacity.

● Back up important data beforehand to prevent data loss in case of unexpected issues.

## Steps to Change RAID Type

1. Open **[Storage] > [Storage] > [Storage Pool & volume]**.

2. Locate the target storage pool, click the "**..."** icon on the right, and select **"Change RAID type"**.

3. In the pop-up window, select the desired RAID type and click **"Change"**.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/6c22960225cf474fb68f0d05d8e32344.webp)

If the current RAID type does not support conversion, this option will be grayed out.

4. Select the available hard drives to add, then click "**Next"**.

The added drives will be formatted. Please make sure to back up their data in advance.

5. Review the configuration details, then click **"Apply"** to start the RAID type change.

6. During the process, the storage pool status will display **“Changing RAID type.”** Once completed, the status will automatically revert to **“Normal.”**

## Note

● Changing the RAID type can be time-consuming and consumes system resources. It is recommended to perform this operation when the NAS is idle.

● Keep the device powered on during the RAID change process. Do not shut down or restart the NAS to prevent data corruption or loss.

● During the RAID conversion, some applications that depend on the storage pool may be temporarily inaccessible.

● If a hard drive fails during the process, the RAID type change will still complete, but the storage pool may enter a **“Degraded”** state.

![](https://file1-cn.ugnas.com/admin/article/2025-11-06/f45d650dabd5422ab412b24a530c32fa.webp)

● If the RAID type change fails, do not force a NAS restart. Check the detailed error information in **"Storage"** and contact technical support.
