# How to Fix the Issue Where Data Cannot Be Written Despite Available Free Space (Reclaim Storage Space)?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODU5In0=

## Applicability

**Supported Platforms**: UGREEN NAS PC Client and Web browser.

**Supported Versions**: UGOS Pro firmware version 1.16.0.0042 or later.

This document is for reference only. Actual interfaces and operation paths may vary depending on system or application version updates. Please refer to the actual interface displayed on your device.

**Requirements**: This feature is only supported on storage spaces using the Btrfs file system. (EXT4 is not supported.)

## Overview

During daily use, you may encounter a confusing situation where the storage space still shows sufficient available capacity, yet write operations repeatedly fail.

If you experience one or more of the following issues, it is usually caused by the underlying "**fragmentation mechanism**" of the Btrfs file system, where part of the space becomes locked and cannot be effectively utilized:

● **Application abnormalities**: Applications cannot be installed or enabled, and the system reports errors such as corrupted data or damaged application database files.

● **File operation failures**: File rename, move, or copy operations fail with errors such as "**File or directory does not exist**" or "**Insufficient space**".

● **Underlying system errors**: System-level commands such as `df` still show available space, but actual write operations continue to fail, and even the built-in "**Balance**" task cannot run successfully.

To eliminate issues caused by these underlying technical limitations, UGREEN NAS provides a dedicated"**Reclaim storage space**" feature that deeply reorganizes fragmented storage space and releases unusable hidden space.

## Use the Reclaim Storage Space Feature

1. Open the "**Storage**" application and click "**Storage**" in the left sidebar.

2. At the top of the main panel on the right, switch to the "**Storage pool & Volume**" tab.

3. Locate the target storage space experiencing write failures and confirm that its file system is labeled as Btrfs.

4. Click the "**...**" icon on the right side of the storage space block and select"**Reclaim storage space**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-28/abfad0c89f7e42eaa83c23cf9c9bcc72.webp)

5. In the confirmation dialog box, click "**Reclaim**". The system will then begin the fragmentation cleanup process.

![](https://file1-cn.ugnas.com/admin/article/2026-05-28/b6a9814308c04e4fb1eadcfab75ab41a.webp)

## Notes

The Reclaim Storage Space feature is a high-load I/O task that operates at the file system level. Before starting the operation, please be aware of the following:

● **Irreversible and cannot be interrupted**: Once the space reclaim task starts, it cannot be manually stopped midway. During execution, the volume status will continuously display "**Reclaiming**" until the task is fully completed, after which the status will return to "**Normal**".

![](https://file1-cn.ugnas.com/admin/article/2026-05-28/88373f4e99124812995329a8377b6521.webp)

● **System performance degradation**: During the task, you can still access the NAS and read/write files normally. However, because the drives are operating under heavy load, overall system responsiveness and file transfer speeds may noticeably decrease. It is recommended to perform this task during off-peak hours, such as at night.

● **Normal fluctuation of available capacity (temporary decrease followed by recovery)**: During the reclaim process, the system temporarily uses additional storage space as a "**staging area**" to reorganize fragmented data. As a result, available capacity may temporarily decrease before increasing again after the reclaim process is completed.
