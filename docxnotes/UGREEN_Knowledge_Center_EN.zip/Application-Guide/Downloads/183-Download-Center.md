# Download Center

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTgzIn0=

## Overview

The "**Downloads**" in the UGOS Pro system is an efficient and practical download management tool that supports multiple protocols and download methods, enabling users to conveniently manage various file download tasks. Whether downloading movies, music, documents, or large files, the "**Downloads**" provides automated downloading and centralized management.

The "**Downloads**" offers the following key features:

● **Comprehensive Download Options**: Supports multiple download methods including Torrent, Magnet, HTTP, and FTP, allowing users to download files, videos, music, and other types of resources. Integrated PT (Private Tracker) support enables management according to private tracker rules, allowing users to continue seeding after download to maintain resource stability.

● **Simultaneous Multi-Task Downloading**: Allows users to download multiple files at the same time, efficiently utilizing NAS storage and network resources to improve download efficiency.

● **Remote Management**: Manage and add download tasks remotely via the UGREEN NAS mobile app, enabling users to operate anytime and anywhere without time or location restrictions.

## Installing the Downloads

The Downloads is not a built-in system application. For first-time use, please go to the "**App Center**", locate "**Downloads**", and install the application.

![](https://file1-cn.ugnas.com/admin/article/2025-12-31/4a3225d4626c4f5a8fb7add389e29692.webp)

## Downloads Feature Overview

● **Multi-protocol support**: Supports Torrent, magnet links, HTTP, FTP, and other protocols.

● **Task management**: Supports batch adding, pausing, starting, and deleting download tasks.

● **Speed limits**: Allows setting global download and upload speed limits for tasks.

● **Torrent file management**: Supports importing `.torrent` files to download torrent resources directly.

● **Magnet link parsing**: Automatically parses magnet links and displays available resource content.

● **Task categorization**: Organizes download tasks by status (downloading, downloaded).

● **Notifications**: Provides system notifications when downloads are completed or when errors occur.

### Downloads Settings Description

![](https://file1-cn.ugnas.com/admin/article/2025-12-31/41cf1a39569e4cfa8def931df8c5fb88.webp)

● **Default Save Path**: Configure the default storage location for all completed download tasks.

● **Auto-Monitored Directory**: Specify a directory to monitor. When new `.torrent` or `.txt` files are detected in this directory, they will be automatically created as download tasks (subdirectories are not included).

● **Task Timeout Setting**: Define the period of inactivity after which a download task will be automatically canceled to prevent long-term resource consumption.

● **Concurrent Task Limit**: Limit the number of simultaneous download tasks. This can be configured globally or per user to prevent system resource overload.

● **Download Speed Limit**: Set the maximum download speed for HTTP, FTP, BT, and PT tasks, with support for time-based speed limiting.

● **Upload Speed Limit**: Set the maximum upload speed for BT and PT tasks, also supporting time-based speed limiting.

● **Protocol Port Settings**: Specify the peer communication port used for P2P connections.

● **Maximum Peer Count**: Limit the maximum number of peers a single download task can connect to, affecting download performance and upload control.

● **UPnP / NAT-PMP**: Enable or disable automatic port mapping to support automatic port forwarding in compatible network environments (recommended when supported by the router).

● **DHT Network Toggle**: Enable or disable the DHT network (decentralized peer discovery), which helps improve resource discovery for BT/PT download tasks.

● **Seeding Limits**: Configure seeding conditions (such as upload duration or ratio) to automatically control when a task stops seeding.

● **Tracker Server Configuration**: Add or edit the list of trackers used for BT/PT downloads to improve torrent resource discovery efficiency.

## Creating Download Tasks

1. Open the "**Downloads**" app and click the **"Create"** button in the top-left corner. You can add tasks in two ways:

● **Create from Download Link**: Enter or paste a link. You can paste multiple links at once to create multiple download tasks (supports HTTP, HTTPS, FTP, magnet links, etc.).

● **Create from Seed File**: Upload a `.torrent` file to create a download task.

2. After selecting the source, set the download save path, then click "**Confirm**" to start the download.

## Managing Download Tasks

● **Start / Pause Task**: Select a task and click the "**Start / Pause"** button.

![](https://file1-cn.ugnas.com/admin/article/2025-12-31/ccb31891ed164537a1be588b20f83018.webp)

● **View Task Details**: Click the task name to see progress, connection status, download path, and more.

![](https://file1-cn.ugnas.com/admin/article/2025-12-31/e2ec7404076a48b5a7688b0a278b431a.webp)

● **Batch Operations**: You can select multiple tasks to manage them together.

## Managing Seeding Tasks

After a BT/PT download task is completed, the system will automatically enter seeding mode. You can manage seeding tasks as follows:

### Managing a Single Seeding Task

1. Open the "**Downloaded**"page and locate the target task.

2. Click the "**Start seeding**" button to begin seeding.

3. Additional right-click options include:

● **Copy Download Link**: For easy sharing of resources.

● **Open from "Files"**: Quickly navigate to the file's directory.

● **Stop or Delete**: Free up system resources as needed.

![](https://file1-cn.ugnas.com/admin/article/2025-12-31/96d1ba8f26154eb7845946b2e75a711b.webp)

### Managing All Seeding Tasks

1. Click the "**Start all**" button in the toolbar to start or pause all seeding tasks at once.

2. To clear all tasks, click "**Delete**" and select "**Delete all**" to remove them in one action.

### Viewing and Searching Seeding Tasks

● **View**: In the "**Downloaded**" list, you can see detailed information for each download task, including current status (Queuing/Paused /Notseeding / Completed), file size, uploaded amount, etc.

● **Search**: Use the search bar at the top to quickly find specific tasks or files matching keywords.

**Note:** Deleting a seeding/download task will not delete the downloaded files.

## Terms and Definitions

| Term | Definition | Characteristics |
| --- | --- | --- |
| BT (BitTorrent) | A protocol for file sharing over peer-to-peer (P2P) networks. | The more users downloading, the faster the speed; users upload while downloading, forming a shared network. |
| PT (Private Tracker) | A private download protocol based on BT, emphasizing access control and traffic tracking. | High privacy (strict, limited access); tracks upload/download traffic to determine user permissions. |
| Torrent File (.torrent) | An index file used by the BT protocol; contains no actual content but records file information and tracker addresses. | Contains only metadata (e.g., file piece information, tracker addresses); required to connect to other users and complete the download. |
| Tracker Server | A server that coordinates the BT network by providing user IP addresses to facilitate data transfer. | Acts like a "switchboard," matching downloaders; if the tracker fails, connections may be affected. |
| DHT (Distributed Hash Table) | A technology that allows BT clients to connect to other users directly without a tracker. | Decentralized storage; reduces tracker load; allows downloads even when trackers are unavailable. |
| Seeding (Download Status) | The state in which a user continues uploading files after download completion to help others download. | File integrity verified via hash; upload contribution affects other users' permissions (e.g., in PT communities). |
