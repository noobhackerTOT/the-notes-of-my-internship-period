# DLNA

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmMTc1In0=

## What is DLNA?

DLNA (Digital Living Network Alliance) is a standardized technical protocol for sharing digital media and content services within a digital home network. NAS devices typically offer DLNA services, allowing you to access and play media files stored on the NAS through DLNA-compatible devices on your local network, such as smart TVs, audio devices, computers, etc.

Once the DLNA feature is enabled, DLNA-supported devices (such as TVs, computers, set-top boxes, etc.) within the local network can access media files (such as music, video, image files, etc.) on the NAS.

The DLNA service not only supports a variety of common media formats but also has an automatic discovery feature, ensuring that you can simultaneously access and control media files on multiple devices.

**Note**: After the DLNA service is enabled, any added "**media resources**" can be accessed anonymously by other devices on the local network. For your privacy and security, please add personal folders or sensitive resources with caution.

![](https://file1-cn.ugnas.com/admin/article/2025-12-31/ae21d0caaa6c42459d3eb3afa362b25b.webp)

## How to Use DLNA

To share media files from the NAS with DLNA devices on the same network, you need to enable the DLNA service.

**Steps:**

1. Go to the "**DLNA**" application interface and turn on the "**DLNA service**." Once enabled, you can access files on the NAS from computers and TVs (DLNA-supported devices) within the same local network. DLNA supports only media files such as videos, music, and images. By default, content is categorized into folders such as videos, music, and photos.

2. Add media file paths: Click "**Add**" to select the folders that DLNA devices can access, and click "**OK**" to add the path.

3. To stop sharing a folder, check the corresponding folder and click "**Remove"**. Removing a path will affect devices that are currently playing files via DLNA. If there are invalid files, you can click "**Remove Invalid**".

**Note:**

● Before enabling the DLNA service, ensure that the NAS and DLNA-compatible devices are on the same local network.

● Accessing the NAS via DLNA is default to anonymous access. Loading a large number of files via DLNA may take time.

● Adding or removing file paths will restart the DLNA service, which will affect devices that are currently playing files via DLNA.

![](https://file1-cn.ugnas.com/admin/article/2025-12-31/9f5ff0285dc84422b1276b370e8ac1e1.webp)

## DLNA Supported Media Formats

The DLNA service supports a variety of common media formats, including photo, audio, video, and subtitle files, as follows:

● **Photos**：JPG, JPEG

● **Audio**：MP3, FLAC, WMA, FLA, FLC, M4A, AAC, MP4, M4P, WAV, OGG, 3GP

● **Video**：MPG, MPEG, AVI, DIVX, ASF, WMV, MP4, M4V, MTS, M2TS, M2T, MKV, VOB, TS, FLV, XVID, MOV, 3GP

● **Subtitle**：SRT, SMI

● **Playlist**：M3U, PLS

You can store such media files on the NAS and play them through DLNA devices.

## FAQs

**Q: What is the difference between the DLNA service and screen casting feature?**

**A:**The main difference is that with DLNA, the playback device independently browses and plays files, so you do not need to continuously control playback using your phone or computer. Screen casting, on the other hand, mirrors content from your phone or computer to the TV, and all actions must be performed on the source device. The detailed explanation is as follows:

● **DLNA service**: DLNA allows devices such as TVs or speakers on the same local network to directly access and play media files stored on the NAS. You simply select the media file to play on the TV, and the NAS streams the file to the device. No ongoing control from a phone or computer is required during playback.

● **Screen casting**: Screen casting mirrors the content displayed on your phone or computer to the TV in real time. Whatever actions you perform on your phone or computer are reflected on the TV, and media playback must be operated and controlled from the phone or computer.
