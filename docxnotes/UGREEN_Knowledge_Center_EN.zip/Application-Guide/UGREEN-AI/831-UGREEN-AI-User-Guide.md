# UGREEN AI User Guide

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmODMxIn0=

**Supported Series**: DH Series, DX Series, DXP Series, and iDX Series**Supported Platforms**: UGREEN NAS PC Client, Web Browser**Supported Version**: UGOS Pro firmware 1.15.12.0051 and laterSome features of the UGREEN AI app (such as**Explore, Intelligent Learning, and Smart Commands**) are currently supported only on iDX series devices.Screenshots in this document are for reference only. Actual interfaces may vary slightly depending on system or application versions. Please refer to the actual interface displayed on your device.

## Overview

**UGREEN AI** serves as the central hub for AI capabilities in UGOS Pro. It is a visual management platform that integrates AI model management, capability orchestration, and scenario-based applications. It deeply connects with system apps such as Uliya, Voice Memos, and Photos, enabling unified access and centralized management of AI capabilities across the entire system.

With UGREEN AI, you can:

● **One-click deployment**: Explore a wide range of AI application scenarios and deploy models to your NAS with a single click—no technical expertise required.

● **Transparent and controllable**: Clearly view all deployed models, along with their associated applications and functions. The full AI workflow is traceable, ensuring data privacy and giving you full control.

● **Flexible model usage**: Enable or disable specific models at any time based on your needs, allowing fine-grained management of system resources.

![](https://file1-cn.ugnas.com/admin/article/2026-05-18/be719966409943a6a0ea31d5182c4c6c.webp)

## Explore Page

On the "**Explore**" page, you can discover common AI application scenarios and install AI resource packages with one click (such as Voice Memos and Uliya resource packages). These packages include apps, dependent environments, and AI models, along with detailed download information and progress status.

### Main AI Application Scenarios (including but not limited to)

**Uliya**

● **AI Knowledge Base Q&A**: Turn Uliya into your personal local knowledge base. Ask questions in natural language and quickly retrieve answers from your stored files.

● **Summarize & Translation Documents**: Automatically summarize long documents or translate content into your desired language to improve efficiency.

● **Smart Commands**: Issue tasks using natural language. Uliya understands your intent and performs corresponding actions automatically, simplifying workflows.

**Voice Memos**

● **Speech-to-text**: Convert recordings into editable text with one click, eliminating the need for repeated playback and making conversations easy to review.

● **Summarization and translation**: Automatically extract key information from recordings, generate concise summaries, and support quick translation for efficient content understanding.

**Photos**

● **Person Recognition**: Automatically detect and categorize faces in photos and videos, enabling quick search and management by person.

● **Image Recognition**: Identify backgrounds and object tags in images, allowing you to search using descriptions (e.g., "beach at sunset").

● **Text Recognition**: Accurately extract text from images with multi-language support, making text searchable and copyable.

● **Similar and Duplicate Photo Recognition**: Automatically identify and organize burst shots and highly similar images, with one-click options to keep or delete, helping free up storage space.

**Universal Search**

● **AI Semantic Search**: Goes beyond traditional keyword and file-type limitations. By leveraging AI to understand natural language queries, it quickly matches and retrieves relevant content.

## Intelligent Learning

After enabling "**Intelligent Learning**", AI will automatically analyze your documents to generate semantic indexes and text summaries. The preprocessed data is centrally stored in UGREEN AI and can be used across applications such as Universal Search, Files, and the Uliya knowledge base—avoiding redundant processing and significantly improving parsing speed when adding files to the knowledge base.

![](https://file1-cn.ugnas.com/admin/article/2026-05-18/e8fc993cd9ec4d27b41f7de42852d9d6.webp)

**Steps:**

1. When entering the "**Intelligent Learning**" page for the first time, you need to download the AI model package (including dependent environments, RAG models, large language models, and multimodal models) to enable intelligent learning, semantic search, and text summarizationfeatures.

2. Once the models are ready, choose a learning mode based on your needs:

● **Quick Mode**
: Uses only the semantic search model, providing fast semantic search with low resource usage.

● **Deep Mode**:Uses a semantic search model together with a large language model to provide semantic understanding for searches (such as finding documents through vague descriptions) and text summarization capabilities (document summary generation), enabling comprehensive content analysis.

3. Set the learning time period.You can set learning periods (night / all day / custom). AI will automatically analyze files during the selected time window.

**Note**: Apps with built-in AI capabilities (such as Photos and Voice Memos) are not affected by this feature.

![](https://file1-cn.ugnas.com/admin/article/2026-05-18/5dde3f3dadeb46cd8acd523e07090eda.webp)

## Model Management

On the "**Model Management**" page, you can centrally download, view, and manage all local AI models, with the following capabilities:

![](https://file1-cn.ugnas.com/admin/article/2026-05-18/d4d954547b5540778961a39914bf3634.webp)

● **Configure Models**: Download required models based on your usage needs.

● **Enable/Disable (All) Models**: Flexibly control the running status of models as needed.

● **Remove Models**: Delete models that are no longer needed to free up system resources.

● **Batch Update Models**: When outdated models are detected, the system will prompt for updates. Click "**Update all**", and the system will automatically upgrade dependencies and update older models to ensure optimal performance and stability.

● **Add Cloud Models (for LLMs)**: Integrate models provided by external vendors based on your needs.

## Smart Commands

In "**Smart Commands**", you can view supported applications and their available commands. You can enable or disable authorization for application tools. Once enabled, you can issue commands via conversation in Uliya, allowing AI to automatically execute corresponding actions.

![](https://file1-cn.ugnas.com/admin/article/2026-05-18/3203987d3b724941bfa813ab920ffe9e.webp)

In the sidebar, you can view the authorized smart commands and AI models for each application individually, and manage the authorization status of each model.

![](https://file1-cn.ugnas.com/admin/article/2026-05-18/5dd2c1e811cd4f9ea8af9c10293d870e.webp)

## Settings

On the "**Settings**" page, you can manage AI-related data:

● **Delete Vector Data**: Clear vector data generated by applications such as Uliya and Universal Search, useful for resetting or clearing cache.

**Note:** After deletion, AI features that rely on this data will become unavailable. Please proceed with caution.

● **Migrate AI Data**: Move AI-related data (including dependencies, AI models, and vector data) to another storage location on the NAS to optimize storage allocation.

![](https://file1-cn.ugnas.com/admin/article/2026-05-18/bd49f673658340f9a579b36cb69dd70d.webp)
