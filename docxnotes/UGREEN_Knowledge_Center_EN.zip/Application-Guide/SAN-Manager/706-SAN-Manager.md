# SAN Manager

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNzA2In0=

**Applicable Version**: UGOS Pro 1.11.0.0002 and above

Screenshots and interfaces in this document are for reference only. Actual displays may vary depending on system or application version. Some features may change across versions, please refer to your actual interface.

## Feature Overview

The "**SAN Manager**" application provides powerful iSCSI services that virtualize the NAS volume into "**virtual disks**". These disks can be recognized by computers as local hard drives over an IP network, enabling efficient and flexible remote storage access.

## What Is iSCSI?

iSCSI can be understood as a form of "**virtual hard drive mapping**". After establishing an iSCSI connection, the space on the NAS appears on your computer like a newly installed physical hard drive, supporting formatting, partitioning, software installation, and data storage.

**Key Concepts:**

When using SAN Manager, it is important to understand the following three core terms:

● **LUN (Logical Unit Number)**: The actual "**virtual disk**". You can define its size, storage location, and type.

● **Target**: The "**entry point**" or" **access channel**" through which a client connects to a LUN. Each Target has a unique IQN (identifier) and can be configured with CHAP authentication.

● **Group (Initiator Group)**: A permission management set used for bulk authorization. Multiple clients can be grouped together and granted unified access to specific LUNs.

## Quick Start: Create and Connect

### Preparation

Before you begin, ensure that:

● Available volume has been created on the NAS.

● The computer and the NAS are on the same local network or can communicate with each other.

● You have obtained the NAS IP address (available under "**Control Panel**">"**Network Settings**">"**Network connection"** in the PC client).

### Step 1: Create a Virtual Disk (LUN)

1. Open the "**SAN Manager**" application, go to the "**LUN**" page, and click "**Add**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/29cbcffd5fde4e70803d82d943821462.webp)

2. Configure the parameters:

● **Name**: Custom (for example, Game).

● **Type**: Thick LUN is recommended for more stable performance.

● **Location**: Choose volume based on SSDs for better performance.

● **Capacity**: Set as needed (for example, 200 GB).

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/9449f9cf39d441d6b3ee0eec75e61677.webp)

3. Click "**OK**" to complete the creation.

### Step 2: Create an Access Target

1. Go to the "**Target**" page and click "**Add**".

2. Select the LUN you just created and click "**Next**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/2754830daedc4d079985c4e01545d7de.webp)

3. For the IQN, it is recommended to use the system-generated default prefix and add an identifiable suffix (for example, `target-Game`). Click "**OK**" to complete the creation.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/ccbe89e9ca1447ccab474aea1b863c31.webp)

**Note:** The default IQN prefix provided by the system complies with iSCSI standards and offers better compatibility.

### Step 3: Mount on the Client (Windows/macOS)

**Windows Client (Windows 11 as an Example)**

1. Press `Win + R`, type `iscsicpl`, and press Enter.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/2820c565297c4cd4b22adb0e79a3cb47.webp)

2. When prompted on first launch, click "**Yes**" to start the iSCSI service.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/b9eb482756b14b14afa808832ae613ac.webp)

3. Switch to the "**Discovery**" tab and click "**Discover Portal**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/4796c73072d54464b8288547d0aa6294.webp)

4. Enter the NAS IP address, keep the port set to the default 3260, and click "**OK**".

Note: The port used for the iSCSI connection must match the port configured in "SAN Manager">"Settings">"iSCSI". The default port is 3260.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/2add4fda340a47beb2156c2dae0dea1e.webp)

5. Switch to the "**Targets**" tab, locate the target, select it, and click "**Connect**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/efee1fe1836a4e9787c9ad047609c46f.webp)

6. In the dialog box, click "**OK**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/26662d3de5a24725bb04400026d7e82f.webp)

7. When the status changes to "**Connected**", the connection is successful.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/936bed34ad4c4f5fb1ef7de3f7450f0b.webp)

**Initialize the Disk:**

1. Press `Win + R`, type `diskmgmt.msc`, and open "**Disk Management**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/c523e180708947afa336ef2e5b2855f2.webp)

2. The system will prompt you to initialize the new disk (choose GPT or MBR). Then right-click the "**Unallocated**" space, select "**New Simple Volume**", and format the disk. It will then be ready for use.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/4fe31118e44943179c10905d6e2ede56.webp)

**macOS Client**

macOS does not include a built-in iSCSI initiator, so third-party software is required (such as DAEMON Tools).

1. Install and launch **DAEMON Tools for Mac**. On the main interface, right-click and select "**Add**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/9965876640f14953a144055d0e52b336.webp)

2. Enter the UGREEN NAS IP address and port (3260), then click "**Add**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/ea5f4d6bac734c3bb38ce14dd834345d.webp)

3. Locate the corresponding target in the list, right-click it, and choose "**Connect**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/5b0018751a6842b28f2da1db18c1166d.webp)

4. After a successful connection, the disk will appear on the desktop or in Finder. For first-time use, initialize the disk using "**Disk Utility**" in macOS (format it as APFS or exFAT).

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/2047419c1d7c4856add39e203564e491.webp)

## Detailed Features and Management

### LUN Management

On the "**LUN**" page, you can view LUN status and capacity, as well as edit existing configurations.

**LUN Type Comparison:**

● **Thick LUN**:Offers better and more consistent performance. volume is pre-allocated and immediately consumes physical capacity at the time of creation.

● **Thin LUN**: Uses on-demand allocation (physical space is consumed only when data is written). This provides higher space utilization, but requires careful monitoring of the storage pool capacity and delivers slightly lower performance.

**Advanced Editing:**

Click "**Edit**" button on an existing LUN to configure advanced options, including access permissions.

On the edit page, you can enable "**Advanced SCSI Command Support**" (FUA and Sync Cache). This ensures that data is written to disk immediately and remains consistent, but may impact performance.

Under the "**Permission"** tab, you can flexibly manage access to the LUN using the following modes:

● **Allow all clients read/write (default)**: All clients connected to the Target can read from and write to the LUN.

● **Custom**: When enabled, you can specify which client groups (Groups) are allowed to access the LUN and define their corresponding permissions.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/ab78b52cc1a941558e84e65f9dd91431.webp)

### Target Management

A "**Target**" acts as the bridge between clients and LUNs. Through the edit options, you can configure authentication methods, data integrity settings, and connection policies for iSCSI targets.

**Access the Edit Page:**

In the Target list, select the target you want to configure and click "**Edit**" buttonto open the Target configuration page.

**CHAP Authentication:**

CHAP enhances connection security. When enabled, clients must provide a username and password when attempting to connect to the NAS.

1. **Authentication Mode Selection**

● **Use default iSCSI CHAP**: The system uses the CHAP username and password preset on the "**Settings**" page.

● **Use custom CHAP**: You can define a dedicated username and password specifically for the selected Target.

2. **Mutual CHAP**

● When enabled, a two-way authentication mechanism is used: the NAS authenticates the client, and the client also authenticates the NAS, providing a higher level of security.

**Notes:**

● In enterprise or complex network environments, enabling CHAP or Mutual CHAP is recommended to prevent unauthorized access.

● In secure network environments, these options can be left disabled to simplify the connection process if enhanced security is not required.

**CRC Checksum:**

You can enable CRC verification to prevent data tampering or corruption during transmission. Note that enabling this feature increases CPU and network overhead.

● **Enable Header Digest**: Performs CRC checks on iSCSI protocol header information.

● **Enable Data Digest**: Performs CRC checks on the data payload transmitted via iSCSI.

**iSCSI Connection Policy:**

● **iSCSI Cluster**: Allows multiple clients to connect to the same Target simultaneously.

**Note:** When this feature is enabled, ensure that the corresponding LUN permissions are set to "**read-only**". If multiple devices write to the same LUN at the same time, there is a high risk of data corruption or file system failure.

### Group (Client Group) Management

Groups are used for batch permission management, especially in scenarios where certain clients need to be restricted to "**read-only**" access.

**Create a Group and Obtain the Client IQN**

1. Press **Win + R**, open the Run dialog, type `iscsicpl`, and press Enter to launch the iSCSI Initiator.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/51276034b1114028970114fdaace3a66.webp)

2. Click "**Configuration**", then copy the "**Initiator Name**" (this is the client IQN). The initiator name must not contain Chinese characters. If necessary, click "**Change**" and modify it to English.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/3c2c6e5034c5428eb3d8f26b7485f589.webp)

3. In the "**SAN Manager**" application, go to "**Group">"Add**", paste the IQN, and save.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/3e5b586291e14c53895584921ca7b028.webp)

**Set "Read-Only" Permissions (Prevent Data Conflicts)**

When multiple clients connect to the same LUN (iSCSI cluster), read-only permissions must be enforced.

1. Go to the "**LUN**" page, edit the target LUN, and switch to the "**Permission**" tab.

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/10b96bb09c6e4c73a9e8063e4c0dd86f.webp)

2. Select "**Custom**", add the previously created Group, and set its permission to "**Read-only**".

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/8f7309d29eb14a5ca25b84f3b0cd1b8f.webp)

**Note:** After changing permissions, clients must disconnect and reconnect for the changes to take effect.

### Settings

On the "**Settings**" page, you can configure system-wide parameters:

![](https://file1-cn.ugnas.com/admin/article/2026-01-16/eeb417c422f54f9ea1d0c419a646fab0.webp)

● **iSCSI service port**: Default is 3260. If changed, clients must update their connection settings accordingly.

● **Base name**: The default IQN prefix used when creating new Targets.

● **Default CHAP**: A predefined set of authentication credentials that can be applied as the default iSCSI CHAP for quick configuration.
