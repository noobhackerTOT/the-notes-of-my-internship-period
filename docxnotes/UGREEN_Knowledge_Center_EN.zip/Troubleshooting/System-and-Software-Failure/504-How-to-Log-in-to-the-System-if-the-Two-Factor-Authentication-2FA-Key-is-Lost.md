# How to Log in to the System if the Two-Factor Authentication (2FA) Key is Lost?

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNTA0In0=

If your mobile device is lost or you are unable to retrieve your OTP key, you can regain access to the UGOS Pro system and disable 2FA using one of the following methods. Please choose the method that best suits your situation.

## Method 1: Log in to NAS Using the Emergency Verification Email

If OTP verification is unavailable, you can use the linked emergency verification email to receive a code for login.

**Steps**

1. On the [Enter Verification Code] page, click "Unable to Verify" via OTP.

2. The system will automatically send a verification code to your registered emergency verification email.

3. Check your email inbox for the code and enter it on the login page to complete the verification process.

4. Once logged in successfully, it is recommended to disable 2FA or bind a new OTP application.

![](https://file1-cn.ugnas.com/admin/article/2025-08-26/a27e35e4c3e64e769b3c2551f35ecbe0.webp)

## Method 2: Log in via a Trusted Device to Disable Two-Factor Authentication

If you have set up a trusted device, you can disable two-factor authentication after logging in on the trusted device.

**Steps**

● Log in to the UGOS Pro system using a trusted device without entering the OTP verification code.

● After a successful login, click the user icon in the top-right corner of the system, select your username, and go to the [Account Settings] page.

● In the left menu, select "Account Security", locate the "Two-Factor Authentication" feature, and click the "Disable" button.

● A verification dialog will appear. Enter the account password to confirm the action and disable two-factor authentication.

● After successful verification, two-factor authentication will be disabled, allowing you to bind a new OTP application.

![](https://file1-cn.ugnas.com/admin/article/2025-08-26/0cfc5b28877f4c938c04127a3ef51d07.webp)

## Method 3: Disable Two-Factor Authentication Through Another Administrator

If there is another administrator account on your device, you can contact them for assistance in disabling your two-factor authentication.

**Steps**

1. The other administrator logs in to the UGOS Pro system.

2. Go to [Control Panel] > [User Management] and locate your account.

3. Click the "···" button on the right side of the account and select "Edit".

4. In the pop-up user settings dialog, scroll down to find the Two-Factor Authentication option and disable it.

5. Save the settings. Once saved, your two-factor authentication will be disabled, and you can log in again using your account password.

![](https://file1-cn.ugnas.com/admin/article/2025-08-26/703dde34088e41ab9e3a6268e6d6c1f5.webp)

## Method 4: Disable Two-Factor Authentication by Resetting the Device

If you are the sole administrator of the device and no other methods are available to regain access, you can disable two-factor authentication by resetting the device.

**Steps**

1. Press and hold the "Reset" button on the device for 5 seconds until you hear a beep, then release the button.

2. Wait for the device to complete the reboot process.

3. Log in to the system using the default administrator account (admin) and a blank password on the login page.

4. After logging in, reset your account password and log in using your account with the new password.

5. Reconfigure the two-factor authentication feature as needed.

**Note:** Resetting the device may restore certain settings. Please back up important data in advance to prevent data loss.

## Notes

1. Bind a commonly used emergency verification email when enabling two-factor authentication. This will help you quickly restore access if the OTP key is unavailable.

2. Ensure you have backed up critical data before resetting the device to disable two-factor authentication, to prevent data loss during the reset process.

3. Reconfigure the two-factor authentication feature after successfully regaining access to enhance account security.
