# After upgrading to macOS 15, the client suite cannot be opened on Mac

Source URL: https://support.ugnas.com/#/detail/eyJjb2RlIjoiMiYmNDIxIn0=

## **Problem Description**

After upgrading the Mac computer to macOS 15, the client can log in successfully; however, after logging in, none of the suites open. Instead, a white loading animation keeps displaying indefinitely.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250718/9a965c0e-af00-40c1-8de1-4487987e1263.png)

## **Solution**

### **Method 1: Restart the Computer**

After upgrading to macOS 15, restarting the Mac can resolve this issue.

### **Method 2: Add to Whitelist**

1. Go to [Settings] > [Privacy & Security].
2. Add the UGREEN NAS App to the whitelist.

![](https://file1-cn.ugnas.com/ugreen-pro/admin/article/20250718/fc09a793-2a63-4ebe-b625-6dcc463c4589.png)
